<?php
require_once 'includes/config.php';
require_once 'auth.php';

$message = '';
$error = '';

// Handle seller registration
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['become_seller'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $phone = trim($_POST['phone']);
    $company = trim($_POST['company']);
    $description = trim($_POST['description']);
    
    // Validation
    if (empty($username) || empty($email) || empty($password)) {
        $error = "Tous les champs obligatoires doivent être remplis";
    } elseif ($password !== $confirm_password) {
        $error = "Les mots de passe ne correspondent pas";
    } elseif (strlen($password) < 6) {
        $error = "Le mot de passe doit contenir au moins 6 caractères";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Email invalide";
    } else {
        // Check if email already exists
        try {
            $stmt = $pdo->prepare("SELECT user_id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            
            if ($stmt->fetch()) {
                $error = "Cet email est déjà utilisé";
            } else {
                // Create seller account
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                
                $stmt = $pdo->prepare("
                    INSERT INTO users (username, email, password, status, created_at)
                    VALUES (?, ?, ?, 'active', NOW())
                ");
                
                $stmt->execute([$username, $email, $hashed_password]);
                
                $message = "Compte vendeur créé avec succès ! Vous pouvez maintenant vous connecter.";
            }
        } catch (PDOException $e) {
            $error = "Erreur lors de la création du compte";
        }
    }
}

// Handle seller login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['seller_login'])) {
    $email = trim($_POST['login_email']);
    $password = $_POST['login_password'];
    
    if (empty($email) || empty($password)) {
        $error = "Email et mot de passe requis";
    } else {
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND status = 'active'");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password'])) {
                // Login successful
                session_start();
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['is_admin'] = $user['is_admin'];
                
                // Update last login
                $stmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE user_id = ?");
                $stmt->execute([$user['user_id']]);
                
                // Redirect to seller dashboard
                header('Location: seller-dashboard.php');
                exit;
            } else {
                $error = "Email ou mot de passe incorrect";
            }
        } catch (PDOException $e) {
            $error = "Erreur de connexion";
        }
    }
}

include 'includes/header.php';
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Devenir Vendeur - Tombola</title>
    <link rel="stylesheet" href="css/layout.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/animations.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="seller-page">
        <!-- Hero Section -->
        <section class="seller-hero">
            <div class="hero-content">
                <div class="hero-text">
                    <h1>💼 Devenez Vendeur sur Tombola</h1>
                    <p class="hero-subtitle">Vendez vos produits, organisez vos propres tombolas et générez des revenus</p>
                    <div class="hero-stats">
                        <div class="stat-item">
                            <span class="stat-number">1000+</span>
                            <span class="stat-label">Vendeurs actifs</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-number">50k+</span>
                            <span class="stat-label">Produits vendus</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-number">98%</span>
                            <span class="stat-label">Satisfaction</span>
                        </div>
                    </div>
                </div>
                <div class="hero-image">
                    <div class="hero-illustration">
                        <span class="hero-emoji">🎯</span>
                        <span class="hero-emoji">💰</span>
                        <span class="hero-emoji">📈</span>
                    </div>
                </div>
            </div>
        </section>

        <!-- Benefits Section -->
        <section class="seller-benefits">
            <div class="container">
                <h2>Pourquoi vendre sur Tombola ?</h2>
                <div class="benefits-grid">
                    <div class="benefit-card">
                        <div class="benefit-icon">💰</div>
                        <h3>Revenus attractifs</h3>
                        <p>Commissions compétitives sur chaque vente. Plus vous vendez, plus vous gagnez !</p>
                    </div>
                    <div class="benefit-card">
                        <div class="benefit-icon">🎯</div>
                        <h3>Audience ciblée</h3>
                        <p>Accédez à une communauté de passionnés de tombola prêts à acheter.</p>
                    </div>
                    <div class="benefit-card">
                        <div class="benefit-icon">📊</div>
                        <h3>Outils avancés</h3>
                        <p>Dashboard complet, statistiques détaillées, gestion simplifiée.</p>
                    </div>
                    <div class="benefit-card">
                        <div class="benefit-icon">🚀</div>
                        <h3>Facilité d'utilisation</h3>
                        <p>Interface intuitive, upload facile, gestion automatisée des tirages.</p>
                    </div>
                    <div class="benefit-card">
                        <div class="benefit-icon">🛡️</div>
                        <h3>Sécurité garantie</h3>
                        <p>Paiements sécurisés, protection contre la fraude, support 24/7.</p>
                    </div>
                    <div class="benefit-card">
                        <div class="benefit-icon">📱</div>
                        <h3>Mobile-friendly</h3>
                        <p>Gérez vos ventes depuis n'importe où avec notre interface responsive.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Action Section -->
        <section class="seller-action">
            <div class="container">
                <div class="action-tabs">
                    <button class="tab-btn active" onclick="showTab('register-tab')">🆕 Créer un compte</button>
                    <button class="tab-btn" onclick="showTab('login-tab')">🔑 Se connecter</button>
                </div>

                <!-- Register Tab -->
                <div id="register-tab" class="tab-content active">
                    <div class="form-container">
                        <div class="form-header">
                            <h3>Créer votre compte vendeur</h3>
                            <p>Rejoignez notre communauté de vendeurs en quelques minutes</p>
                        </div>

                        <?php if ($message): ?>
                            <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
                        <?php endif; ?>

                        <?php if ($error && isset($_POST['become_seller'])): ?>
                            <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
                        <?php endif; ?>

                        <form method="POST" class="seller-form" id="registerForm">
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="username">Nom d'utilisateur *</label>
                                    <input type="text" id="username" name="username" required 
                                           value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '' ?>">
                                </div>
                                <div class="form-group">
                                    <label for="email">Email *</label>
                                    <input type="email" id="email" name="email" required 
                                           value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group">
                                    <label for="password">Mot de passe *</label>
                                    <div class="password-input">
                                        <input type="password" id="password" name="password" required>
                                        <button type="button" class="password-toggle" onclick="togglePassword('password')">👁️</button>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="confirm_password">Confirmer le mot de passe *</label>
                                    <div class="password-input">
                                        <input type="password" id="confirm_password" name="confirm_password" required>
                                        <button type="button" class="password-toggle" onclick="togglePassword('confirm_password')">👁️</button>
                                    </div>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group">
                                    <label for="phone">Téléphone</label>
                                    <input type="tel" id="phone" name="phone" 
                                           value="<?= isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : '' ?>">
                                </div>
                                <div class="form-group">
                                    <label for="company">Entreprise</label>
                                    <input type="text" id="company" name="company" 
                                           value="<?= isset($_POST['company']) ? htmlspecialchars($_POST['company']) : '' ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="description">Description de votre activité</label>
                                <textarea id="description" name="description" rows="4" 
                                          placeholder="Décrivez brièvement ce que vous vendez..."><?= isset($_POST['description']) ? htmlspecialchars($_POST['description']) : '' ?></textarea>
                            </div>

                            <div class="form-group">
                                <label class="checkbox-label">
                                    <input type="checkbox" name="terms" required>
                                    <span>J'accepte les <a href="terms.php" target="_blank">conditions d'utilisation</a> et la <a href="privacy.php" target="_blank">politique de confidentialité</a></span>
                                </label>
                            </div>

                            <div class="form-group">
                                <label class="checkbox-label">
                                    <input type="checkbox" name="newsletter">
                                    <span>Je souhaite recevoir les nouveautés et conseils pour vendeurs</span>
                                </label>
                            </div>

                            <button type="submit" name="become_seller" class="btn btn-primary btn-large">
                                <span class="btn-icon">🚀</span>
                                Créer mon compte vendeur
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Login Tab -->
                <div id="login-tab" class="tab-content">
                    <div class="form-container">
                        <div class="form-header">
                            <h3>Connexion vendeur</h3>
                            <p>Accédez à votre espace vendeur existant</p>
                        </div>

                        <?php if ($error && isset($_POST['seller_login'])): ?>
                            <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
                        <?php endif; ?>

                        <form method="POST" class="seller-form" id="loginForm">
                            <div class="form-group">
                                <label for="login_email">Email</label>
                                <input type="email" id="login_email" name="login_email" required>
                            </div>

                            <div class="form-group">
                                <label for="login_password">Mot de passe</label>
                                <div class="password-input">
                                    <input type="password" id="login_password" name="login_password" required>
                                    <button type="button" class="password-toggle" onclick="togglePassword('login_password')">👁️</button>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="checkbox-label">
                                    <input type="checkbox" name="remember">
                                    <span>Se souvenir de moi</span>
                                </label>
                            </div>

                            <button type="submit" name="seller_login" class="btn btn-primary btn-large">
                                <span class="btn-icon">🔑</span>
                                Se connecter
                            </button>

                            <div class="form-links">
                                <a href="forgot-password.php">Mot de passe oublié ?</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>

        <!-- How it Works Section -->
        <section class="how-it-works">
            <div class="container">
                <h2>Comment ça marche ?</h2>
                <div class="steps-grid">
                    <div class="step-card">
                        <div class="step-number">1</div>
                        <div class="step-content">
                            <h3>📝 Créez votre compte</h3>
                            <p>Inscription simple et rapide. Vérification de votre identité pour la sécurité.</p>
                        </div>
                    </div>
                    <div class="step-card">
                        <div class="step-number">2</div>
                        <div class="step-content">
                            <h3>📦 Ajoutez vos produits</h3>
                            <p>Upload facile avec photos, description détaillée et paramètres de la tombola.</p>
                        </div>
                    </div>
                    <div class="step-card">
                        <div class="step-number">3</div>
                        <div class="step-content">
                            <h3>🎯 Gérez vos ventes</h3>
                            <p>Suivez les ventes en temps réel, communiquez avec les acheteurs.</p>
                        </div>
                    </div>
                    <div class="step-card">
                        <div class="step-number">4</div>
                        <div class="step-content">
                            <h3>🏆 Tirage automatique</h3>
                            <p>Le système effectue le tirage équitable et notifie automatiquement le gagnant.</p>
                        </div>
                    </div>
                    <div class="step-card">
                        <div class="step-number">5</div>
                        <div class="step-content">
                            <h3>💰 Recevez vos gains</h3>
                            <p>Virement automatique de vos commissions après déduction des frais.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- FAQ Section -->
        <section class="seller-faq">
            <div class="container">
                <h2>Questions fréquentes</h2>
                <div class="faq-grid">
                    <div class="faq-item">
                        <button class="faq-question" onclick="toggleFaq(this)">
                            <span>💰 Quelles sont les commissions ?</span>
                            <span class="faq-arrow">▼</span>
                        </button>
                        <div class="faq-answer">
                            <p>Nos commissions sont de 10% sur chaque vente. Pas de frais cachés, pas d'abonnement mensuel.</p>
                        </div>
                    </div>

                    <div class="faq-item">
                        <button class="faq-question" onclick="toggleFaq(this)">
                            <span>⏰ Quand suis-je payé ?</span>
                            <span class="faq-arrow">▼</span>
                        </button>
                        <div class="faq-answer">
                            <p>Les paiements sont effectués automatiquement 7 jours après la fin de chaque tombola.</p>
                        </div>
                    </div>

                    <div class="faq-item">
                        <button class="faq-question" onclick="toggleFaq(this)">
                            <span>📦 Quels produits puis-je vendre ?</span>
                            <span class="faq-arrow">▼</span>
                        </button>
                        <div class="faq-answer">
                            <p>Tous les produits légaux : électronique, mode, maison, sport, etc. Voir nos conditions pour la liste complète.</p>
                        </div>
                    </div>

                    <div class="faq-item">
                        <button class="faq-question" onclick="toggleFaq(this)">
                            <span>🛡️ Comment garantissez-vous l'équité ?</span>
                            <span class="faq-arrow">▼</span>
                        </button>
                        <div class="faq-answer">
                            <p>Nos algorithmes de tirage sont certifiés équitables et auditables. Transparence totale sur tous les tirages.</p>
                        </div>
                    </div>

                    <div class="faq-item">
                        <button class="faq-question" onclick="toggleFaq(this)">
                            <span>📞 Comment obtenir de l'aide ?</span>
                            <span class="faq-arrow">▼</span>
                        </button>
                        <div class="faq-answer">
                            <p>Support 24/7 par chat, email et téléphone. Équipe dédiée aux vendeurs pour un accompagnement personnalisé.</p>
                        </div>
                    </div>

                    <div class="faq-item">
                        <button class="faq-question" onclick="toggleFaq(this)">
                            <span>📈 Comment augmenter mes ventes ?</span>
                            <span class="faq-arrow">▼</span>
                        </button>
                        <div class="faq-answer">
                            <p>Photos de qualité, descriptions détaillées, prix attractifs. Notre équipe vous accompagne avec des conseils personnalisés.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script>
        function showTab(tabId) {
            // Hide all tabs
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Remove active class from all buttons
            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            
            // Show selected tab
            document.getElementById(tabId).classList.add('active');
            
            // Add active class to clicked button
            event.target.classList.add('active');
        }

        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            const button = input.nextElementSibling;
            
            if (input.type === 'password') {
                input.type = 'text';
                button.textContent = '🙈';
            } else {
                input.type = 'password';
                button.textContent = '👁️';
            }
        }

        function toggleFaq(button) {
            const faqItem = button.parentElement;
            const answer = faqItem.querySelector('.faq-answer');
            const arrow = button.querySelector('.faq-arrow');
            
            faqItem.classList.toggle('active');
            
            if (faqItem.classList.contains('active')) {
                answer.style.maxHeight = answer.scrollHeight + 'px';
                arrow.textContent = '▲';
            } else {
                answer.style.maxHeight = '0';
                arrow.textContent = '▼';
            }
        }

        // Form validation
        document.getElementById('registerForm').addEventListener('submit', function(e) {
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (password !== confirmPassword) {
                e.preventDefault();
                alert('Les mots de passe ne correspondent pas');
            }
        });
    </script>

    <style>
        .seller-page {
            min-height: 100vh;
        }

        .seller-hero {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 100px 0;
            position: relative;
            overflow: hidden;
        }

        .hero-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 60px;
            align-items: center;
        }

        .hero-text h1 {
            font-size: 3rem;
            margin-bottom: 20px;
            line-height: 1.2;
        }

        .hero-subtitle {
            font-size: 1.25rem;
            margin-bottom: 40px;
            opacity: 0.9;
        }

        .hero-stats {
            display: flex;
            gap: 40px;
        }

        .stat-item {
            text-align: center;
        }

        .stat-number {
            display: block;
            font-size: 2.5rem;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .stat-label {
            font-size: 14px;
            opacity: 0.8;
        }

        .hero-illustration {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 30px;
            flex-wrap: wrap;
        }

        .hero-emoji {
            font-size: 4rem;
            animation: float 3s ease-in-out infinite;
        }

        .hero-emoji:nth-child(2) {
            animation-delay: 0.5s;
        }

        .hero-emoji:nth-child(3) {
            animation-delay: 1s;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-20px); }
        }

        .seller-benefits {
            padding: 80px 0;
            background: #f8f9fa;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .seller-benefits h2 {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 60px;
            color: #333;
        }

        .benefits-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 30px;
        }

        .benefit-card {
            background: white;
            padding: 40px 30px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }

        .benefit-card:hover {
            transform: translateY(-10px);
        }

        .benefit-icon {
            font-size: 3rem;
            margin-bottom: 20px;
        }

        .benefit-card h3 {
            font-size: 1.5rem;
            margin-bottom: 15px;
            color: #333;
        }

        .benefit-card p {
            color: #666;
            line-height: 1.6;
        }

        .seller-action {
            padding: 80px 0;
            background: white;
        }

        .action-tabs {
            display: flex;
            justify-content: center;
            margin-bottom: 40px;
            gap: 20px;
        }

        .tab-btn {
            padding: 15px 30px;
            border: 2px solid #667eea;
            background: white;
            color: #667eea;
            border-radius: 25px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .tab-btn.active,
        .tab-btn:hover {
            background: #667eea;
            color: white;
        }

        .tab-content {
            display: none;
            max-width: 600px;
            margin: 0 auto;
        }

        .tab-content.active {
            display: block;
        }

        .form-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .form-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px 30px;
            text-align: center;
        }

        .form-header h3 {
            font-size: 1.75rem;
            margin-bottom: 10px;
        }

        .form-header p {
            opacity: 0.9;
        }

        .seller-form {
            padding: 40px 30px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #333;
        }

        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s ease;
        }

        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .password-input {
            position: relative;
        }

        .password-toggle {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }

        .checkbox-label {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
        }

        .checkbox-label input[type="checkbox"] {
            width: auto;
        }

        .btn-large {
            width: 100%;
            padding: 15px 30px;
            font-size: 18px;
            font-weight: 600;
            margin-top: 20px;
        }

        .form-links {
            text-align: center;
            margin-top: 20px;
        }

        .form-links a {
            color: #667eea;
            text-decoration: none;
        }

        .form-links a:hover {
            text-decoration: underline;
        }

        .how-it-works {
            padding: 80px 0;
            background: #f8f9fa;
        }

        .how-it-works h2 {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 60px;
            color: #333;
        }

        .steps-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }

        .step-card {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            position: relative;
        }

        .step-number {
            position: absolute;
            top: -15px;
            left: 30px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 18px;
        }

        .step-content {
            margin-top: 15px;
        }

        .step-content h3 {
            font-size: 1.25rem;
            margin-bottom: 15px;
            color: #333;
        }

        .step-content p {
            color: #666;
            line-height: 1.6;
        }

        .seller-faq {
            padding: 80px 0;
            background: white;
        }

        .seller-faq h2 {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 60px;
            color: #333;
        }

        .faq-grid {
            max-width: 800px;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .faq-item {
            border: 1px solid #e9ecef;
            border-radius: 10px;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .faq-item.active {
            border-color: #667eea;
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.1);
        }

        .faq-question {
            width: 100%;
            padding: 20px;
            background: white;
            border: none;
            text-align: left;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 16px;
            font-weight: 500;
            color: #333;
            transition: background-color 0.3s ease;
        }

        .faq-question:hover {
            background: #f8f9fa;
        }

        .faq-arrow {
            transition: transform 0.3s ease;
            color: #667eea;
        }

        .faq-item.active .faq-arrow {
            transform: rotate(180deg);
        }

        .faq-answer {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease;
            background: #f8f9fa;
        }

        .faq-answer p {
            padding: 20px;
            margin: 0;
            color: #666;
            line-height: 1.6;
        }

        @media (max-width: 768px) {
            .hero-content {
                grid-template-columns: 1fr;
                text-align: center;
            }

            .hero-text h1 {
                font-size: 2rem;
            }

            .hero-stats {
                justify-content: center;
                gap: 20px;
            }

            .form-row {
                grid-template-columns: 1fr;
            }

            .action-tabs {
                flex-direction: column;
                align-items: center;
            }

            .tab-btn {
                width: 100%;
                max-width: 300px;
            }

            .benefits-grid {
                grid-template-columns: 1fr;
            }

            .steps-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</body>
</html>