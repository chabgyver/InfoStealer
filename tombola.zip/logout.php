<?php
session_start();

define('ROOT_PATH', realpath(dirname(__FILE__)));
require_once 'includes/config.php';

// Log the logout activity
if (isset($_SESSION['user_id'])) {
    try {
        $stmt = $pdo->prepare("
            INSERT INTO user_logs (user_id, action, data, created_at)
            VALUES (?, 'logout', ?, NOW())
        ");

        $logData = json_encode([
            'ip' => $_SERVER['REMOTE_ADDR'],
            'user_agent' => $_SERVER['HTTP_USER_AGENT'],
            'logout_time' => date('Y-m-d H:i:s')
        ]);

        $stmt->execute([$_SESSION['user_id'], $logData]);
    } catch (PDOException $e) {
        // On continue même si l'enregistrement échoue
    }
}

// Nettoyage session
$_SESSION = [];

if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

session_destroy();

header('Location: index.html?message=logged_out');
exit;
?>
