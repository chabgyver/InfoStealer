// Popup system for buy modal and other modals
class PopupManager {
    constructor() {
        this.modals = new Map();
        this.init();
    }

    init() {
        this.createBuyModal();
        this.setupEventListeners();
    }

    createBuyModal() {
        const buyModal = document.createElement('div');
        buyModal.id = 'buyModal';
        buyModal.className = 'modal';
        buyModal.innerHTML = `
            <div class="modal-overlay"></div>
            <div class="modal-content buy-modal">
                <div class="modal-header">
                    <h3>Acheter des tickets</h3>
                    <button class="modal-close" onclick="popupManager.close('buyModal')">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="product-preview">
                        <img id="modalProductImage" src="" alt="Produit">
                        <div class="product-details">
                            <h4 id="modalProductTitle"></h4>
                            <div class="price-info">
                                <span class="product-price">Prix: <span id="modalProductPrice"></span></span>
                                <span class="ticket-price">Ticket: <span id="modalTicketPrice"></span></span>
                            </div>
                            <div class="tickets-info">
                                <span class="tickets-left">Tickets restants: <span id="modalTicketsLeft"></span></span>
                            </div>
                        </div>
                    </div>
                    <form id="buyForm" class="buy-form">
                        <div class="form-group">
                            <label for="ticketQuantity">Nombre de tickets</label>
                            <div class="quantity-input">
                                <button type="button" onclick="popupManager.decreaseQuantity()">-</button>
                                <input type="number" id="ticketQuantity" value="1" min="1" max="10" oninput="popupManager.updateTotal()">
                                <button type="button" onclick="popupManager.increaseQuantity()">+</button>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Numéros de tickets</label>
                            <div id="ticketNumbers" class="ticket-numbers"></div>
                        </div>
                        <div class="form-group">
                            <label>Méthode de paiement</label>
                            <select id="paymentMethod" required>
                                <option value="card">Carte bancaire</option>
                                <option value="paypal">PayPal</option>
                                <option value="bank">Virement bancaire</option>
                            </select>
                        </div>
                        <div class="total-section">
                            <div class="total-line">
                                <span>Total à payer:</span>
                                <span id="totalPrice" class="total-amount">0.00 €</span>
                            </div>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary btn-full">
                                <span class="btn-text">Acheter maintenant</span>
                                <span class="btn-loading" style="display: none;">⏳ Traitement...</span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        `;
        
        document.body.appendChild(buyModal);
        this.modals.set('buyModal', buyModal);
    }

    setupEventListeners() {
        // Close modal when clicking outside
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal-overlay')) {
                this.close(e.target.parentElement.id);
            }
        });

        // Close modal with Escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeAll();
            }
        });

        // Buy form submission
        document.addEventListener('submit', (e) => {
            if (e.target.id === 'buyForm') {
                e.preventDefault();
                this.handleBuySubmit(e);
            }
        });
    }

    open(modalId, data = {}) {
        const modal = this.modals.get(modalId) || document.getElementById(modalId);
        if (!modal) return;

        if (modalId === 'buyModal') {
            this.populateBuyModal(data);
        }

        modal.style.display = 'block';
        document.body.style.overflow = 'hidden';
        
        // Animation
        setTimeout(() => {
            modal.classList.add('active');
        }, 10);
    }

    close(modalId) {
        const modal = this.modals.get(modalId) || document.getElementById(modalId);
        if (!modal) return;

        modal.classList.remove('active');
        
        setTimeout(() => {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }, 300);
    }

    closeAll() {
        this.modals.forEach((modal, id) => {
            this.close(id);
        });
    }

    populateBuyModal(product) {
        document.getElementById('modalProductTitle').textContent = product.title;
        document.getElementById('modalProductPrice').textContent = product.price + ' €';
        document.getElementById('modalTicketPrice').textContent = product.ticket_price + ' €';
        document.getElementById('modalTicketsLeft').textContent = product.total_tickets - product.tickets_sold;
        
        const modalImage = document.getElementById('modalProductImage');
        if (product.main_image) {
            modalImage.src = product.main_image;
            modalImage.style.display = 'block';
        } else {
            modalImage.style.display = 'none';
        }

        // Store product data
        document.getElementById('buyForm').dataset.productId = product.product_id;
        document.getElementById('buyForm').dataset.ticketPrice = product.ticket_price;
        document.getElementById('buyForm').dataset.maxTickets = product.total_tickets - product.tickets_sold;

        // Reset form
        document.getElementById('ticketQuantity').value = 1;
        this.updateTotal();
        this.generateTicketNumbers();
    }

    increaseQuantity() {
        const input = document.getElementById('ticketQuantity');
        const maxTickets = parseInt(document.getElementById('buyForm').dataset.maxTickets);
        const currentValue = parseInt(input.value);
        
        if (currentValue < Math.min(10, maxTickets)) {
            input.value = currentValue + 1;
            this.updateTotal();
            this.generateTicketNumbers();
        }
    }

    decreaseQuantity() {
        const input = document.getElementById('ticketQuantity');
        const currentValue = parseInt(input.value);
        
        if (currentValue > 1) {
            input.value = currentValue - 1;
            this.updateTotal();
            this.generateTicketNumbers();
        }
    }

    updateTotal() {
        const quantity = parseInt(document.getElementById('ticketQuantity').value);
        const ticketPrice = parseFloat(document.getElementById('buyForm').dataset.ticketPrice);
        const total = quantity * ticketPrice;
        
        document.getElementById('totalPrice').textContent = total.toFixed(2) + ' €';
    }

    generateTicketNumbers() {
        const quantity = parseInt(document.getElementById('ticketQuantity').value);
        const container = document.getElementById('ticketNumbers');
        
        container.innerHTML = '';
        
        for (let i = 0; i < quantity; i++) {
            const ticketNumber = this.generateRandomTicketNumber();
            const span = document.createElement('span');
            span.className = 'ticket-number';
            span.textContent = ticketNumber;
            container.appendChild(span);
        }
    }

    generateRandomTicketNumber() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let result = '';
        for (let i = 0; i < 8; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }

    async handleBuySubmit(e) {
        const form = e.target;
        const productId = parseInt(form.dataset.productId);
        const quantity = parseInt(document.getElementById('ticketQuantity').value);
        const paymentMethod = document.getElementById('paymentMethod').value;
        const ticketPrice = parseFloat(form.dataset.ticketPrice);
        const total = quantity * ticketPrice;

        // Show loading state
        const btnText = form.querySelector('.btn-text');
        const btnLoading = form.querySelector('.btn-loading');
        btnText.style.display = 'none';
        btnLoading.style.display = 'inline';

        try {
            const response = await fetch('buy_ticket.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    product_id: productId,
                    quantity: quantity,
                    payment_method: paymentMethod,
                    amount: total
                })
            });

            const data = await response.json();

            if (data.success) {
                this.showSuccessMessage('Tickets achetés avec succès !');
                this.close('buyModal');
                // Refresh the page or update the product
                if (window.loadProducts) {
                    window.loadProducts();
                } else {
                    location.reload();
                }
            } else {
                this.showErrorMessage(data.message || 'Erreur lors de l\'achat');
            }
        } catch (error) {
            console.error('Error:', error);
            this.showErrorMessage('Erreur de connexion');
        } finally {
            // Reset loading state
            btnText.style.display = 'inline';
            btnLoading.style.display = 'none';
        }
    }

    showSuccessMessage(message) {
        this.showMessage(message, 'success');
    }

    showErrorMessage(message) {
        this.showMessage(message, 'error');
    }

    showMessage(message, type) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `alert alert-${type}`;
        messageDiv.textContent = message;
        
        document.body.appendChild(messageDiv);
        
        setTimeout(() => {
            messageDiv.remove();
        }, 5000);
    }
}

// Initialize popup manager
const popupManager = new PopupManager();

// Global functions for compatibility
function openBuyModal(productId) {
    // Find product data
    const product = window.products ? window.products.find(p => p.product_id === productId) : null;
    if (product) {
        popupManager.open('buyModal', product);
    }
}

function closeBuyModal() {
    popupManager.close('buyModal');
}
