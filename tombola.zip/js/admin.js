// Admin JavaScript
let currentUser = null;
let currentSection = 'dashboard';

// Initialize admin panel
document.addEventListener('DOMContentLoaded', function() {
    checkAdminAuth();
    initializeAdmin();
});

// Check admin authentication
function checkAdminAuth() {
    const token = localStorage.getItem('adminToken');
    if (!token) {
        window.location.href = 'login.html';
        return;
    }
    
    // Verify token with server
    fetch('auth.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            action: 'verify_admin_token',
            token: token
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            currentUser = data.user;
            document.getElementById('adminUsername').textContent = currentUser.username;
        } else {
            window.location.href = 'login.html';
        }
    })
    .catch(error => {
        console.error('Error:', error);
        window.location.href = 'login.html';
    });
}

// Initialize admin functions
function initializeAdmin() {
    loadDashboardStats();
    loadProducts();
    loadUsers();
    loadTransactions();
    setupEventListeners();
}

// Setup event listeners
function setupEventListeners() {
    // Add product form
    document.getElementById('addProductForm').addEventListener('submit', function(e) {
        e.preventDefault();
        addProduct();
    });
    
    // Image upload preview
    document.getElementById('productImages').addEventListener('change', function(e) {
        previewImages(e.target.files);
    });
}

// Show section
function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.admin-section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Show selected section
    document.getElementById(sectionId).classList.add('active');
    
    // Update menu
    document.querySelectorAll('.admin-menu a').forEach(link => {
        link.classList.remove('active');
    });
    document.querySelector(`[onclick="showSection('${sectionId}')"]`).classList.add('active');
    
    currentSection = sectionId;
    
    // Load section data
    switch(sectionId) {
        case 'dashboard':
            loadDashboardStats();
            break;
        case 'products':
            loadProducts();
            break;
        case 'users':
            loadUsers();
            break;
        case 'transactions':
            loadTransactions();
            break;
        case 'statistics':
            loadStatistics();
            break;
    }
}

// Load dashboard statistics
function loadDashboardStats() {
    fetch('api/products.php?action=stats')
        .then(response => response.json())
        .then(data => {
            document.getElementById('totalProducts').textContent = data.totalProducts || 0;
            document.getElementById('totalUsers').textContent = data.totalUsers || 0;
            document.getElementById('totalRevenue').textContent = (data.totalRevenue || 0) + ' €';
            document.getElementById('totalTickets').textContent = data.totalTickets || 0;
        })
        .catch(error => console.error('Error loading stats:', error));
}

// Load products
function loadProducts() {
    fetch('api/products.php?action=admin_list')
        .then(response => response.json())
        .then(data => {
            const tbody = document.getElementById('productsTableBody');
            tbody.innerHTML = '';
            
            data.forEach(product => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${product.product_id}</td>
                    <td>${product.title}</td>
                    <td>${product.price} €</td>
                    <td>${product.tickets_sold}/${product.total_tickets}</td>
                    <td><span class="badge ${product.status}">${product.status}</span></td>
                    <td>
                        <button onclick="editProduct(${product.product_id})" class="btn btn-sm btn-primary">Modifier</button>
                        <button onclick="deleteProduct(${product.product_id})" class="btn btn-sm btn-danger">Supprimer</button>
                    </td>
                `;
                tbody.appendChild(row);
            });
        })
        .catch(error => console.error('Error loading products:', error));
}

// Load users
function loadUsers() {
    fetch('api/users.php?action=list')
        .then(response => response.json())
        .then(data => {
            const tbody = document.getElementById('usersTableBody');
            tbody.innerHTML = '';
            
            data.forEach(user => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${user.user_id}</td>
                    <td>${user.username}</td>
                    <td>${user.email}</td>
                    <td>${user.is_admin ? 'Admin' : 'Utilisateur'}</td>
                    <td><span class="badge ${user.status}">${user.status}</span></td>
                    <td>
                        <button onclick="editUser(${user.user_id})" class="btn btn-sm btn-primary">Modifier</button>
                        <button onclick="toggleUserStatus(${user.user_id})" class="btn btn-sm btn-warning">Basculer</button>
                    </td>
                `;
                tbody.appendChild(row);
            });
        })
        .catch(error => console.error('Error loading users:', error));
}

// Load transactions
function loadTransactions() {
    fetch('api/transactions.php?action=list')
        .then(response => response.json())
        .then(data => {
            const tbody = document.getElementById('transactionsTableBody');
            tbody.innerHTML = '';
            
            data.forEach(transaction => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${transaction.transaction_id}</td>
                    <td>${transaction.username}</td>
                    <td>${transaction.product_title}</td>
                    <td>${transaction.amount} €</td>
                    <td>${new Date(transaction.created_at).toLocaleDateString()}</td>
                    <td><span class="badge ${transaction.status}">${transaction.status}</span></td>
                `;
                tbody.appendChild(row);
            });
        })
        .catch(error => console.error('Error loading transactions:', error));
}

// Show add product form
function showAddProductForm() {
    document.getElementById('addProductModal').style.display = 'block';
}

// Close modal
function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Preview images
function previewImages(files) {
    const preview = document.getElementById('imagePreview');
    preview.innerHTML = '';
    
    Array.from(files).forEach((file, index) => {
        if (file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const div = document.createElement('div');
                div.className = 'image-preview-item';
                div.innerHTML = `
                    <img src="${e.target.result}" alt="Preview">
                    <button type="button" class="image-preview-remove" onclick="removeImage(${index})">×</button>
                `;
                preview.appendChild(div);
            };
            reader.readAsDataURL(file);
        }
    });
}

// Add product
function addProduct() {
    const form = document.getElementById('addProductForm');
    const formData = new FormData(form);
    
    fetch('api/products.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Produit ajouté avec succès !');
            closeModal('addProductModal');
            form.reset();
            document.getElementById('imagePreview').innerHTML = '';
            loadProducts();
        } else {
            alert('Erreur : ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Erreur lors de l\'ajout du produit');
    });
}

// Edit product
function editProduct(productId) {
    // Implementation for editing product
    console.log('Edit product:', productId);
}

// Delete product
function deleteProduct(productId) {
    if (confirm('Êtes-vous sûr de vouloir supprimer ce produit ?')) {
        fetch('api/products.php', {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                product_id: productId
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Produit supprimé avec succès !');
                loadProducts();
            } else {
                alert('Erreur : ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Erreur lors de la suppression');
        });
    }
}

// Logout
function logout() {
    localStorage.removeItem('adminToken');
    window.location.href = 'login.html';
}

// Close modals when clicking outside
window.onclick = function(event) {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
}
