/**
 * ===== SYSTÈME DE VENTE DE TOMBOLA - JAVASCRIPT PRINCIPAL =====
 * 
 * Fonctionnalités principales :
 * - Gestion complète du formulaire de vente
 * - Validation en temps réel
 * - Intégration éditeur de texte riche
 * - Upload d'images avec drag & drop
 * - Calcul automatique des tickets
 * - Protection CSRF
 * - Gestion des erreurs
 * - Interface utilisateur moderne
 * 
 * @author Système Tombola
 * @version 2.0
 * @since 2024
 */

'use strict';

// ===== CONFIGURATION GLOBALE =====
const TOMBOLA_CONFIG = {
    // Limites et contraintes
    MAX_IMAGES: 5,
    MAX_IMAGE_SIZE: 5 * 1024 * 1024, // 5MB
    ALLOWED_FORMATS: ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'],
    MIN_TICKET_PRICE: 0.50,
    MAX_TICKET_PRICE: 1000.00,
    MAX_DESCRIPTION_LENGTH: 2000,

    // URLs des endpoints
    ENDPOINTS: {
        UPLOAD: 'image_processor.php',
        VALIDATE: 'validation.php',
        SUBMIT: 'process_sale.php',
        CSRF: 'get_csrf_token.php'
    },

    // Messages d'erreur
    MESSAGES: {
        REQUIRED_FIELD: 'Ce champ est obligatoire',
        INVALID_EMAIL: 'Adresse email invalide',
        INVALID_PHONE: 'Numéro de téléphone invalide',
        INVALID_PRICE: 'Prix invalide (entre 0.50€ et 1000€)',
        INVALID_QUANTITY: 'Quantité invalide (minimum 1)',
        FILE_TOO_LARGE: 'Fichier trop volumineux (max 5MB)',
        INVALID_FORMAT: 'Format non supporté (JPG, PNG, WebP uniquement)',
        TOO_MANY_FILES: 'Maximum 5 images autorisées',
        UPLOAD_ERROR: 'Erreur lors de l'upload',
        NETWORK_ERROR: 'Erreur de connexion',
        SERVER_ERROR: 'Erreur serveur',
        CSRF_ERROR: 'Token de sécurité invalide'
    }
};

// ===== FONCTIONS UTILITAIRES =====

/**
 * Fonction de debounce pour limiter les appels
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Fonction de throttle pour limiter la fréquence
 */
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

/**
 * Validation d'email
 */
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

/**
 * Validation de téléphone français
 */
function isValidPhone(phone) {
    const phoneRegex = /^(?:(?:\+|00)33|0)\s*[1-9](?:[\s.-]*\d{2}){4}$/;
    return phoneRegex.test(phone);
}

/**
 * Formatage du prix
 */
function formatPrice(price) {
    return parseFloat(price).toFixed(2) + '€';
}

/**
 * Formatage de la taille de fichier
 */
function formatFileSize(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * Génération d'un ID unique
 */
function generateUniqueId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

/**
 * Sanitisation des données
 */
function sanitizeInput(input) {
    if (typeof input !== 'string') return input;
    return input.trim().replace(/[<>]/g, '');
}

/**
 * Vérification si un élément est visible
 */
function isElementVisible(element) {
    return element.offsetWidth > 0 && element.offsetHeight > 0;
}

/**
 * Animation smooth scroll
 */
function smoothScrollTo(element, duration = 500) {
    const targetPosition = element.offsetTop;
    const startPosition = window.pageYOffset;
    const distance = targetPosition - startPosition;
    let startTime = null;

    function animation(currentTime) {
        if (startTime === null) startTime = currentTime;
        const timeElapsed = currentTime - startTime;
        const run = ease(timeElapsed, startPosition, distance, duration);
        window.scrollTo(0, run);
        if (timeElapsed < duration) requestAnimationFrame(animation);
    }

    function ease(t, b, c, d) {
        t /= d / 2;
        if (t < 1) return c / 2 * t * t + b;
        t--;
        return -c / 2 * (t * (t - 2) - 1) + b;
    }

    requestAnimationFrame(animation);
}

// ===== CLASSE PRINCIPALE DU SYSTÈME DE VENTE =====
class TombolaSaleSystem {
    constructor() {
        this.form = null;
        this.csrfToken = null;
        this.uploadedImages = [];
        this.validationRules = {};
        this.textEditor = null;
        this.imageUploader = null;
        this.isSubmitting = false;
        this.unsavedChanges = false;
        this.autoSaveTimer = null;

        // Initialisation
        this.init();
    }

    /**
     * Initialisation du système
     */
    async init() {
        try {
            console.log('🚀 Initialisation du système de vente...');

            // Attendre que le DOM soit prêt
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', () => this.setup());
            } else {
                await this.setup();
            }

        } catch (error) {
            console.error('❌ Erreur lors de l'initialisation:', error);
            this.showError('Erreur lors de l'initialisation du système');
        }
    }

    /**
     * Configuration initiale
     */
    async setup() {
        try {
            // Récupération des éléments DOM
            this.form = document.getElementById('sale-form');
            if (!this.form) {
                throw new Error('Formulaire de vente non trouvé');
            }

            // Récupération du token CSRF
            await this.fetchCSRFToken();

            // Configuration des règles de validation
            this.setupValidationRules();

            // Initialisation des composants
            this.initializeComponents();

            // Attachement des événements
            this.attachEventListeners();

            // Configuration des observateurs
            this.setupObservers();

            console.log('✅ Système de vente initialisé avec succès');

        } catch (error) {
            console.error('❌ Erreur lors de la configuration:', error);
            this.showError('Erreur de configuration du système');
        }
    }

    /**
     * Récupération du token CSRF
     */
    async fetchCSRFToken() {
        try {
            const response = await fetch(TOMBOLA_CONFIG.ENDPOINTS.CSRF, {
                method: 'GET',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }

            const data = await response.json();
            this.csrfToken = data.token;

            // Mise à jour du champ caché
            const csrfInput = document.getElementById('csrf_token');
            if (csrfInput) {
                csrfInput.value = this.csrfToken;
            }

        } catch (error) {
            console.error('❌ Erreur CSRF:', error);
            throw new Error('Impossible de récupérer le token de sécurité');
        }
    }

    /**
     * Configuration des règles de validation
     */
    setupValidationRules() {
        this.validationRules = {
            seller_name: {
                required: true,
                minLength: 2,
                maxLength: 100,
                pattern: /^[a-zA-ZÀ-ÿ\s\-']+$/
            },
            seller_email: {
                required: true,
                pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/
            },
            seller_phone: {
                required: true,
                pattern: /^(?:(?:\+|00)33|0)\s*[1-9](?:[\s.-]*\d{2}){4}$/
            },
            item_name: {
                required: true,
                minLength: 3,
                maxLength: 200
            },
            item_description: {
                required: true,
                minLength: 10,
                maxLength: TOMBOLA_CONFIG.MAX_DESCRIPTION_LENGTH
            },
            ticket_price: {
                required: true,
                min: TOMBOLA_CONFIG.MIN_TICKET_PRICE,
                max: TOMBOLA_CONFIG.MAX_TICKET_PRICE,
                pattern: /^\d+(\.\d{1,2})?$/
            },
            ticket_quantity: {
                required: true,
                min: 1,
                max: 10000,
                pattern: /^\d+$/
            }
        };
    }

    /**
     * Initialisation des composants
     */
    initializeComponents() {
        // Initialisation de l'éditeur de texte riche
        if (typeof TextEditor !== 'undefined') {
            this.textEditor = new TextEditor('item_description');
        }

        // Initialisation de l'uploader d'images
        if (typeof ImageUploader !== 'undefined') {
            this.imageUploader = new ImageUploader('image-upload-zone', {
                maxFiles: TOMBOLA_CONFIG.MAX_IMAGES,
                maxSize: TOMBOLA_CONFIG.MAX_IMAGE_SIZE,
                allowedTypes: TOMBOLA_CONFIG.ALLOWED_FORMATS,
                onUpload: (files) => this.handleImageUpload(files),
                onRemove: (index) => this.handleImageRemove(index)
            });
        }

        // Initialisation des calculateurs
        this.initializeCalculators();

        // Initialisation des indicateurs de progression
        this.initializeProgressIndicators();

        // Initialisation des tooltips
        this.initializeTooltips();
    }

    /**
     * Initialisation des calculateurs automatiques
     */
    initializeCalculators() {
        const priceInput = document.getElementById('ticket_price');
        const quantityInput = document.getElementById('ticket_quantity');
        const totalDisplay = document.getElementById('total_value');

        if (priceInput && quantityInput && totalDisplay) {
            const updateTotal = () => {
                const price = parseFloat(priceInput.value) || 0;
                const quantity = parseInt(quantityInput.value) || 0;
                const total = price * quantity;

                totalDisplay.textContent = formatPrice(total);
                totalDisplay.classList.toggle('highlight', total > 0);

                // Animation du total
                if (total > 0) {
                    totalDisplay.classList.add('pulse');
                    setTimeout(() => totalDisplay.classList.remove('pulse'), 300);
                }
            };

            priceInput.addEventListener('input', debounce(updateTotal, 300));
            quantityInput.addEventListener('input', debounce(updateTotal, 300));

            // Calcul initial
            updateTotal();
        }
    }

    /**
     * Initialisation des indicateurs de progression
     */
    initializeProgressIndicators() {
        // Barre de progression du formulaire
        this.updateFormProgress();

        // Compteur de caractères pour la description
        const descriptionField = document.getElementById('item_description');
        const counterElement = document.getElementById('description-counter');

        if (descriptionField && counterElement) {
            const updateCounter = () => {
                const length = descriptionField.value.length;
                const maxLength = TOMBOLA_CONFIG.MAX_DESCRIPTION_LENGTH;
                const percentage = (length / maxLength) * 100;

                counterElement.textContent = `${length}/${maxLength}`;
                counterElement.className = 'character-counter';

                if (percentage > 90) {
                    counterElement.classList.add('danger');
                } else if (percentage > 75) {
                    counterElement.classList.add('warning');
                }
            };

            descriptionField.addEventListener('input', updateCounter);
            updateCounter();
        }
    }

    /**
     * Initialisation des tooltips
     */
    initializeTooltips() {
        const tooltipElements = document.querySelectorAll('[data-tooltip]');

        tooltipElements.forEach(element => {
            element.addEventListener('mouseenter', (e) => {
                this.showTooltip(e.target, e.target.dataset.tooltip);
            });

            element.addEventListener('mouseleave', () => {
                this.hideTooltip();
            });
        });
    }

    /**
     * Affichage d'un tooltip
     */
    showTooltip(element, text) {
        const tooltip = document.createElement('div');
        tooltip.className = 'tooltip';
        tooltip.textContent = text;
        tooltip.id = 'active-tooltip';

        document.body.appendChild(tooltip);

        const rect = element.getBoundingClientRect();
        tooltip.style.left = rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2) + 'px';
        tooltip.style.top = rect.top - tooltip.offsetHeight - 10 + 'px';

        setTimeout(() => tooltip.classList.add('show'), 100);
    }

    /**
     * Masquage du tooltip
     */
    hideTooltip() {
        const tooltip = document.getElementById('active-tooltip');
        if (tooltip) {
            tooltip.classList.remove('show');
            setTimeout(() => tooltip.remove(), 200);
        }
    }
}

// ===== GESTIONNAIRE D'ÉVÉNEMENTS GLOBAUX =====

/**
 * Gestion des erreurs JavaScript globales
 */
window.addEventListener('error', (event) => {
    console.error('❌ Erreur JavaScript:', event.error);

    // Ne pas afficher les erreurs en production
    if (window.location.hostname !== 'localhost') {
        event.preventDefault();
    }
});

/**
 * Gestion des promesses rejetées
 */
window.addEventListener('unhandledrejection', (event) => {
    console.error('❌ Promesse rejetée:', event.reason);
    event.preventDefault();
});

/**
 * Gestion de la perte de connexion
 */
window.addEventListener('offline', () => {
    document.body.classList.add('offline');
    console.warn('⚠️ Connexion perdue');
});

window.addEventListener('online', () => {
    document.body.classList.remove('offline');
    console.log('✅ Connexion rétablie');
});

// ===== INITIALISATION AUTOMATIQUE =====
let tombolaSale = null;

// Initialisation quand le DOM est prêt
document.addEventListener('DOMContentLoaded', () => {
    tombolaSale = new TombolaSaleSystem();
});

// Export pour utilisation externe
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { TombolaSaleSystem, TOMBOLA_CONFIG };
}
