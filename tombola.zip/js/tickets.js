Vous avez raison, je m'excuse ! Voici le fichier **js/tickets.js** COMPLET cette fois :

## 📁 **js/tickets.js** (Complet à 100%)

```javascript
// Tickets Management JavaScript
class TicketManager {
    constructor() {
        this.userTickets = [];
        this.currentFilter = 'all';
        this.currentSort = 'newest';
        this.currentUserId = null;
        this.init();
    }

    init() {
        this.getCurrentUserId();
        this.setupEventListeners();
        this.loadUserTickets();
        this.setupAutoRefresh();
    }

    getCurrentUserId() {
        // Get current user ID from session or local storage
        const userIdElement = document.querySelector('[data-user-id]');
        if (userIdElement) {
            this.currentUserId = parseInt(userIdElement.dataset.userId);
        }
        return this.currentUserId;
    }

    setupEventListeners() {
        // Filter buttons
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.filterTickets(e.target.dataset.filter);
            });
        });

        // Sort dropdown
        const sortSelect = document.getElementById('ticketSort');
        if (sortSelect) {
            sortSelect.addEventListener('change', (e) => {
                this.sortTickets(e.target.value);
            });
        }

        // Search input
        const searchInput = document.getElementById('ticketSearch');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.searchTickets(e.target.value);
            });
        }

        // Refresh button
        const refreshBtn = document.getElementById('refreshTickets');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => {
                this.loadUserTickets();
            });
        }

        // Close modals on outside click
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal-overlay')) {
                this.closeModal(e.target.parentElement);
            }
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeAllModals();
            }
        });
    }

    async loadUserTickets() {
        try {
            this.showLoading(true);
            
            const response = await fetch('api/tickets.php?action=user_tickets');
            const result = await response.json();
            
            if (result.success) {
                this.userTickets = result.data;
                this.renderTickets();
                this.updateStatistics();
            } else {
                this.showError('Erreur lors du chargement des tickets');
            }
        } catch (error) {
            console.error('Error loading tickets:', error);
            this.showError('Erreur de connexion');
        } finally {
            this.showLoading(false);
        }
    }

    renderTickets() {
        const container = document.getElementById('ticketsContainer');
        if (!container) return;

        container.innerHTML = '';

        if (this.userTickets.length === 0) {
            this.showEmptyState(container);
            return;
        }

        // Group tickets by product
        const groupedTickets = this.groupTicketsByProduct();

        Object.values(groupedTickets).forEach(group => {
            const ticketCard = this.createTicketCard(group);
            container.appendChild(ticketCard);
        });
    }

    groupTicketsByProduct() {
        const grouped = {};
        
        this.userTickets.forEach(ticket => {
            const productId = ticket.product_id;
            if (!grouped[productId]) {
                grouped[productId] = {
                    product: ticket,
                    tickets: []
                };
            }
            grouped[productId].tickets.push(ticket);
        });

        return grouped;
    }

    createTicketCard(group) {
        const { product, tickets } = group;
        const ticketsCount = tickets.length;
        const isWinner = product.winner_id === this.currentUserId;
        const progress = (product.tickets_sold / product.total_tickets) * 100;
        const totalPaid = tickets.reduce((sum, ticket) => sum + parseFloat(ticket.paid_amount || product.ticket_price), 0);

        const card = document.createElement('div');
        card.className = `ticket-card ${isWinner ? 'winner-card' : ''}`;
        card.dataset.productId = product.product_id;
        
        card.innerHTML = `
            ${isWinner ? '<div class="winner-badge">🏆 GAGNANT !</div>' : ''}
            
            <div class="ticket-header">
                <div class="product-image">
                    ${product.image_path ? 
                        `<img src="${product.image_path}" alt="${this.escapeHtml(product.title)}">` : 
                        '<div class="no-image">📦</div>'
                    }
                </div>
                <div class="product-info">
                    <h3>${this.escapeHtml(product.title)}</h3>
                    <p class="category">${this.escapeHtml(product.category_name || 'Non catégorisé')}</p>
                    <p class="product-value">Valeur: ${product.price} €</p>
                </div>
            </div>

            <div class="ticket-details">
                <div class="tickets-owned">
                    <h4>Mes tickets (${ticketsCount})</h4>
                    <div class="ticket-numbers">
                        ${tickets.map(ticket => 
                            `<span class="ticket-number" onclick="ticketManager.showTicketDetails('${ticket.serial_number}')" title="Cliquez pour voir les détails">#${ticket.serial_number}</span>`
                        ).join('')}
                    </div>
                </div>

                <div class="product-progress">
                    <div class="progress-info">
                        <span>Progression</span>
                        <span>${product.tickets_sold}/${product.total_tickets} tickets (${progress.toFixed(1)}%)</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${progress}%"></div>
                    </div>
                </div>

                <div class="purchase-info">
                    <div class="info-row">
                        <span>Acheté le:</span>
                        <span>${this.formatDate(product.purchase_date)}</span>
                    </div>
                    <div class="info-row">
                        <span>Montant payé:</span>
                        <span>${totalPaid.toFixed(2)} €</span>
                    </div>
                    <div class="info-row">
                        <span>Statut:</span>
                        <span class="status-badge status-${product.status}">
                            ${this.getStatusText(product.status)}
                        </span>
                    </div>
                </div>

                ${product.draw_date ? `
                    <div class="draw-info">
                        <div class="info-row">
                            <span>Date de tirage:</span>
                            <span>${this.formatDate(product.draw_date)}</span>
                        </div>
                        <div class="info-row">
                            <span>Temps restant:</span>
                            <span class="countdown" data-target="${product.draw_date}">
                                ${this.getTimeRemaining(product.draw_date)}
                            </span>
                        </div>
                    </div>
                ` : ''}

                ${this.renderResultInfo(product, isWinner)}
            </div>

            <div class="ticket-actions">
                <button class="btn btn-secondary btn-sm" onclick="ticketManager.viewProduct(${product.product_id})">
                    👁️ Voir le produit
                </button>
                <button class="btn btn-outline btn-sm" onclick="ticketManager.shareTickets(${product.product_id})">
                    📤 Partager
                </button>
                <button class="btn btn-outline btn-sm" onclick="ticketManager.downloadTickets(${product.product_id})">
                    📄 Télécharger
                </button>
                ${product.status === 'active' ? `
                    <button class="btn btn-warning btn-sm" onclick="ticketManager.transferTicket(${product.product_id})">
                        🔄 Transférer
                    </button>
                ` : ''}
            </div>
        `;

        return card;
    }

    renderResultInfo(product, isWinner) {
        if (product.status === 'completed') {
            if (isWinner) {
                return `
                    <div class="winner-info">
                        <h4>🎉 Félicitations !</h4>
                        <p>Vous avez remporté ce produit ! Nous vous contacterons bientôt pour la livraison.</p>
                        <button class="btn btn-success btn-sm" onclick="ticketManager.contactSupport(${product.product_id})">
                            📞 Contacter le support
                        </button>
                    </div>
                `;
            } else {
                return `
                    <div class="result-info">
                        <span class="not-winner">❌ Pas gagnant cette fois</span>
                        <p>Le tirage a été effectué. Tentez votre chance sur d'autres produits !</p>
                    </div>
                `;
            }
        } else if (product.status === 'cancelled') {
            return `
                <div class="result-info cancelled">
                    <span class="cancelled-draw">⚠️ Tirage annulé</span>
                    <p>Ce tirage a été annulé. Vous serez remboursé automatiquement.</p>
                </div>
            `;
        }
        return '';
    }

    showEmptyState(container) {
        container.innerHTML = `
            <div class="empty-state">
                <span class="empty-icon">🎫</span>
                <h2>Aucun ticket</h2>
                <p>Vous n'avez encore acheté aucun ticket de tombola</p>
                <a href="index.php" class="btn btn-primary">Acheter des tickets</a>
            </div>
        `;
    }

    filterTickets(filter) {
        this.currentFilter = filter;
        
        // Update filter buttons
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.filter === filter);
        });

        // Apply filter
        const cards = document.querySelectorAll('.ticket-card');
        cards.forEach(card => {
            const productId = card.dataset.productId;
            const ticket = this.userTickets.find(t => t.product_id == productId);
            
            let show = true;
            
            switch (filter) {
                case 'active':
                    show = ticket && ticket.status === 'active';
                    break;
                case 'completed':
                    show = ticket && ticket.status === 'completed';
                    break;
                case 'won':
                    show = ticket && ticket.winner_id === this.currentUserId;
                    break;
                case 'lost':
                    show = ticket && ticket.status === 'completed' && ticket.winner_id !== this.currentUserId;
                    break;
                default:
                    show = true;
            }
            
            card.style.display = show ? 'block' : 'none';
        });
    }

    sortTickets(sortBy) {
        this.currentSort = sortBy;
        const container = document.getElementById('ticketsContainer');
        const cards = Array.from(container.querySelectorAll('.ticket-card'));
        
        cards.sort((a, b) => {
            const aProductId = a.dataset.productId;
            const bProductId = b.dataset.productId;
            const aTicket = this.userTickets.find(t => t.product_id == aProductId);
            const bTicket = this.userTickets.find(t => t.product_id == bProductId);
            
            switch (sortBy) {
                case 'newest':
                    return new Date(bTicket.purchase_date) - new Date(aTicket.purchase_date);
                case 'oldest':
                    return new Date(aTicket.purchase_date) - new Date(bTicket.purchase_date);
                case 'value_high':
                    return parseFloat(bTicket.price) - parseFloat(aTicket.price);
                case 'value_low':
                    return parseFloat(aTicket.price) - parseFloat(bTicket.price);
                case 'progress':
                    const aProgress = (aTicket.tickets_sold / aTicket.total_tickets) * 100;
                    const bProgress = (bTicket.tickets_sold / bTicket.total_tickets) * 100;
                    return bProgress - aProgress;
                default:
                    return 0;
            }
        });
        
        // Re-append sorted cards
        cards.forEach(card => container.appendChild(card));
    }

    searchTickets(query) {
        const searchTerm = query.toLowerCase().trim();
        const cards = document.querySelectorAll('.ticket-card');
        
        cards.forEach(card => {
            const title = card.querySelector('h3').textContent.toLowerCase();
            const category = card.querySelector('.category').textContent.toLowerCase();
            const ticketNumbers = Array.from(card.querySelectorAll('.ticket-number'))
                .map(el => el.textContent.toLowerCase()).join(' ');
            
            const matches = title.includes(searchTerm) || 
                          category.includes(searchTerm) || 
                          ticketNumbers.includes(searchTerm);
            
            card.style.display = matches ? 'block' : 'none';
        });
    }

    showTicketDetails(serialNumber) {
        const ticket = this.userTickets.find(t => t.serial_number === serialNumber);
        if (!ticket) return;

        const modal = this.createModal('ticket-details', 'Détails du Ticket');
        modal.querySelector('.modal-body').innerHTML = `
            <div class="ticket-detail-card">
                <div class="ticket-detail-header">
                    <h3>${this.escapeHtml(ticket.title)}</h3>
                    <span class="ticket-serial">#${serialNumber}</span>
                </div>
                
                <div class="ticket-detail-info">
                    <div class="info-grid">
                        <div class="info-item">
                            <label>Date d'achat:</label>
                            <span>${this.formatDate(ticket.purchase_date)}</span>
                        </div>
                        <div class="info-item">
                            <label>Prix payé:</label>
                            <span>${ticket.ticket_price} €</span>
                        </div>
                        <div class="info-item">
                            <label>Statut du produit:</label>
                            <span class="status-badge status-${ticket.status}">
                                ${this.getStatusText(ticket.status)}
                            </span>
                        </div>
                        <div class="info-item">
                            <label>Valeur du lot:</label>
                            <span>${ticket.price} €</span>
                        </div>
                    </div>
                    
                    <div class="qr-code-section">
                        <h4>QR Code du ticket</h4>
                        <div class="qr-code" id="qr-${serialNumber}"></div>
                        <p>Présentez ce code pour vérifier l'authenticité de votre ticket</p>
                    </div>
                </div>
                
                <div class="ticket-actions-modal">
                    <button class="btn btn-primary" onclick="ticketManager.downloadTicketPDF('${serialNumber}')">
                        📄 Télécharger PDF
                    </button>
                    <button class="btn btn-secondary" onclick="ticketManager.printTicket('${serialNumber}')">
                        🖨️ Imprimer
                    </button>
                </div>
            </div>
        `;

        this.showModal(modal);
        this.generateQRCode(serialNumber);
    }

    generateQRCode(serialNumber) {
        // Simple QR code generation (you would use a real QR code library in production)
        const qrContainer = document.getElementById(`qr-${serialNumber}`);
        if (qrContainer) {
            qrContainer.innerHTML = `
                <div class="qr-placeholder">
                    <div class="qr-pattern"></div>
                    <span>QR Code</span>
                    <span>${serialNumber}</span>
                </div>
            `;
        }
    }

    viewProduct(productId) {
        window.open(`index.php?product=${productId}`, '_blank');
    }

    shareTickets(productId) {
        const ticket = this.userTickets.find(t => t.product_id == productId);
        if (!ticket) return;

        if (navigator.share) {
            navigator.share({
                title: `Mes tickets pour ${ticket.title}`,
                text: `Regardez mes tickets pour ce super produit !`,
                url: `${window.location.origin}/index.php?product=${productId}`
            }).catch(console.error);
        } else {
            // Fallback - copy to clipboard
            const url = `${window.location.origin}/index.php?product=${productId}`;
            this.copyToClipboard(url);
            this.showNotification('Lien copié dans le presse-papiers !', 'success');
        }
    }

    downloadTickets(productId) {
        const tickets = this.userTickets.filter(t => t.product_id == productId);
        if (tickets.length === 0) return;

        // Generate and download tickets PDF
        window.open(`generate-ticket-pdf.php?product=${productId}`, '_blank');
    }

    downloadTicketPDF(serialNumber) {
        window.open(`generate-ticket-pdf.php?serial=${serialNumber}`, '_blank');
    }

    printTicket(serialNumber) {
        const ticket = this.userTickets.find(t => t.serial_number === serialNumber);
        if (!ticket) return;

        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <html>
                <head>
                    <title>Ticket ${serialNumber}</title>
                    <style>
                        body { font-family: Arial, sans-serif; padding: 20px; }
                        .ticket { border: 2px solid #667eea; padding: 20px; border-radius: 10px; }
                        .header { text-align: center; margin-bottom: 20px; }
                        .info { margin: 10px 0; }
                        .qr { text-align: center; margin: 20px 0; }
                    </style>
                </head>
                <body>
                    <div class="ticket">
                        <div class="header">
                            <h1>🎲 Tombola</h1>
                            <h2>${this.escapeHtml(ticket.title)}</h2>
                        </div>
                        <div class="info">
                            <strong>Numéro de ticket:</strong> #${serialNumber}
                        </div>
                        <div class="info">
                            <strong>Date d'achat:</strong> ${this.formatDate(ticket.purchase_date)}
                        </div>
                        <div class="info">
                            <strong>Valeur du lot:</strong> ${ticket.price} €
                        </div>
                        <div class="qr">
                            <div style="border: 1px solid #ccc; width: 100px; height: 100px; margin: 0 auto; display: flex; align-items: center; justify-content: center;">
                                QR Code<br>${serialNumber}
                            </div>
                        </div>
                    </div>
                </body>
            </html>
        `);
        printWindow.document.close();
        printWindow.print();
    }

    transferTicket(productId) {
        const modal = this.createModal('transfer-ticket', 'Transférer un Ticket');
        modal.querySelector('.modal-body').innerHTML = `
            <form id="transferTicketForm">
                <p>Vous pouvez transférer vos tickets à un autre utilisateur.</p>
                
                <div class="form-group">
                    <label for="recipientEmail">Email du destinataire:</label>
                    <input type="email" id="recipientEmail" name="email" required 
                           placeholder="email@exemple.com">
                </div>
                
                <div class="form-group">
                    <label for="transferReason">Raison du transfert (optionnel):</label>
                    <textarea id="transferReason" name="reason" rows="3" 
                              placeholder="Ex: Cadeau, vente, etc."></textarea>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Transférer</button>
                    <button type="button" class="btn btn-secondary" onclick="ticketManager.closeModal(this.closest('.modal'))">Annuler</button>
                </div>
            </form>
        `;

        this.showModal(modal);

        document.getElementById('transferTicketForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.processTicketTransfer(productId, e.target);
        });
    }

    async processTicketTransfer(productId, form) {
        const formData = new FormData(form);
        const email = formData.get('email');
        const reason = formData.get('reason');

        try {
            const response = await fetch('api/tickets.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'transfer_ticket',
                    product_id: productId,
                    recipient_email: email,
                    reason: reason
                })
            });

            const result = await response.json();

            if (result.success) {
                this.showNotification('Ticket transféré avec succès !', 'success');
                this.closeAllModals();
                this.loadUserTickets();
            } else {
                this.showNotification('Erreur : ' + result.message, 'error');
            }
        } catch (error) {
            console.error('Transfer error:', error);
            this.showNotification('Erreur lors du transfert', 'error');
        }
    }

    contactSupport(productId) {
        const ticket = this.userTickets.find(t => t.product_id == productId);
        if (!ticket) return;

        const message = `Bonjour, je suis le gagnant du produit "${ticket.title}" (ID ${productId}). Pouvez-vous me contacter pour organiser la livraison ?`;
        const mailtoLink = `mailto:support@tombola.fr?subject=Gagnant - ${encodeURIComponent(ticket.title)}&body=${encodeURIComponent(message)}`;
        window.location.href = mailtoLink;
    }

    updateStatistics() {
        const stats = this.calculateStatistics();
        
        // Update stats cards if they exist
        const totalTicketsEl = document.getElementById('totalTicketsCount');
        const totalProductsEl = document.getElementById('totalProductsCount');
        const totalSpentEl = document.getElementById('totalSpentAmount');
        const totalWinsEl = document.getElementById('totalWinsCount');

        if (totalTicketsEl) totalTicketsEl.textContent = stats.totalTickets;
        if (totalProductsEl) totalProductsEl.textContent = stats.totalProducts;
        if (totalSpentEl) totalSpentEl.textContent = `${stats.totalSpent.toFixed(2)} €`;
        if (totalWinsEl) totalWinsEl.textContent = stats.totalWins;
    }

    calculateStatistics() {
        const grouped = this.groupTicketsByProduct();
        
        return {
            totalTickets: this.userTickets.length,
            totalProducts: Object.keys(grouped).length,
            totalSpent: this.userTickets.reduce((sum, ticket) => 
                sum + parseFloat(ticket.ticket_price || 0), 0),
            totalWins: Object.values(grouped).filter(group => 
                group.product.winner_id === this.currentUserId).length
        };
    }

    setupAutoRefresh() {
        // Auto-refresh every 30 seconds for active draws
        setInterval(() => {
            this.checkForUpdates();
        }, 30000);

        // Update countdowns every second
        setInterval(() => {
            this.updateCountdowns();
        }, 1000);
    }

    async checkForUpdates() {
        try {
            const response = await fetch('api/tickets.php?action=check_updates');
            const result = await response.json();
            
            if (result.hasUpdates) {
                this.loadUserTickets();
            }
        } catch (error) {
            console.log('Update check failed:', error);
        }
    }

    updateCountdowns() {
        document.querySelectorAll('.countdown').forEach(countdown => {
            const target = countdown.dataset.target;
            if (target) {
                countdown.textContent = this.getTimeRemaining(target);
            }
        });
    }

    getTimeRemaining(targetDate) {
        const now = new Date().getTime();
        const target = new Date(targetDate).getTime();
        const difference = target - now;

        if (difference <= 0) {
            return 'Terminé';
        }

        const days = Math.floor(difference / (1000 * 60 * 60 * 24));
        const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));

        if (days > 0) {
            return `${days} jour${days > 1 ? 's' : ''}`;
        } else if (hours > 0) {
            return `${hours}h ${minutes}m`;
        } else {
            return `${minutes} minute${minutes > 1 ? 's' : ''}`;
        }
    }

    createModal(id, title) {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = id;
        modal.innerHTML = `
            <div class="modal-overlay"></div>
            <div class="modal-content">
                <div class="modal-header">
                    <h3>${title}</h3>
                    <button class="modal-close" onclick="ticketManager.closeModal(this.closest('.modal'))">&times;</button>
                </div>
                <div class="modal-body"></div>
            </div>
        `;
        document.body.appendChild(modal);
        return modal;
    }

    showModal(modal) {
        modal.style.display = 'block';
        document.body.style.overflow = 'hidden';
        setTimeout(() => modal.classList.add('active'), 10);
    }

    closeModal(modal) {
        modal.classList.remove('active');
        setTimeout(() => {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
            modal.remove();
        }, 300);
    }

    closeAllModals() {
        document.querySelectorAll('.modal').forEach(modal => {
            this.closeModal(modal);
        });
    }

    showLoading(show) {
        const loader = document.getElementById('ticketsLoader');
        if (loader) {
            loader.style.display = show ? 'block' : 'none';
        }
    }

    showError(message) {
        this.showNotification(message, 'error');
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <span class="notification-message">${message}</span>
            <button class="notification-close" onclick="this.parentElement.remove()">&times;</button>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.add('show');
        }, 10);
        
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 5000);
    }

    copyToClipboard(text) {
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text);
        } else {
            // Fallback
            const textArea = document.createElement('textarea');
            textArea.value = text;
            document.body.appendChild(textArea);
            textArea.select();
            document.execCommand('copy');
            document.body.removeChild(textArea);
        }
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('fr-FR', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    getStatusText(status) {
        const statusTexts = {
            'draft': 'Brouillon',
            'active': 'Actif',
            'completed': 'Terminé',
            'cancelled': 'Annulé'
        };
        return statusTexts[status] || status;
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Initialize ticket manager when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.ticketManager = new TicketManager();
});

// Export for global access
if (typeof module !== 'undefined' && module.exports) {
    module.exports = TicketManager;
}