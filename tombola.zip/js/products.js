// Products management JavaScript
class ProductManager {
    constructor() {
        this.products = [];
        this.filteredProducts = [];
        this.currentFilter = 'all';
        this.currentSort = 'newest';
        this.currentPage = 1;
        this.productsPerPage = 12;
        this.init();
    }

    async init() {
        await this.loadProducts();
        this.setupEventListeners();
        this.renderProducts();
    }

    async loadProducts() {
        try {
            const response = await fetch('api/products.php?action=list');
            const data = await response.json();
            
            this.products = data;
            this.filteredProducts = [...this.products];
            window.products = this.products; // For global access
            
            this.updateProductsCount();
        } catch (error) {
            console.error('Error loading products:', error);
        }
    }

    setupEventListeners() {
        // Search
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.searchProducts(e.target.value);
            });
        }

        // Filter buttons
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                this.filterProducts(e.target.dataset.filter);
            });
        });

        // Sort dropdown
        const sortSelect = document.getElementById('sortSelect');
        if (sortSelect) {
            sortSelect.addEventListener('change', (e) => {
                this.sortProducts(e.target.value);
            });
        }

        // Pagination
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('pagination-btn')) {
                const page = parseInt(e.target.dataset.page);
                this.goToPage(page);
            }
        });
    }

    searchProducts(query) {
        const searchQuery = query.toLowerCase().trim();
        
        if (searchQuery === '') {
            this.filteredProducts = [...this.products];
        } else {
            this.filteredProducts = this.products.filter(product => 
                product.title.toLowerCase().includes(searchQuery) ||
                product.description.toLowerCase().includes(searchQuery)
            );
        }
        
        this.currentPage = 1;
        this.renderProducts();
        this.updateProductsCount();
    }

    filterProducts(filter) {
        this.currentFilter = filter;
        
        switch (filter) {
            case 'all':
                this.filteredProducts = [...this.products];
                break;
            case 'almost_sold':
                this.filteredProducts = this.products.filter(p => 
                    (p.tickets_sold / p.total_tickets) >= 0.85
                );
                break;
            case 'new':
                this.filteredProducts = this.products.filter(p => 
                    this.isNewProduct(p.created_at)
                );
                break;
            default:
                // Category filter
                this.filteredProducts = this.products.filter(p => 
                    p.category_id == filter
                );
        }
        
        this.currentPage = 1;
        this.sortProducts(this.currentSort);
        this.renderProducts();
        this.updateFilterUI();
        this.updateProductsCount();
    }

    sortProducts(sort) {
        this.currentSort = sort;
        
        switch (sort) {
            case 'newest':
                this.filteredProducts.sort((a, b) => 
                    new Date(b.created_at) - new Date(a.created_at)
                );
                break;
            case 'oldest':
                this.filteredProducts.sort((a, b) => 
                    new Date(a.created_at) - new Date(b.created_at)
                );
                break;
            case 'price_low':
                this.filteredProducts.sort((a, b) => 
                    a.ticket_price - b.ticket_price
                );
                break;
            case 'price_high':
                this.filteredProducts.sort((a, b) => 
                    b.ticket_price - a.ticket_price
                );
                break;
            case 'popularity':
                this.filteredProducts.sort((a, b) => 
                    b.tickets_sold - a.tickets_sold
                );
                break;
            case 'ending_soon':
                this.filteredProducts.sort((a, b) => {
                    const aRemaining = a.total_tickets - a.tickets_sold;
                    const bRemaining = b.total_tickets - b.tickets_sold;
                    return aRemaining - bRemaining;
                });
                break;
        }
        
        this.renderProducts();
    }

    renderProducts() {
        const productsGrid = document.getElementById('productsGrid');
        if (!productsGrid) return;

        // Calculate pagination
        const startIndex = (this.currentPage - 1) * this.productsPerPage;
        const endIndex = startIndex + this.productsPerPage;
        const paginatedProducts = this.filteredProducts.slice(startIndex, endIndex);

        // Clear grid
        productsGrid.innerHTML = '';

        // Render products
        paginatedProducts.forEach(product => {
            const productCard = this.createProductCard(product);
            productsGrid.appendChild(productCard);
        });

        // Update pagination
        this.renderPagination();
    }

    createProductCard(product) {
        const card = document.createElement('div');
        card.className = 'product-card';
        
        const ticketsLeft = product.total_tickets - product.tickets_sold;
        const percentage = (product.tickets_sold / product.total_tickets) * 100;
        
        // Status badges
        let badges = '';
        if (percentage >= 85) {
            badges += '<span class="badge hot">🔥 Presque épuisé</span>';
        }
        if (this.isNewProduct(product.created_at)) {
            badges += '<span class="badge new">✨ Nouveau</span>';
        }
        if (product.status === 'featured') {
            badges += '<span class="badge featured">⭐ Mis en avant</span>';
        }

        card.innerHTML = `
            <div class="product-image">
                ${product.main_image ? 
                    `<img src="${product.main_image}" alt="${product.title}" loading="lazy">` : 
                    '<div class="no-image">📦<br>Aucune image</div>'
                }
                <div class="product-badges">${badges}</div>
            </div>
            <div class="product-info">
                <div class="product-category">
                    <span class="category-icon">${this.getCategoryIcon(product.category_id)}</span>
                    <span class="category-name">${this.getCategoryName(product.category_id)}</span>
                </div>
                <h3 class="product-title">${product.title}</h3>
                <p class="product-description">${this.truncateText(product.description, 100)}</p>
                <div class="product-price">
                    <span class="main-price">${product.price} €</span>
                    <span class="ticket-price">Ticket: ${product.ticket_price} €</span>
                </div>
                <div class="product-progress">
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${percentage}%"></div>
                    </div>
                    <span class="progress-text">${product.tickets_sold}/${product.total_tickets} tickets</span>
                </div>
                <div class="product-actions">
                    <button onclick="openBuyModal(${product.product_id})" class="btn btn-primary btn-buy">
                        <span class="btn-icon">🎫</span>
                        Acheter un ticket
                    </button>
                    <button onclick="productManager.toggleFavorite(${product.product_id})" class="btn btn-secondary btn-favorite">
                        <span class="btn-icon">❤️</span>
                    </button>
                </div>
            </div>
        `;
        
        return card;
    }

    renderPagination() {
        const paginationContainer = document.getElementById('pagination');
        if (!paginationContainer) return;

        const totalPages = Math.ceil(this.filteredProducts.length / this.productsPerPage);
        
        if (totalPages <= 1) {
            paginationContainer.innerHTML = '';
            return;
        }

        let paginationHTML = '';
        
        // Previous button
        if (this.currentPage > 1) {
            paginationHTML += `<button class="pagination-btn" data-page="${this.currentPage - 1}">‹ Précédent</button>`;
        }

        // Page numbers
        for (let i = 1; i <= totalPages; i++) {
            if (i === this.currentPage) {
                paginationHTML += `<button class="pagination-btn active" data-page="${i}">${i}</button>`;
            } else if (i === 1 || i === totalPages || (i >= this.currentPage - 2 && i <= this.currentPage + 2)) {
                paginationHTML += `<button class="pagination-btn" data-page="${i}">${i}</button>`;
            } else if (i === this.currentPage - 3 || i === this.currentPage + 3) {
                paginationHTML += `<span class="pagination-dots">...</span>`;
            }
        }

        // Next button
        if (this.currentPage < totalPages) {
            paginationHTML += `<button class="pagination-btn" data-page="${this.currentPage + 1}">Suivant ›</button>`;
        }

        paginationContainer.innerHTML = paginationHTML;
    }

    goToPage(page) {
        this.currentPage = page;
        this.renderProducts();
        
        // Scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    updateFilterUI() {
        const filterButtons = document.querySelectorAll('.filter-btn');
        filterButtons.forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.filter === this.currentFilter) {
                btn.classList.add('active');
            }
        });
    }

    updateProductsCount() {
        const countElement = document.getElementById('productsCount');
        if (countElement) {
            countElement.textContent = `${this.filteredProducts.length} produit${this.filteredProducts.length !== 1 ? 's' : ''}`;
        }
    }

    isNewProduct(createdAt) {
        const created = new Date(createdAt);
        const now = new Date();
        const diffTime = Math.abs(now - created);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        return diffDays <= 7;
    }

    getCategoryIcon(categoryId) {
        const icons = {
            1: '📱', // Électronique
            2: '👕', // Mode
            3: '🏠', // Maison
            4: '⚽', // Sport
            5: '🎮', // Jeux
            6: '📦'  // Autres
        };
        return icons[categoryId] || '📦';
    }

    getCategoryName(categoryId) {
        const names = {
            1: 'Électronique',
            2: 'Mode',
            3: 'Maison',
            4: 'Sport',
            5: 'Jeux',
            6: 'Autres'
        };
        return names[categoryId] || 'Autres';
    }

    truncateText(text, maxLength) {
        if (text.length <= maxLength) return text;
        return text.substring(0, maxLength) + '...';
    }

    toggleFavorite(productId) {
        // Implementation for favorite functionality
        console.log('Toggle favorite for product:', productId);
        // This would typically save to localStorage or send to server
    }

    async refreshProducts() {
        await this.loadProducts();
        this.renderProducts();
    }
}

// Initialize product manager
const productManager = new ProductManager();

// Global functions
window.loadProducts = () => productManager.refreshProducts();
