// Authentication JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    // Register form
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }
});

// Handle login
async function handleLogin(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const loginData = {
        action: 'login',
        email: formData.get('email'),
        password: formData.get('password'),
        remember: formData.get('remember') ? true : false
    };

    try {
        const response = await fetch('auth.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(loginData)
        });

        const data = await response.json();
        
        if (data.success) {
            // Store token
            localStorage.setItem('userToken', data.token);
            if (data.user.is_admin) {
                localStorage.setItem('adminToken', data.token);
                window.location.href = 'admin.html';
            } else {
                window.location.href = 'index.html';
            }
        } else {
            showError(data.message || 'Erreur de connexion');
        }
    } catch (error) {
        console.error('Login error:', error);
        showError('Erreur de connexion au serveur');
    }
}

// Handle register
async function handleRegister(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const password = formData.get('password');
    const confirmPassword = formData.get('confirm_password');
    
    if (password !== confirmPassword) {
        showError('Les mots de passe ne correspondent pas');
        return;
    }

    const registerData = {
        action: 'register',
        username: formData.get('username'),
        email: formData.get('email'),
        password: password
    };

    try {
        const response = await fetch('auth.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(registerData)
        });

        const data = await response.json();
        
        if (data.success) {
            showSuccess('Compte créé avec succès ! Vous pouvez maintenant vous connecter.');
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 2000);
        } else {
            showError(data.message || 'Erreur lors de la création du compte');
        }
    } catch (error) {
        console.error('Register error:', error);
        showError('Erreur de connexion au serveur');
    }
}

// Toggle password visibility
function togglePassword() {
    const passwordInput = document.getElementById('password');
    const toggleButton = document.querySelector('.password-toggle');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleButton.textContent = '🙈';
    } else {
        passwordInput.type = 'password';
        toggleButton.textContent = '👁️';
    }
}

// Check if user is logged in
function isLoggedIn() {
    return localStorage.getItem('userToken') !== null;
}

// Check if user is admin
function isAdmin() {
    return localStorage.getItem('adminToken') !== null;
}

// Get current user
async function getCurrentUser() {
    const token = localStorage.getItem('userToken');
    if (!token) return null;

    try {
        const response = await fetch('auth.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'get_current_user',
                token: token
            })
        });

        const data = await response.json();
        return data.success ? data.user : null;
    } catch (error) {
        console.error('Error getting current user:', error);
        return null;
    }
}

// Logout
function logout() {
    localStorage.removeItem('userToken');
    localStorage.removeItem('adminToken');
    window.location.href = 'index.html';
}

// Show error message
function showError(message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'alert alert-error';
    errorDiv.textContent = message;
    
    const form = document.querySelector('.auth-form');
    form.insertBefore(errorDiv, form.firstChild);
    
    setTimeout(() => {
        errorDiv.remove();
    }, 5000);
}

// Show success message
function showSuccess(message) {
    const successDiv = document.createElement('div');
    successDiv.className = 'alert alert-success';
    successDiv.textContent = message;
    
    const form = document.querySelector('.auth-form');
    form.insertBefore(successDiv, form.firstChild);
    
    setTimeout(() => {
        successDiv.remove();
    }, 5000);
}
