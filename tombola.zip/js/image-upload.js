/**
 * SYSTÈME D'UPLOAD D'IMAGES MODERNE - JavaScript
 * Version 2.0 - 2024
 * 
 * Fonctionnalités:
 * - Drag & Drop intuitif
 * - Prévisualisation en temps réel
 * - Validation des fichiers
 * - Redimensionnement automatique
 * - Compression d'images
 * - Upload progressif
 * - Gestion des erreurs
 * - Interface responsive
 * - Support multi-formats
 * - Métadonnées EXIF
 */

'use strict';

// ===== CONFIGURATION GLOBALE =====

const IMAGE_UPLOAD_CONFIG = {
    // Limites de fichiers
    MAX_FILES: 5,
    MAX_FILE_SIZE: 5 * 1024 * 1024, // 5MB
    MIN_FILE_SIZE: 1024, // 1KB
    
    // Formats supportés
    ALLOWED_TYPES: [
        'image/jpeg',
        'image/jpg',
        'image/png',
        'image/webp',
        'image/gif'
    ],
    
    // Dimensions d'images
    MAX_WIDTH: 1920,
    MAX_HEIGHT: 1080,
    THUMBNAIL_SIZE: 150,
    PREVIEW_SIZE: 300,
    
    // Qualité de compression
    JPEG_QUALITY: 0.85,
    WEBP_QUALITY: 0.80,
    
    // URLs des endpoints
    ENDPOINTS: {
        UPLOAD: 'image_processor.php',
        DELETE: 'delete_image.php',
        ROTATE: 'rotate_image.php'
    },
    
    // Messages
    MESSAGES: {
        DRAG_DROP: 'Glissez-déposez vos images ici ou cliquez pour sélectionner',
        DRAG_OVER: 'Relâchez pour ajouter les images',
        PROCESSING: 'Traitement en cours...',
        UPLOAD_SUCCESS: 'Image uploadée avec succès',
        UPLOAD_ERROR: 'Erreur lors de l\'upload',
        FILE_TOO_LARGE: 'Fichier trop volumineux (max {size})',
        FILE_TOO_SMALL: 'Fichier trop petit (min {size})',
        INVALID_TYPE: 'Type de fichier non supporté',
        TOO_MANY_FILES: 'Trop de fichiers (max {count})',
        DIMENSION_ERROR: 'Dimensions d\'image non supportées',
        NETWORK_ERROR: 'Erreur de connexion',
        COMPRESSION_ERROR: 'Erreur de compression'
    }
};

// ===== CLASSE PRINCIPALE D'UPLOAD D'IMAGES =====

class ImageUploader {
    constructor(containerId, options = {}) {
        this.containerId = containerId;
        this.container = document.getElementById(containerId);
        
        if (!this.container) {
            throw new Error(`Container avec l'ID '${containerId}' non trouvé`);
        }
        
        // Configuration avec options par défaut
        this.config = {
            maxFiles: options.maxFiles || IMAGE_UPLOAD_CONFIG.MAX_FILES,
            maxSize: options.maxSize || IMAGE_UPLOAD_CONFIG.MAX_FILE_SIZE,
            minSize: options.minSize || IMAGE_UPLOAD_CONFIG.MIN_FILE_SIZE,
            allowedTypes: options.allowedTypes || IMAGE_UPLOAD_CONFIG.ALLOWED_TYPES,
            maxWidth: options.maxWidth || IMAGE_UPLOAD_CONFIG.MAX_WIDTH,
            maxHeight: options.maxHeight || IMAGE_UPLOAD_CONFIG.MAX_HEIGHT,
            quality: options.quality || IMAGE_UPLOAD_CONFIG.JPEG_QUALITY,
            autoUpload: options.autoUpload !== false,
            enableCompression: options.enableCompression !== false,
            enableResize: options.enableResize !== false,
            showPreview: options.showPreview !== false,
            enableRotation: options.enableRotation !== false,
            enableCrop: options.enableCrop !== false,
            multiple: options.multiple !== false
        };
        
        // Callbacks
        this.callbacks = {
            onFileSelect: options.onFileSelect || null,
            onUploadStart: options.onUploadStart || null,
            onUploadProgress: options.onUploadProgress || null,
            onUploadSuccess: options.onUploadSuccess || null,
            onUploadError: options.onUploadError || null,
            onFileRemove: options.onFileRemove || null,
            onValidationError: options.onValidationError || null
        };
        
        // État interne
        this.files = [];
        this.uploadQueue = [];
        this.isUploading = false;
        this.dragCounter = 0;
        
        // Éléments DOM
        this.dropZone = null;
        this.fileInput = null;
        this.previewContainer = null;
        this.progressContainer = null;
        
        // Initialisation
        this.init();
    }

    // ===== INITIALISATION =====
    
    init() {
        try {
            this.createInterface();
            this.attachEventListeners();
            this.setupDragAndDrop();
            
            console.log('✅ ImageUploader initialisé pour:', this.containerId);
            
        } catch (error) {
            console.error('❌ Erreur initialisation ImageUploader:', error);
            throw error;
        }
    }

    createInterface() {
        // Structure HTML de l'uploader
        this.container.innerHTML = `
            <div class="image-uploader">
                <div class="upload-drop-zone" id="${this.containerId}-drop-zone">
                    <div class="drop-zone-content">
                        <div class="drop-zone-icon">
                            <i class="fas fa-cloud-upload-alt"></i>
                        </div>
                        <div class="drop-zone-text">
                            <p class="drop-zone-title">${IMAGE_UPLOAD_CONFIG.MESSAGES.DRAG_DROP}</p>
                            <p class="drop-zone-subtitle">Formats supportés: JPG, PNG, WebP, GIF</p>
                            <p class="drop-zone-limits">Max ${this.config.maxFiles} fichiers • Max ${this.formatFileSize(this.config.maxSize)} par fichier</p>
                        </div>
                        <button type="button" class="upload-browse-btn">
                            <i class="fas fa-folder-open"></i>
                            Parcourir les fichiers
                        </button>
                    </div>
                </div>
                
                <input type="file" 
                       id="${this.containerId}-file-input" 
                       class="upload-file-input" 
                       accept="${this.config.allowedTypes.join(',')}" 
                       ${this.config.multiple ? 'multiple' : ''} 
                       style="display: none;">
                
                <div class="upload-progress-container" id="${this.containerId}-progress" style="display: none;">
                    <div class="upload-progress-bar">
                        <div class="upload-progress-fill"></div>
                    </div>
                    <div class="upload-progress-text">0%</div>
                </div>
                
                <div class="upload-preview-container" id="${this.containerId}-preview">
                    <!-- Les aperçus d'images seront ajoutés ici -->
                </div>
                
                <div class="upload-actions" id="${this.containerId}-actions" style="display: none;">
                    <button type="button" class="upload-action-btn upload-all-btn">
                        <i class="fas fa-upload"></i>
                        Uploader tout
                    </button>
                    <button type="button" class="upload-action-btn clear-all-btn">
                        <i class="fas fa-trash"></i>
                        Tout supprimer
                    </button>
                </div>
            </div>
        `;
        
        // Récupération des éléments DOM
        this.dropZone = document.getElementById(`${this.containerId}-drop-zone`);
        this.fileInput = document.getElementById(`${this.containerId}-file-input`);
        this.previewContainer = document.getElementById(`${this.containerId}-preview`);
        this.progressContainer = document.getElementById(`${this.containerId}-progress`);
        this.actionsContainer = document.getElementById(`${this.containerId}-actions`);
    }

    attachEventListeners() {
        // Clic sur la zone de drop
        this.dropZone.addEventListener('click', () => {
            this.fileInput.click();
        });
        
        // Clic sur le bouton parcourir
        const browseBtn = this.container.querySelector('.upload-browse-btn');
        browseBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.fileInput.click();
        });
        
        // Changement de fichier
        this.fileInput.addEventListener('change', (e) => {
            this.handleFileSelect(e.target.files);
        });
        
        // Boutons d'action
        const uploadAllBtn = this.container.querySelector('.upload-all-btn');
        const clearAllBtn = this.container.querySelector('.clear-all-btn');
        
        uploadAllBtn.addEventListener('click', () => {
            this.uploadAll();
        });
        
        clearAllBtn.addEventListener('click', () => {
            this.clearAll();
        });
    }

    setupDragAndDrop() {
        // Prévention du comportement par défaut
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            this.dropZone.addEventListener(eventName, this.preventDefaults, false);
            document.body.addEventListener(eventName, this.preventDefaults, false);
        });
        
        // Événements de drag
        ['dragenter', 'dragover'].forEach(eventName => {
            this.dropZone.addEventListener(eventName, () => {
                this.handleDragEnter();
            }, false);
        });
        
        ['dragleave', 'dragend'].forEach(eventName => {
            this.dropZone.addEventListener(eventName, () => {
                this.handleDragLeave();
            }, false);
        });
        
        // Événement de drop
        this.dropZone.addEventListener('drop', (e) => {
            this.handleDrop(e);
        }, false);
    }

    // ===== GESTION DU DRAG & DROP =====
    
    preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    handleDragEnter() {
        this.dragCounter++;
        this.dropZone.classList.add('drag-over');
        
        const titleElement = this.dropZone.querySelector('.drop-zone-title');
        if (titleElement) {
            titleElement.textContent = IMAGE_UPLOAD_CONFIG.MESSAGES.DRAG_OVER;
        }
    }

    handleDragLeave() {
        this.dragCounter--;
        
        if (this.dragCounter === 0) {
            this.dropZone.classList.remove('drag-over');
            
            const titleElement = this.dropZone.querySelector('.drop-zone-title');
            if (titleElement) {
                titleElement.textContent = IMAGE_UPLOAD_CONFIG.MESSAGES.DRAG_DROP;
            }
        }
    }

    handleDrop(e) {
        this.dragCounter = 0;
        this.dropZone.classList.remove('drag-over');
        
        const titleElement = this.dropZone.querySelector('.drop-zone-title');
        if (titleElement) {
            titleElement.textContent = IMAGE_UPLOAD_CONFIG.MESSAGES.DRAG_DROP;
        }
        
        const files = e.dataTransfer.files;
        this.handleFileSelect(files);
    }

    // ===== GESTION DES FICHIERS =====
    
    async handleFileSelect(fileList) {
        const files = Array.from(fileList);
        
        if (files.length === 0) return;
        
        // Vérification du nombre de fichiers
        if (this.files.length + files.length > this.config.maxFiles) {
            this.showError(
                IMAGE_UPLOAD_CONFIG.MESSAGES.TOO_MANY_FILES
                    .replace('{count}', this.config.maxFiles)
            );
            return;
        }
        
        // Traitement de chaque fichier
        for (const file of files) {
            try {
                const processedFile = await this.processFile(file);
                if (processedFile) {
                    this.files.push(processedFile);
                    this.createPreview(processedFile);
                    
                    // Callback de sélection
                    if (this.callbacks.onFileSelect) {
                        this.callbacks.onFileSelect(processedFile, this.files);
                    }
                    
                    // Upload automatique si activé
                    if (this.config.autoUpload) {
                        this.uploadFile(processedFile);
                    }
                }
            } catch (error) {
                console.error('❌ Erreur traitement fichier:', error);
                this.showError(`Erreur avec ${file.name}: ${error.message}`);
            }
        }
        
        this.updateInterface();
    }

    async processFile(file) {
        // Validation du fichier
        const validation = this.validateFile(file);
        if (!validation.valid) {
            if (this.callbacks.onValidationError) {
                this.callbacks.onValidationError(validation.error, file);
            }
            throw new Error(validation.error);
        }
        
        // Création de l'objet fichier enrichi
        const processedFile = {
            id: this.generateFileId(),
            originalFile: file,
            name: file.name,
            size: file.size,
            type: file.type,
            lastModified: file.lastModified,
            status: 'pending',
            progress: 0,
            error: null,
            preview: null,
            thumbnail: null,
            metadata: {},
            processedFile: null
        };
        
        try {
            // Génération des aperçus
            processedFile.preview = await this.createImagePreview(file, IMAGE_UPLOAD_CONFIG.PREVIEW_SIZE);
            processedFile.thumbnail = await this.createImagePreview(file, IMAGE_UPLOAD_CONFIG.THUMBNAIL_SIZE);
            
            // Extraction des métadonnées
            processedFile.metadata = await this.extractMetadata(file);
            
            // Traitement de l'image (redimensionnement/compression)
            if (this.config.enableResize || this.config.enableCompression) {
                processedFile.processedFile = await this.processImage(file, processedFile.metadata);
            } else {
                processedFile.processedFile = file;
            }
            
            processedFile.status = 'processed';
            return processedFile;
            
        } catch (error) {
            processedFile.status = 'error';
            processedFile.error = error.message;
            throw error;
        }
    }

    validateFile(file) {
        // Vérification du type
        if (!this.config.allowedTypes.includes(file.type)) {
            return {
                valid: false,
                error: IMAGE_UPLOAD_CONFIG.MESSAGES.INVALID_TYPE
            };
        }
        
        // Vérification de la taille
        if (file.size > this.config.maxSize) {
            return {
                valid: false,
                error: IMAGE_UPLOAD_CONFIG.MESSAGES.FILE_TOO_LARGE
                    .replace('{size}', this.formatFileSize(this.config.maxSize))
            };
        }
        
        if (file.size < this.config.minSize) {
            return {
                valid: false,
                error: IMAGE_UPLOAD_CONFIG.MESSAGES.FILE_TOO_SMALL
                    .replace('{size}', this.formatFileSize(this.config.minSize))
            };
        }
        
        return { valid: true };
    }

    // ===== TRAITEMENT D'IMAGES =====
    
    createImagePreview(file, maxSize) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            
            reader.onload = (e) => {
                const img = new Image();
                
                img.onload = () => {
                    try {
                        const canvas = document.createElement('canvas');
                        const ctx = canvas.getContext('2d');
                        
                        // Calcul des dimensions
                        const { width, height } = this.calculateDimensions(
                            img.width, img.height, maxSize, maxSize
                        );
                        
                        canvas.width = width;
                        canvas.height = height;
                        
                        // Dessin de l'image redimensionnée
                        ctx.drawImage(img, 0, 0, width, height);
                        
                        resolve(canvas.toDataURL('image/jpeg', 0.9));
                        
                    } catch (error) {
                        reject(error);
                    }
