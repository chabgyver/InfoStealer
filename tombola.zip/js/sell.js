/**
 * ===== SYSTÈME DE VENTE DE TOMBOLA - JAVASCRIPT PRINCIPAL =====
 * 
 * Fonctionnalités principales :
 * - Gestion complète du formulaire de vente
 * - Validation en temps réel
 * - Intégration éditeur de texte riche
 * - Upload d'images avec drag & drop
 * - Calcul automatique des tickets
 * - Protection CSRF
 * - Gestion des erreurs
 * - Interface utilisateur moderne
 * - Sauvegarde automatique
 * - Prévisualisation
 * 
 * @author Système Tombola
 * @version 2.0
 * @since 2024
 */

'use strict';

// ===== CONFIGURATION GLOBALE =====
const TOMBOLA_CONFIG = {
    // Limites et contraintes
    MAX_IMAGES: 5,
    MAX_IMAGE_SIZE: 5 * 1024 * 1024, // 5MB
    ALLOWED_FORMATS: ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'],
    MIN_TICKET_PRICE: 0.50,
    MAX_TICKET_PRICE: 1000.00,
    MAX_DESCRIPTION_LENGTH: 2000,

    // URLs des endpoints
    ENDPOINTS: {
        UPLOAD: 'image_processor.php',
        VALIDATE: 'validation.php',
        SUBMIT: 'process_sale.php',
        CSRF: 'get_csrf_token.php'
    },

    // Messages d'erreur
    MESSAGES: {
        REQUIRED_FIELD: 'Ce champ est obligatoire',
        INVALID_EMAIL: 'Adresse email invalide',
        INVALID_PHONE: 'Numéro de téléphone invalide',
        INVALID_PRICE: 'Prix invalide (entre 0.50€ et 1000€)',
        INVALID_QUANTITY: 'Quantité invalide (minimum 1)',
        FILE_TOO_LARGE: 'Fichier trop volumineux (max 5MB)',
        INVALID_FORMAT: 'Format non supporté (JPG, PNG, WebP uniquement)',
        TOO_MANY_FILES: 'Maximum 5 images autorisées',
        UPLOAD_ERROR: 'Erreur lors de l\'upload',
        NETWORK_ERROR: 'Erreur de connexion',
        SERVER_ERROR: 'Erreur serveur',
        CSRF_ERROR: 'Token de sécurité invalide'
    }
};

// ===== FONCTIONS UTILITAIRES =====

/**
 * Fonction de debounce pour limiter les appels
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Fonction de throttle pour limiter la fréquence
 */
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

/**
 * Validation d'email
 */
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

/**
 * Validation de téléphone français
 */
function isValidPhone(phone) {
    const phoneRegex = /^(?:(?:\+|00)33|0)\s*[1-9](?:[\s.-]*\d{2}){4}$/;
    return phoneRegex.test(phone);
}

/**
 * Formatage du prix
 */
function formatPrice(price) {
    return parseFloat(price).toFixed(2) + '€';
}

/**
 * Formatage de la taille de fichier
 */
function formatFileSize(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * Génération d'un ID unique
 */
function generateUniqueId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

/**
 * Sanitisation des données
 */
function sanitizeInput(input) {
    if (typeof input !== 'string') return input;
    return input.trim().replace(/[<>]/g, '');
}

/**
 * Animation smooth scroll
 */
function smoothScrollTo(element, duration = 500) {
    const targetPosition = element.offsetTop;
    const startPosition = window.pageYOffset;
    const distance = targetPosition - startPosition;
    let startTime = null;

    function animation(currentTime) {
        if (startTime === null) startTime = currentTime;
        const timeElapsed = currentTime - startTime;
        const run = ease(timeElapsed, startPosition, distance, duration);
        window.scrollTo(0, run);
        if (timeElapsed < duration) requestAnimationFrame(animation);
    }

    function ease(t, b, c, d) {
        t /= d / 2;
        if (t < 1) return c / 2 * t * t + b;
        t--;
        return -c / 2 * (t * (t - 2) - 1) + b;
    }

    requestAnimationFrame(animation);
}
