Copy// Seller Dashboard JavaScript
let currentProducts = [];
let currentSection = 'dashboard';

document.addEventListener('DOMContentLoaded', function() {
    initializeDashboard();
    setupFormHandlers();
    loadDashboardData();
});

function initializeDashboard() {
    // Setup navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const sectionId = this.getAttribute('href').substring(1);
            showSection(sectionId);
        });
    });

    // Setup image preview
    const imageInput = document.getElementById('productImages');
    if (imageInput) {
        imageInput.addEventListener('change', previewImages);
    }

    // Setup price calculation
    const ticketPriceInput = document.getElementById('ticketPrice');
    const totalTicketsInput = document.getElementById('totalTickets');
    if (ticketPriceInput && totalTicketsInput) {
        ticketPriceInput.addEventListener('input', calculateRevenue);
        totalTicketsInput.addEventListener('input', calculateRevenue);
    }
}

function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.dashboard-section').forEach(section => {
        section.classList.remove('active');
    });

    // Show selected section
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.classList.add('active');
        currentSection = sectionId;
    }

    // Update navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    
    const activeLink = document.querySelector(`[href="#${sectionId}"]`);
    if (activeLink) {
        activeLink.classList.add('active');
    }

    // Load section-specific data
    switch(sectionId) {
        case 'products':
            loadProducts();
            break;
        case 'sales':
            loadSales();
            break;
        case 'analytics':
            loadAnalytics();
            break;
    }
}

function setupFormHandlers() {
    const productForm = document.getElementById('productForm');
    if (productForm) {
        productForm.addEventListener('submit', handleProductSubmit);
    }

    // Setup drag and drop for images
    const imageInput = document.getElementById('productImages');
    if (imageInput) {
        const dropZone = imageInput.parentElement;
        
        dropZone.addEventListener('dragover', function(e) {
            e.preventDefault();
            dropZone.classList.add('drag-over');
        });

        dropZone.addEventListener('dragleave', function(e) {
            e.preventDefault();
            dropZone.classList.remove('drag-over');
        });

        dropZone.addEventListener('drop', function(e) {
            e.preventDefault();
            dropZone.classList.remove('drag-over');
            
            const files = e.dataTransfer.files;
            imageInput.files = files;
            previewImages({ target: { files: files } });
        });
    }
}

async function loadDashboardData() {
    try {
        // Load dashboard statistics
        const statsResponse = await fetch('api/products.php?action=seller_stats');
        const stats = await statsResponse.json();
        
        if (stats.success) {
            updateDashboardStats(stats.data);
        }

        // Load recent products and transactions
        await loadProducts();
        await loadRecentTransactions();
        
    } catch (error) {
        console.error('Error loading dashboard data:', error);
        showNotification('Erreur lors du chargement des données', 'error');
    }
}

function updateDashboardStats(stats) {
    // Update stat cards
    const statCards = document.querySelectorAll('.stat-card');
    if (statCards.length >= 4) {
        statCards[0].querySelector('.stat-number').textContent = stats.total_products || 0;
        statCards[0].querySelector('.stat-label').textContent = `${stats.active_products || 0} actifs`;
        
        statCards[1].querySelector('.stat-number').textContent = `${(stats.seller_earnings || 0).toFixed(2)} €`;
        
        statCards[2].querySelector('.stat-number').textContent = stats.total_sales || 0;
        
        statCards[3].querySelector('.stat-number').textContent = `${(stats.total_revenue || 0).toFixed(2)} €`;
    }
}

async function handleProductSubmit(e) {
    e.preventDefault();
    
    const submitButton = e.target.querySelector('button[type="submit"]');
    const originalText = submitButton.innerHTML;
    
    // Show loading state
    submitButton.innerHTML = '⏳ Création en cours...';
    submitButton.disabled = true;
    
    const formData = new FormData(e.target);
    
    try {
        const response = await fetch('api/products.php', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            showNotification('Produit créé avec succès !', 'success');
            resetForm();
            await loadProducts();
            showSection('products');
        } else {
            showNotification('Erreur : ' + (result.message || 'Erreur inconnue'), 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('Erreur lors de la création du produit', 'error');
    } finally {
        // Reset button state
        submitButton.innerHTML = originalText;
        submitButton.disabled = false;
    }
}

function previewImages(event) {
    const preview = document.getElementById('imagePreview');
    const files = Array.from(event.target.files);
    
    preview.innerHTML = '';
    
    if (files.length > 5) {
        showNotification('Maximum 5 images autorisées', 'warning');
        return;
    }
    
    files.forEach((file, index) => {
        if (file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const div = document.createElement('div');
                div.className = 'preview-item';
                div.innerHTML = `
                    <img src="${e.target.result}" alt="Preview ${index + 1}">
                    <button type="button" class="remove-image" onclick="removeImage(${index})">×</button>
                    ${index === 0 ? '<span class="primary-badge">Principal</span>' : ''}
                    <div class="image-info">
                        <span class="image-name">${file.name}</span>
                        <span class="image-size">${formatFileSize(file.size)}</span>
                    </div>
                `;
                preview.appendChild(div);
            };
            reader.readAsDataURL(file);
        } else {
            showNotification(`${file.name} n'est pas une image valide`, 'warning');
        }
    });
}

function removeImage(index) {
    const imageInput = document.getElementById('productImages');
    const files = Array.from(imageInput.files);
    
    // Remove file from array
    files.splice(index, 1);
    
    // Create new FileList
    const dt = new DataTransfer();
    files.forEach(file => dt.items.add(file));
    imageInput.files = dt.files;
    
    // Update preview
    previewImages({ target: { files: dt.files } });
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function calculateRevenue() {
    const ticketPrice = parseFloat(document.getElementById('ticketPrice').value) || 0;
    const totalTickets = parseInt(document.getElementById('totalTickets').value) || 0;
    
    const totalRevenue = ticketPrice * totalTickets;
    const commission = totalRevenue * 0.1;
    const sellerRevenue = totalRevenue * 0.9;
    
    // Display calculation if element exists
    const calculationDisplay = document.getElementById('revenueCalculation');
    if (calculationDisplay) {
        calculationDisplay.innerHTML = `
            <div class="revenue-breakdown">
                <div class="revenue-item">
                    <span>Revenus bruts:</span>
                    <span>${totalRevenue.toFixed(2)} €</span>
                </div>
                <div class="revenue-item">
                    <span>Commission (10%):</span>
                    <span>-${commission.toFixed(2)} €</span>
                </div>
                <div class="revenue-item total">
                    <span>Vos revenus:</span>
                    <span>${sellerRevenue.toFixed(2)} €</span>
                </div>
            </div>
        `;
    }
}

function resetForm() {
    const form = document.getElementById('productForm');
    if (form) {
        form.reset();
        document.getElementById('imagePreview').innerHTML = '';
        
        const calculationDisplay = document.getElementById('revenueCalculation');
        if (calculationDisplay) {
            calculationDisplay.innerHTML = '';
        }
    }
}

async function loadProducts() {
    try {
        const response = await fetch('api/products.php?action=seller_products');
        const result = await response.json();
        
        if (result.success) {
            currentProducts = result.data;
            updateProductsTable(currentProducts);
            updateRecentProductsList(currentProducts.slice(0, 5));
        } else {
            showNotification('Erreur lors du chargement des produits', 'error');
        }
    } catch (error) {
        console.error('Error loading products:', error);
        showNotification('Erreur de connexion', 'error');
    }
}

function updateProductsTable(products) {
    const tbody = document.querySelector('#products .products-table tbody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    if (products.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" class="empty-table">
                    <div class="empty-state">
                        <span class="empty-icon">📦</span>
                        <p>Aucun produit trouvé</p>
                        <button class="btn btn-primary" onclick="showSection('add-product')">Ajouter un produit</button>
                    </div>
                </td>
            </tr>
        `;
        return;
    }
    
    products.forEach(product => {
        const row = document.createElement('tr');
        const progressPercent = (product.tickets_sold / product.total_tickets) * 100;
        
        row.innerHTML = `
            <td>
                <div class="product-cell">
                    <h4>${escapeHtml(product.title)}</h4>
                    <p>${formatDate(product.created_at)}</p>
                </div>
            </td>
            <td>${product.price} €</td>
            <td>
                <div class="tickets-progress">
                    <span>${product.tickets_sold}/${product.total_tickets}</span>
                    <div class="mini-progress">
                        <div class="mini-progress-fill" style="width: ${progressPercent}%"></div>
                    </div>
                </div>
            </td>
            <td>
                <span class="status-badge status-${product.status}">
                    ${getStatusText(product.status)}
                </span>
            </td>
            <td>${((product.product_revenue || 0) * 0.9).toFixed(2)} €</td>
            <td>
                <div class="action-buttons">
                    <button class="btn btn-sm btn-primary" onclick="editProduct(${product.product_id})" title="Modifier">✏️</button>
                    <button class="btn btn-sm btn-secondary" onclick="viewProduct(${product.product_id})" title="Voir">👁️</button>
                    <button class="btn btn-sm btn-warning" onclick="toggleProductStatus(${product.product_id}, '${product.status}')" title="Changer statut">🔄</button>
                    <button class="btn btn-sm btn-danger" onclick="deleteProduct(${product.product_id})" title="Supprimer">🗑️</button>
                </div>
            </td>
        `;
        
        tbody.appendChild(row);
    });
}

function updateRecentProductsList(products) {
    const container = document.querySelector('#dashboard .products-list');
    if (!container) return;
    
    container.innerHTML = '';
    
    products.forEach(product => {
        const item = document.createElement('div');
        item.className = 'product-item';
        item.innerHTML = `
            <div class="product-info">
                <h4>${escapeHtml(product.title)}</h4>
                <p>${product.tickets_sold}/${product.total_tickets} tickets vendus</p>
            </div>
            <div class="product-stats">
                <span class="product-status status-${product.status}">${getStatusText(product.status)}</span>
                <span class="product-revenue">${((product.product_revenue || 0) * 0.9).toFixed(2)} €</span>
            </div>
        `;
        container.appendChild(item);
    });
}

async function loadRecentTransactions() {
    try {
        const response = await fetch('api/transactions.php?action=seller_recent');
        const result = await response.json();
        
        if (result.success) {
            updateRecentTransactionsList(result.data);
        }
    } catch (error) {
        console.error('Error loading transactions:', error);
    }
}

function updateRecentTransactionsList(transactions) {
    const container = document.querySelector('#dashboard .transactions-list');
    if (!container) return;
    
    container.innerHTML = '';
    
    transactions.forEach(transaction => {
        const item = document.createElement('div');
        item.className = 'transaction-item';
        item.innerHTML = `
            <div class="transaction-info">
                <h4>${escapeHtml(transaction.product_title)}</h4>
                <p>Par ${escapeHtml(transaction.buyer_name)}</p>
            </div>
            <div class="transaction-amount">
                <span class="amount">${transaction.amount} €</span>
                <span class="date">${formatDate(transaction.created_at)}</span>
            </div>
        `;
        container.appendChild(item);
    });
}

async function loadSales() {
    try {
        const response = await fetch('api/transactions.php?action=seller_sales');
        const result = await response.json();
        
        if (result.success) {
            updateSalesTable(result.data);
        }
    } catch (error) {
        console.error('Error loading sales:', error);
    }
}

function updateSalesTable(sales) {
    // Implementation for sales table update
    console.log('Update sales table', sales);
}

async function loadAnalytics() {
    try {
        const response = await fetch('api/products.php?action=seller_analytics');
        const result = await response.json();
        
        if (result.success) {
            updateAnalyticsCharts(result.data);
        }
    } catch (error) {
        console.error('Error loading analytics:', error);
    }
}

function updateAnalyticsCharts(analytics) {
    // Implementation for analytics charts
    console.log('Update analytics', analytics);
}

function editProduct(productId) {
    // Find product data
    const product = currentProducts.find(p => p.product_id === productId);
    if (!product) return;
    
    // Populate form with product data
    document.getElementById('productTitle').value = product.title;
    document.getElementById('productDescription').value = product.description;
    document.getElementById('productPrice').value = product.price;
    document.getElementById('ticketPrice').value = product.ticket_price;
    document.getElementById('totalTickets').value = product.total_tickets;
    document.getElementById('categoryId').value = product.category_id;
    
    // Show add-product section for editing
    showSection('add-product');
    
    // Update form for editing mode
    const form = document.getElementById('productForm');
    form.dataset.editId = productId;
    form.querySelector('button[type="submit"]').innerHTML = '✏️ Modifier le produit';
}

function viewProduct(productId) {
    window.open(`index.php?product=${productId}`, '_blank');
}

async function toggleProductStatus(productId, currentStatus) {
    const newStatus = currentStatus === 'active' ? 'draft' : 'active';
    
    try {
        const response = await fetch('api/products.php', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'update_status',
                product_id: productId,
                status: newStatus
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showNotification(`Statut mis à jour: ${getStatusText(newStatus)}`, 'success');
            await loadProducts();
        } else {
            showNotification('Erreur lors de la mise à jour', 'error');
        }
    } catch (error) {
        console.error('Error updating status:', error);
        showNotification('Erreur de connexion', 'error');
    }
}

async function deleteProduct(productId) {
    if (!confirm('Êtes-vous sûr de vouloir supprimer ce produit ? Cette action est irréversible.')) {
        return;
    }
    
    try {
        const response = await fetch('api/products.php', {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                product_id: productId
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showNotification('Produit supprimé avec succès', 'success');
            await loadProducts();
        } else {
            showNotification('Erreur lors de la suppression', 'error');
        }
    } catch (error) {
        console.error('Error deleting product:', error);
        showNotification('Erreur de connexion', 'error');
    }
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <span class="notification-message">${message}</span>
        <button class="notification-close" onclick="this.parentElement.remove()">×</button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
    
    // Add entrance animation
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
}

// Utility functions
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('fr-FR', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
    });
}

function getStatusText(status) {
    const statusTexts = {
        'draft': 'Brouillon',
        'active': 'Actif',
        'completed': 'Terminé',
        'cancelled': 'Annulé'
    };
    return statusTexts[status] || status;
}

// Export functions for global access
window.showSection = showSection;
window.editProduct = editProduct;
window.viewProduct = viewProduct;
window.deleteProduct = deleteProduct;
window.toggleProductStatus = toggleProductStatus;
window.removeImage = removeImage;