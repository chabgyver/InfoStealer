// Carousel JavaScript
class ImageCarousel {
    constructor(container, images) {
        this.container = container;
        this.images = images;
        this.currentIndex = 0;
        this.autoPlayInterval = null;
        this.init();
    }

    init() {
        this.createCarousel();
        this.setupEventListeners();
        this.startAutoPlay();
    }

    createCarousel() {
        this.container.innerHTML = `
            <div class="carousel-wrapper">
                <div class="carousel-track" id="carouselTrack">
                    ${this.images.map((image, index) => `
                        <div class="carousel-slide ${index === 0 ? 'active' : ''}">
                            <img src="${image.src}" alt="${image.alt || 'Image'}" onclick="openImageViewer(${index})">
                        </div>
                    `).join('')}
                </div>
                <button class="carousel-btn prev" onclick="carousel.prev()">❮</button>
                <button class="carousel-btn next" onclick="carousel.next()">❯</button>
                <div class="carousel-indicators">
                    ${this.images.map((_, index) => `
                        <button class="indicator ${index === 0 ? 'active' : ''}" onclick="carousel.goTo(${index})"></button>
                    `).join('')}
                </div>
            </div>
        `;
    }

    setupEventListeners() {
        this.container.addEventListener('mouseenter', () => {
            this.stopAutoPlay();
        });

        this.container.addEventListener('mouseleave', () => {
            this.startAutoPlay();
        });

        // Touch events for mobile
        let startX = 0;
        let endX = 0;

        this.container.addEventListener('touchstart', (e) => {
            startX = e.touches[0].clientX;
        });

        this.container.addEventListener('touchend', (e) => {
            endX = e.changedTouches[0].clientX;
            if (startX - endX > 50) {
                this.next();
            } else if (endX - startX > 50) {
                this.prev();
            }
        });
    }

    goTo(index) {
        this.currentIndex = index;
        this.updateCarousel();
    }

    next() {
        this.currentIndex = (this.currentIndex + 1) % this.images.length;
        this.updateCarousel();
    }

    prev() {
        this.currentIndex = (this.currentIndex - 1 + this.images.length) % this.images.length;
        this.updateCarousel();
    }

    updateCarousel() {
        const track = document.getElementById('carouselTrack');
        const slides = track.querySelectorAll('.carousel-slide');
        const indicators = this.container.querySelectorAll('.indicator');

        slides.forEach((slide, index) => {
            slide.classList.toggle('active', index === this.currentIndex);
        });

        indicators.forEach((indicator, index) => {
            indicator.classList.toggle('active', index === this.currentIndex);
        });

        track.style.transform = `translateX(-${this.currentIndex * 100}%)`;
    }

    startAutoPlay() {
        this.autoPlayInterval = setInterval(() => {
            this.next();
        }, 5000);
    }

    stopAutoPlay() {
        if (this.autoPlayInterval) {
            clearInterval(this.autoPlayInterval);
            this.autoPlayInterval = null;
        }
    }
}

// Image Viewer
class ImageViewer {
    constructor() {
        this.isOpen = false;
        this.currentIndex = 0;
        this.images = [];
        this.zoomLevel = 1;
        this.init();
    }

    init() {
        this.createViewer();
        this.setupEventListeners();
    }

    createViewer() {
        const viewer = document.createElement('div');
        viewer.id = 'imageViewer';
        viewer.className = 'image-viewer';
        viewer.innerHTML = `
            <div class="viewer-overlay" onclick="imageViewer.close()"></div>
            <div class="viewer-content">
                <button class="viewer-close" onclick="imageViewer.close()">×</button>
                <button class="viewer-prev" onclick="imageViewer.prev()">❮</button>
                <button class="viewer-next" onclick="imageViewer.next()">❯</button>
                <div class="viewer-image-container">
                    <img id="viewerImage" class="viewer-image" alt="Image">
                </div>
                <div class="viewer-controls">
                    <button onclick="imageViewer.zoomIn()">🔍+</button>
                    <button onclick="imageViewer.zoomOut()">🔍-</button>
                    <button onclick="imageViewer.resetZoom()">↺</button>
                    <span class="image-counter" id="imageCounter">1 / 1</span>
                </div>
            </div>
        `;
        document.body.appendChild(viewer);
    }

    setupEventListeners() {
        document.addEventListener('keydown', (e) => {
            if (!this.isOpen) return;

            switch (e.key) {
                case 'Escape':
                    this.close();
                    break;
                case 'ArrowLeft':
                    this.prev();
                    break;
                case 'ArrowRight':
                    this.next();
                    break;
            }
        });

        // Mouse wheel zoom
        document.getElementById('viewerImage').addEventListener('wheel', (e) => {
            e.preventDefault();
            if (e.deltaY < 0) {
                this.zoomIn();
            } else {
                this.zoomOut();
            }
        });
    }

    open(images, index = 0) {
        this.images = images;
        this.currentIndex = index;
        this.isOpen = true;
        this.zoomLevel = 1;
        
        document.getElementById('imageViewer').style.display = 'block';
        document.body.style.overflow = 'hidden';
        
        this.updateImage();
    }

    close() {
        this.isOpen = false;
        document.getElementById('imageViewer').style.display = 'none';
        document.body.style.overflow = 'auto';
    }

    next() {
        this.currentIndex = (this.currentIndex + 1) % this.images.length;
        this.updateImage();
    }

    prev() {
        this.currentIndex = (this.currentIndex - 1 + this.images.length) % this.images.length;
        this.updateImage();
    }

    updateImage() {
        const img = document.getElementById('viewerImage');
        const counter = document.getElementById('imageCounter');
        
        img.src = this.images[this.currentIndex].src;
        img.style.transform = `scale(${this.zoomLevel})`;
        counter.textContent = `${this.currentIndex + 1} / ${this.images.length}`;
    }

    zoomIn() {
        this.zoomLevel = Math.min(this.zoomLevel * 1.2, 3);
        this.updateImage();
    }

    zoomOut() {
        this.zoomLevel = Math.max(this.zoomLevel / 1.2, 0.5);
        this.updateImage();
    }

    resetZoom() {
        this.zoomLevel = 1;
        this.updateImage();
    }
}

// Initialize image viewer
const imageViewer = new ImageViewer();

// Open image viewer
function openImageViewer(index) {
    const images = Array.from(document.querySelectorAll('.carousel-slide img')).map(img => ({
        src: img.src,
        alt: img.alt
    }));
    imageViewer.open(images, index);
}
