// Main JavaScript for Tombola Site
let currentUser = null;
let products = [];
let filteredProducts = [];
let currentFilter = 'all';
let currentSort = 'newest';

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

// Initialize application
async function initializeApp() {
    await loadCurrentUser();
    await loadProducts();
    setupEventListeners();
    updateUI();
}

// Load current user
async function loadCurrentUser() {
    try {
        currentUser = await getCurrentUser();
        updateUserInterface();
    } catch (error) {
        console.error('Error loading current user:', error);
    }
}

// Update user interface based on login status
function updateUserInterface() {
    const userMenu = document.getElementById('userMenu');
    const authButtons = document.getElementById('authButtons');
    
    if (currentUser) {
        if (userMenu) {
            userMenu.style.display = 'block';
            document.getElementById('username').textContent = currentUser.username;
        }
        if (authButtons) {
            authButtons.style.display = 'none';
        }
    } else {
        if (userMenu) {
            userMenu.style.display = 'none';
        }
        if (authButtons) {
            authButtons.style.display = 'block';
        }
    }
}

// Load products
async function loadProducts() {
    try {
        const response = await fetch('api/products.php?action=list');
        const data = await response.json();
        
        products = data;
        filteredProducts = [...products];
        
        renderProducts();
    } catch (error) {
        console.error('Error loading products:', error);
    }
}

// Render products
function renderProducts() {
    const productsGrid = document.getElementById('productsGrid');
    if (!productsGrid) return;
    
    productsGrid.innerHTML = '';
    
    filteredProducts.forEach(product => {
        const productCard = createProductCard(product);
        productsGrid.appendChild(productCard);
    });
}

// Create product card
function createProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card';
    
    const ticketsLeft = product.total_tickets - product.tickets_sold;
    const percentage = (product.tickets_sold / product.total_tickets) * 100;
    
    card.innerHTML = `
        <div class="product-image">
            ${product.main_image ? 
                `<img src="${product.main_image}" alt="${product.title}">` : 
                '<div class="no-image">Aucune image</div>'
            }
            ${percentage >= 85 ? '<span class="badge hot">🔥 Presque épuisé</span>' : ''}
            ${isNewProduct(product.created_at) ? '<span class="badge new">✨ Nouveau</span>' : ''}
        </div>
        <div class="product-info">
            <h3>${product.title}</h3>
            <p class="product-description">${product.description}</p>
            <div class="product-price">
                <span class="main-price">${product.price} €</span>
                <span class="ticket-price">Ticket: ${product.ticket_price} €</span>
            </div>
            <div class="product-progress">
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${percentage}%"></div>
                </div>
                <span class="progress-text">${product.tickets_sold}/${product.total_tickets} tickets</span>
            </div>
            <button onclick="openBuyModal(${product.product_id})" class="btn btn-primary btn-buy">
                Acheter un ticket
            </button>
        </div>
    `;
    
    return card;
}

// Check if product is new (less than 7 days)
function isNewProduct(createdAt) {
    const created = new Date(createdAt);
    const now = new Date();
    const diffTime = Math.abs(now - created);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays <= 7;
}

// Open buy modal
function openBuyModal(productId) {
    if (!currentUser) {
        alert('Veuillez vous connecter pour acheter des tickets');
        window.location.href = 'login.html';
        return;
    }
    
    const product = products.find(p => p.product_id === productId);
    if (!product) return;
    
    const modal = document.getElementById('buyModal');
    document.getElementById('modalProductTitle').textContent = product.title;
    document.getElementById('modalProductPrice').textContent = product.price + ' €';
    document.getElementById('modalTicketPrice').textContent = product.ticket_price + ' €';
    document.getElementById('modalTicketsLeft').textContent = product.total_tickets - product.tickets_sold;
    
    // Set product image
    const modalImage = document.getElementById('modalProductImage');
    if (product.main_image) {
        modalImage.src = product.main_image;
        modalImage.style.display = 'block';
    } else {
        modalImage.style.display = 'none';
    }
    
    // Set product ID
    document.getElementById('buyForm').dataset.productId = productId;
    
    // Reset form
    document.getElementById('ticketQuantity').value = 1;
    updateTotal();
    
    modal.style.display = 'block';
}

// Close buy modal
function closeBuyModal() {
    document.getElementById('buyModal').style.display = 'none';
}

// Update total price
function updateTotal() {
    const form = document.getElementById('buyForm');
    const productId = parseInt(form.dataset.productId);
    const product = products.find(p => p.product_id === productId);
    const quantity = parseInt(document.getElementById('ticketQuantity').value);
    
    if (product && quantity) {
        const total = product.ticket_price * quantity;
        document.getElementById('totalPrice').textContent = total.toFixed(2) + ' €';
    }
}

// Buy tickets
async function buyTickets(e) {
    e.preventDefault();
    
    const form = e.target;
    const productId = parseInt(form.dataset.productId);
    const quantity = parseInt(document.getElementById('ticketQuantity').value);
    
    try {
        const response = await fetch('buy_ticket.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                product_id: productId,
                quantity: quantity
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Tickets achetés avec succès !');
            closeBuyModal();
            loadProducts(); // Refresh products
        } else {
            alert('Erreur : ' + data.message);
        }
    } catch (error) {
        console.error('Error buying tickets:', error);
        alert('Erreur lors de l\'achat des tickets');
    }
}

// Filter products
function filterProducts(filter) {
    currentFilter = filter;
    
    switch (filter) {
        case 'all':
            filteredProducts = [...products];
            break;
        case 'almost_sold':
            filteredProducts = products.filter(p => (p.tickets_sold / p.total_tickets) >= 0.85);
            break;
        case 'new':
            filteredProducts = products.filter(p => isNewProduct(p.created_at));
            break;
        default:
            // Category filter
            filteredProducts = products.filter(p => p.category_id == filter);
    }
    
    sortProducts(currentSort);
    renderProducts();
    updateFilterUI();
}

// Sort products
function sortProducts(sort) {
    currentSort = sort;
    
    switch (sort) {
        case 'newest':
            filteredProducts.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
            break;
        case 'oldest':
            filteredProducts.sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
            break;
        case 'price_low':
            filteredProducts.sort((a, b) => a.ticket_price - b.ticket_price);
            break;
        case 'price_high':
            filteredProducts.sort((a, b) => b.ticket_price - a.ticket_price);
            break;
        case 'popularity':
            filteredProducts.sort((a, b) => b.tickets_sold - a.tickets_sold);
            break;
    }
    
    renderProducts();
}

// Update filter UI
function updateFilterUI() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    filterButtons.forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.filter === currentFilter) {
            btn.classList.add('active');
        }
    });
}

// Search products
function searchProducts(query) {
    const searchQuery = query.toLowerCase();
    filteredProducts = products.filter(product => 
        product.title.toLowerCase().includes(searchQuery) ||
        product.description.toLowerCase().includes(searchQuery)
    );
    
    renderProducts();
}

// Setup event listeners
function setupEventListeners() {
    // Search
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            searchProducts(e.target.value);
        });
    }
    
    // Filter buttons
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            filterProducts(e.target.dataset.filter);
        });
    });
    
    // Sort select
    const sortSelect = document.getElementById('sortSelect');
    if (sortSelect) {
        sortSelect.addEventListener('change', (e) => {
            sortProducts(e.target.value);
        });
    }
    
    // Buy form
    const buyForm = document.getElementById('buyForm');
    if (buyForm) {
        buyForm.addEventListener('submit', buyTickets);
    }
    
    // Quantity input
    const quantityInput = document.getElementById('ticketQuantity');
    if (quantityInput) {
        quantityInput.addEventListener('input', updateTotal);
    }
    
    // Modal close
    document.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal')) {
            e.target.style.display = 'none';
        }
    });
}

// Update UI
function updateUI() {
    // Update user menu
    updateUserInterface();
    
    // Update filter buttons
    updateFilterUI();
}

// Gestion du formulaire d'ajout de produit
if (document.getElementById('productForm')) {
    document.addEventListener('DOMContentLoaded', function() {
        // Éléments du formulaire
        const form = document.getElementById('productForm');
        const priceInput = document.getElementById('price');
        const ticketPriceInput = document.getElementById('ticket_price');
        const totalTicketsInput = document.getElementById('total_tickets');
        const dropZone = document.getElementById('dropZone');
        const imageInput = document.getElementById('images');
        const imagePreview = document.getElementById('imagePreview');
        
        let selectedFiles = [];

        // Gestion du drag & drop
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('dragover');
        });

        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('dragover');
        });

        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('dragover');
            handleFiles(e.dataTransfer.files);
        });

        dropZone.addEventListener('click', () => {
            imageInput.click();
        });

        imageInput.addEventListener('change', () => {
            handleFiles(imageInput.files);
        });

        // Affichage des images sélectionnées
        function handleFiles(files) {
            if (files.length > 5) {
                alert('Maximum 5 images autorisées');
                return;
            }

            selectedFiles = Array.from(files);
            displayImages();
        }

        function displayImages() {
            imagePreview.innerHTML = '';
            
            selectedFiles.forEach((file, index) => {
                if (!file.type.startsWith('image/')) return;
                
                const reader = new FileReader();
                reader.onload = (e) => {
                    const imgContainer = document.createElement('div');
                    imgContainer.className = 'preview-item';
                    imgContainer.innerHTML = `
                        <img src="${e.target.result}" alt="Preview">
                        <button class="remove-btn" data-index="${index}">&times;</button>
                        ${index === 0 ? '<span class="primary-badge">Principal</span>' : ''}
                    `;
                    imagePreview.appendChild(imgContainer);
                };
                reader.readAsDataURL(file);
            });
        }

        // Suppression d'image
        imagePreview.addEventListener('click', (e) => {
            if (e.target.classList.contains('remove-btn')) {
                const index = e.target.getAttribute('data-index');
                selectedFiles.splice(index, 1);
                displayImages();
            }
        });

        // Validation du formulaire
        form.addEventListener('submit', (e) => {
            const submitBtn = document.getElementById('submitBtn');
            
            if (selectedFiles.length === 0) {
                e.preventDefault();
                alert('Veuillez ajouter au moins une image');
                return;
            }
            
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Publication en cours...';
        });
    });
}
