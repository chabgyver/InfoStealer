-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : dim. 06 juil. 2025 à 08:22
-- Version du serveur : 10.6.21-MariaDB
-- Version de PHP : 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `thiebtcz_tombola`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin_permissions`
--

CREATE TABLE `admin_permissions` (
  `permission_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `admin_permissions`
--

INSERT INTO `admin_permissions` (`permission_id`, `user_id`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2025-06-09 08:34:53', '2025-06-25 18:25:44');

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `categories`
--

INSERT INTO `categories` (`category_id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Électronique', 'Produits électroniques, gadgets et accessoires', '2025-06-08 07:08:47', NULL),
(2, 'Mode', 'Vêtements, chaussures et accessoires de mode', '2025-06-08 07:08:47', NULL),
(3, 'Maison', 'Décoration, meubles et articles pour la maison', '2025-06-08 07:08:47', NULL),
(4, 'Sport', 'Équipements et accessoires de sport', '2025-06-08 07:08:47', NULL),
(5, 'Jeux', 'Jeux vidéo, consoles et accessoires', '2025-06-08 07:08:47', NULL),
(6, 'Autres', 'Autres catégories de produits', '2025-06-08 07:08:47', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `csrf_tokens`
--

CREATE TABLE `csrf_tokens` (
  `token_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `token` varchar(128) NOT NULL,
  `expires_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `attempt_id` int(11) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `login_used` varchar(255) DEFAULT NULL,
  `success` tinyint(1) NOT NULL DEFAULT 0,
  `attempt_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `attempt_type` enum('login','admin','register','password_reset') NOT NULL DEFAULT 'login',
  `user_agent` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `notifications`
--

CREATE TABLE `notifications` (
  `notification_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `participations`
--

CREATE TABLE `participations` (
  `participation_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `participation_date` datetime NOT NULL,
  `is_winner` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structure de la table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `ticket_price` decimal(10,2) NOT NULL,
  `total_tickets` int(11) NOT NULL,
  `tickets_sold` int(11) DEFAULT 0,
  `category_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `winner_id` int(11) DEFAULT NULL,
  `status` enum('draft','active','completed','cancelled') DEFAULT 'draft',
  `published_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `draw_date` datetime DEFAULT NULL
) ;

--
-- Déchargement des données de la table `products`
--

INSERT INTO `products` (`product_id`, `title`, `description`, `price`, `ticket_price`, `total_tickets`, `tickets_sold`, `category_id`, `seller_id`, `winner_id`, `status`, `published_at`, `created_at`, `updated_at`, `draw_date`) VALUES
(1, 'test', 'testkjkbkjb', 100.00, 2.00, 50, 0, 5, 1, NULL, 'draft', NULL, '2025-06-08 20:54:42', '2025-07-03 13:46:38', NULL),
(2, 'gugigiug', 'jnblblnln', 1000.00, 10.00, 100, 0, 1, 2, NULL, NULL, NULL, '2025-06-30 16:26:07', NULL, NULL),
(3, 'jjbjhbjhvb', 'n,bjbjkbjbvjhvjh', 2000.00, 20.00, 100, 0, 5, 2, NULL, 'active', '2025-07-01 22:20:43', '2025-07-01 17:50:59', '2025-07-01 20:20:43', NULL),
(4, 'testestest', 'bbbbbjbjkbbjjk', 100.00, 1.00, 100, 0, 6, 1, NULL, 'active', '2025-07-02 14:17:20', '2025-07-01 17:55:26', '2025-07-02 12:17:20', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `product_images`
--

CREATE TABLE `product_images` (
  `image_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `is_primary` tinyint(1) DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `product_images`
--

INSERT INTO `product_images` (`image_id`, `product_id`, `image_path`, `is_primary`, `created_at`) VALUES
(1, 2, 'img_6862ba9f10f3f.jpg', 1, '2025-06-30 16:26:07'),
(2, 2, 'img_6862ba9f118ba.jpg', 0, '2025-06-30 16:26:07'),
(3, 2, 'img_6862ba9f1249b.jpg', 0, '2025-06-30 16:26:07'),
(4, 2, 'img_6862ba9f12bc1.jpg', 0, '2025-06-30 16:26:07'),
(6, 4, '/home/thiebtcz/public_html/tombola/uploads/products/2.png', 0, '2025-07-02 12:17:20');

-- --------------------------------------------------------

--
-- Structure de la table `product_logs`
--

CREATE TABLE `product_logs` (
  `log_id` int(11) NOT NULL,
  `action` varchar(50) NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `data` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `product_logs`
--

INSERT INTO `product_logs` (`log_id`, `action`, `product_id`, `user_id`, `data`, `created_at`) VALUES
(1, 'create', 1, 1, '{\"title\":\"test\",\"price\":100,\"total_tickets\":50}', '2025-06-08 20:54:42');

-- --------------------------------------------------------

--
-- Structure de la table `rate_limits`
--

CREATE TABLE `rate_limits` (
  `id` int(11) NOT NULL,
  `ip` varchar(45) NOT NULL,
  `action` varchar(50) NOT NULL,
  `timestamp` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `security_logs`
--

CREATE TABLE `security_logs` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `security_logs`
--

INSERT INTO `security_logs` (`log_id`, `user_id`, `action`, `ip_address`, `user_agent`, `created_at`) VALUES
(1, 1, 'admin_login_success', '213.44.36.119', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 OPR/119.0.0.0', '2025-06-09 08:35:50'),
(2, 1, 'admin_login_success', '213.44.36.119', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 OPR/119.0.0.0', '2025-06-09 08:36:38');

-- --------------------------------------------------------

--
-- Structure de la table `settings`
--

CREATE TABLE `settings` (
  `setting_key` varchar(50) NOT NULL,
  `setting_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Déchargement des données de la table `settings`
--

INSERT INTO `settings` (`setting_key`, `setting_value`) VALUES
('commission_threshold', '10'),
('currency', '€'),
('default_commission', '10'),
('items_per_page', '10'),
('maintenance_mode', '0'),
('reduced_commission', '5'),
('registration_enabled', '1'),
('site_email', 't.chabenat@balistiq.fr'),
('site_name', 'Tombola');

-- --------------------------------------------------------

--
-- Structure de la table `tickets`
--

CREATE TABLE `tickets` (
  `ticket_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `serial_number` varchar(10) NOT NULL,
  `transaction_id` int(11) NOT NULL,
  `purchase_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `ticket_logs`
--

CREATE TABLE `ticket_logs` (
  `log_id` int(11) NOT NULL,
  `action` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `data` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `transactions`
--

CREATE TABLE `transactions` (
  `transaction_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `tickets_count` int(11) NOT NULL,
  `status` enum('pending','completed','failed','refunded') DEFAULT 'pending',
  `error_message` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `is_admin` tinyint(1) DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `last_login` datetime DEFAULT NULL,
  `status` enum('active','inactive','banned') DEFAULT 'active',
  `theme_preference` enum('light','dark') DEFAULT 'light',
  `failed_login_attempts` int(11) NOT NULL DEFAULT 0,
  `locked_until` timestamp NULL DEFAULT NULL
) ;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password`, `is_admin`, `created_at`, `updated_at`, `last_login`, `status`, `theme_preference`, `failed_login_attempts`, `locked_until`) VALUES
(1, 'admin', 'chabgyver@gmail.com', '$2y$10$faXjCVSPAFpOYOwpm.gFuuEYly2UmTSrJC4mC6.R1MhAmlfYod4Oe', 1, '2025-06-08 07:08:47', '2025-07-03 09:53:53', '2025-07-03 09:53:53', 'active', 'light', 0, NULL),
(2, 'chabgyver2', 't.chabenat@balistiq.fr', '$2y$10$PhZ3VGMGLL59zgzF5mkwzOkSiBQuoAcalg8zgsUzRVmVQuMKElkBS', 0, '2025-06-27 15:52:54', '2025-07-03 10:48:43', '2025-07-03 10:48:43', 'active', 'light', 0, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `user_audit_log`
--

CREATE TABLE `user_audit_log` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `action_type` varchar(50) NOT NULL,
  `changes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`changes`)),
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structure de la table `user_logs`
--

CREATE TABLE `user_logs` (
  `log_id` int(11) NOT NULL,
  `action` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`data`)),
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `user_logs`
--

INSERT INTO `user_logs` (`log_id`, `action`, `user_id`, `data`, `created_at`) VALUES
(1, 'logout', 1, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-09 09:14:18\"}', '2025-06-09 07:14:18'),
(5, 'login', 1, '{\"ip\":\"213.44.36.119\"}', '2025-06-09 07:45:00'),
(6, 'logout', 1, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-09 09:48:46\"}', '2025-06-09 07:48:46'),
(7, 'login', 1, '{\"ip\":\"213.44.36.119\"}', '2025-06-09 08:27:14'),
(8, 'logout', 1, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-09 10:31:12\"}', '2025-06-09 08:31:12'),
(9, 'login', 1, '{\"ip\":\"213.44.36.119\"}', '2025-06-09 08:31:26'),
(10, 'logout', 1, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-09 10:35:18\"}', '2025-06-09 08:35:18'),
(11, 'login', 1, '{\"ip\":\"213.44.36.119\"}', '2025-06-09 08:35:22'),
(12, 'logout', 1, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-09 10:35:28\"}', '2025-06-09 08:35:28'),
(13, 'login', 1, '{\"ip\":\"213.44.36.119\"}', '2025-06-09 08:35:50'),
(14, 'logout', 1, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-09 10:36:33\"}', '2025-06-09 08:36:33'),
(15, 'login', 1, '{\"ip\":\"213.44.36.119\"}', '2025-06-09 08:36:38'),
(16, 'logout', 1, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-09 10:43:51\"}', '2025-06-09 08:43:51'),
(17, 'logout', 1, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-09 16:52:03\"}', '2025-06-09 14:52:03'),
(18, 'logout', 1, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-09 16:56:51\"}', '2025-06-09 14:56:51'),
(19, 'logout', 1, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-09 17:56:17\"}', '2025-06-09 15:56:17'),
(20, 'logout', 1, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-09 18:04:37\"}', '2025-06-09 16:04:37'),
(21, 'logout', 1, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-09 18:28:50\"}', '2025-06-09 16:28:50'),
(22, 'logout', 1, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-09 18:42:20\"}', '2025-06-09 16:42:20'),
(23, 'logout', 1, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-27 16:22:00\"}', '2025-06-27 14:22:00'),
(24, 'logout', 1, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-27 16:50:48\"}', '2025-06-27 14:50:48'),
(25, 'logout', 1, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-27 18:09:53\"}', '2025-06-27 16:09:53'),
(26, 'logout', 1, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-27 18:32:03\"}', '2025-06-27 16:32:03'),
(27, 'logout', 2, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-27 19:03:52\"}', '2025-06-27 17:03:52'),
(28, 'logout', 2, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-27 19:07:44\"}', '2025-06-27 17:07:44'),
(29, 'logout', 2, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-28 11:29:02\"}', '2025-06-28 09:29:02'),
(30, 'logout', 1, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-28 11:38:26\"}', '2025-06-28 09:38:26'),
(31, 'logout', 1, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-28 12:15:45\"}', '2025-06-28 10:15:45'),
(32, 'logout', 2, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-28 12:35:28\"}', '2025-06-28 10:35:28'),
(33, 'logout', 2, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-28 12:39:30\"}', '2025-06-28 10:39:30'),
(34, 'logout', 2, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-06-28 12:48:22\"}', '2025-06-28 10:48:22'),
(35, 'logout', 1, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-07-02 12:18:29\"}', '2025-07-02 10:18:29'),
(36, 'logout', 1, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-07-03 11:11:31\"}', '2025-07-03 09:11:31'),
(37, 'logout', 1, '{\"ip\":\"213.44.36.119\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/134.0.0.0 Safari\\/537.36 OPR\\/119.0.0.0\",\"logout_time\":\"2025-07-03 11:51:01\"}', '2025-07-03 09:51:01');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `admin_permissions`
--
ALTER TABLE `admin_permissions`
  ADD PRIMARY KEY (`permission_id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Index pour la table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Index pour la table `csrf_tokens`
--
ALTER TABLE `csrf_tokens`
  ADD PRIMARY KEY (`token_id`),
  ADD UNIQUE KEY `token` (`token`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `expires_at` (`expires_at`);

--
-- Index pour la table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`attempt_id`),
  ADD KEY `idx_ip_address` (`ip_address`),
  ADD KEY `idx_attempt_time` (`attempt_time`),
  ADD KEY `idx_attempt_type` (`attempt_type`),
  ADD KEY `idx_ip_type_time` (`ip_address`,`attempt_type`,`attempt_time`),
  ADD KEY `idx_success` (`success`);

--
-- Index pour la table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `idx_notifications_user` (`user_id`,`is_read`),
  ADD KEY `idx_notifications_type` (`type`),
  ADD KEY `idx_notifications_created` (`created_at`);

--
-- Index pour la table `participations`
--
ALTER TABLE `participations`
  ADD PRIMARY KEY (`participation_id`),
  ADD KEY `fk_participations_user` (`user_id`),
  ADD KEY `fk_participations_product` (`product_id`);

--
-- Index pour la table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `idx_products_status` (`status`),
  ADD KEY `idx_products_category` (`category_id`),
  ADD KEY `idx_products_seller` (`seller_id`),
  ADD KEY `idx_products_winner` (`winner_id`),
  ADD KEY `idx_products_created` (`created_at`),
  ADD KEY `idx_status_category` (`status`,`category_id`);

--
-- Index pour la table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`image_id`),
  ADD KEY `idx_product_images_primary` (`product_id`,`is_primary`);

--
-- Index pour la table `product_logs`
--
ALTER TABLE `product_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `idx_product_logs_product` (`product_id`),
  ADD KEY `idx_product_logs_user` (`user_id`),
  ADD KEY `idx_product_logs_action` (`action`),
  ADD KEY `idx_product_logs_created` (`created_at`);

--
-- Index pour la table `rate_limits`
--
ALTER TABLE `rate_limits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_rate_limits_ip_action` (`ip`,`action`),
  ADD KEY `idx_rate_limits_timestamp` (`timestamp`);

--
-- Index pour la table `security_logs`
--
ALTER TABLE `security_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `action` (`action`),
  ADD KEY `created_at` (`created_at`);

--
-- Index pour la table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`setting_key`);

--
-- Index pour la table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ticket_id`),
  ADD UNIQUE KEY `serial_number` (`serial_number`),
  ADD KEY `idx_tickets_product` (`product_id`),
  ADD KEY `idx_tickets_buyer` (`buyer_id`),
  ADD KEY `idx_tickets_serial` (`serial_number`),
  ADD KEY `idx_tickets_transaction` (`transaction_id`),
  ADD KEY `idx_tickets_purchase_date` (`purchase_date`);

--
-- Index pour la table `ticket_logs`
--
ALTER TABLE `ticket_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `idx_ticket_logs_user` (`user_id`),
  ADD KEY `idx_ticket_logs_product` (`product_id`),
  ADD KEY `idx_ticket_logs_action` (`action`),
  ADD KEY `idx_ticket_logs_created` (`created_at`);

--
-- Index pour la table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`transaction_id`),
  ADD KEY `idx_transactions_user` (`user_id`),
  ADD KEY `idx_transactions_product` (`product_id`),
  ADD KEY `idx_transactions_status` (`status`),
  ADD KEY `idx_transactions_created` (`created_at`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `unique_email` (`email`),
  ADD UNIQUE KEY `unique_username` (`username`),
  ADD KEY `idx_failed_attempts` (`failed_login_attempts`),
  ADD KEY `idx_locked_until` (`locked_until`);

--
-- Index pour la table `user_audit_log`
--
ALTER TABLE `user_audit_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Index pour la table `user_logs`
--
ALTER TABLE `user_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `idx_user_logs_user` (`user_id`),
  ADD KEY `idx_user_logs_action` (`action`),
  ADD KEY `idx_user_logs_created` (`created_at`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `admin_permissions`
--
ALTER TABLE `admin_permissions`
  MODIFY `permission_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `csrf_tokens`
--
ALTER TABLE `csrf_tokens`
  MODIFY `token_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `attempt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT pour la table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `participations`
--
ALTER TABLE `participations`
  MODIFY `participation_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `image_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `product_logs`
--
ALTER TABLE `product_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `rate_limits`
--
ALTER TABLE `rate_limits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `security_logs`
--
ALTER TABLE `security_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `ticket_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `ticket_logs`
--
ALTER TABLE `ticket_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `user_audit_log`
--
ALTER TABLE `user_audit_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `user_logs`
--
ALTER TABLE `user_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `participations`
--
ALTER TABLE `participations`
  ADD CONSTRAINT `fk_participations_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_participations_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`seller_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `products_ibfk_3` FOREIGN KEY (`winner_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Contraintes pour la table `product_images`
--
ALTER TABLE `product_images`
  ADD CONSTRAINT `product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `product_logs`
--
ALTER TABLE `product_logs`
  ADD CONSTRAINT `product_logs_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `product_logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `tickets`
--
ALTER TABLE `tickets`
  ADD CONSTRAINT `tickets_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `tickets_ibfk_2` FOREIGN KEY (`buyer_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `ticket_logs`
--
ALTER TABLE `ticket_logs`
  ADD CONSTRAINT `ticket_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ticket_logs_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `user_logs`
--
ALTER TABLE `user_logs`
  ADD CONSTRAINT `user_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
