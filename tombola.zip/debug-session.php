<?php
session_start();

echo "<h1>🧪 Debug Session & Cookies</h1>";

echo "<h2>SESSION</h2>";
if (!empty($_SESSION)) {
    echo "<pre>";
    print_r($_SESSION);
    echo "</pre>";
} else {
    echo "<p style='color:red;'>Aucune session active.</p>";
}

echo "<h2>COOKIES</h2>";
if (!empty($_COOKIE)) {
    echo "<pre>";
    print_r($_COOKIE);
    echo "</pre>";
} else {
    echo "<p style='color:red;'>Aucun cookie reçu.</p>";
}

echo "<h2>Infos utiles</h2>";
echo "<p>Adresse IP : " . $_SERVER['REMOTE_ADDR'] . "</p>";
echo "<p>Agent utilisateur : " . $_SERVER['HTTP_USER_AGENT'] . "</p>";
echo "<p>Heure : " . date("Y-m-d H:i:s") . "</p>";

echo "<h2>🧹 Action facultative</h2>";
echo "<form method='post'><button name='clear' value='1'>Effacer la session + cookies</button></form>";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clear'])) {
    // Supprimer les cookies
    foreach ($_COOKIE as $name => $value) {
        setcookie($name, '', time() - 3600, '/');
    }

    // Supprimer la session
    session_unset();
    session_destroy();

    echo "<p style='color:green;'>Session et cookies effacés ! Rechargez la page.</p>";
}
