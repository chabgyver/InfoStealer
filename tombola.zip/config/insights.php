<?php

declare(strict_types=1);

use NunoMaduro\PhpInsights\Domain\Insights\ForbiddenNormalClasses;
use NunoMaduro\PhpInsights\Domain\Insights\ForbiddenTraits;
use NunoMaduro\PhpInsights\Domain\Metrics\Code\Comments;
use NunoMaduro\PhpInsights\Domain\Metrics\Complexity\Complexity;
use NunoMaduro\PhpInsights\Domain\Metrics\Complexity\CyclomaticComplexity;
use NunoMaduro\PhpInsights\Domain\Metrics\ForbiddenCode\EvalUsage;
use NunoMaduro\PhpInsights\Domain\Metrics\ForbiddenCode\GotoUsage;
use NunoMaduro\PhpInsights\Domain\Metrics\ForbiddenCode\SilencedErrors;
use NunoMaduro\PhpInsights\Domain\Sniffs\ForbiddenSetterSniff;
use PHP_CodeSniffer\Standards\Generic\Sniffs\Files\LineLengthSniff;
use PHP_CodeSniffer\Standards\Generic\Sniffs\NamingConventions\CamelCapsFunctionNameSniff;
use PHP_CodeSniffer\Standards\PSR1\Sniffs\Methods\CamelCapsMethodNameSniff;
use SlevomatCodingStandard\Sniffs\Classes\SuperfluousExceptionNamingSniff;
use SlevomatCodingStandard\Sniffs\Classes\SuperfluousInterfaceNamingSniff;
use SlevomatCodingStandard\Sniffs\Classes\SuperfluousTraitNamingSniff;
use SlevomatCodingStandard\Sniffs\Commenting\DocCommentSpacingSniff;
use SlevomatCodingStandard\Sniffs\Commenting\UselessFunctionDocCommentSniff;
use SlevomatCodingStandard\Sniffs\ControlStructures\DisallowShortTernaryOperatorSniff;
use SlevomatCodingStandard\Sniffs\Functions\FunctionLengthSniff;
use SlevomatCodingStandard\Sniffs\TypeHints\ReturnTypeHintSniff;

return [
    /*
    |--------------------------------------------------------------------------
    | Default Preset
    |--------------------------------------------------------------------------
    |
    | This option controls the default preset that will be used by PHP Insights
    | to analyze your code.
    |
    | Supported: "default", "laravel", "symfony", "magento2", "drupal"
    |
    */
    'preset' => 'default',

    /*
    |--------------------------------------------------------------------------
    | Configuration
    |--------------------------------------------------------------------------
    |
    | Here you may adjust all the various `Insights` that will be used by PHP
    | Insights. You can either add, remove or configure `Insights`. Keep in
    | mind that all added `Insights` must belong to a specific `Metric`.
    |
    */
    'config' => [
        // Your configuration here
    ],

    /*
    |--------------------------------------------------------------------------
    | Add your global `excludes` here
    |--------------------------------------------------------------------------
    |
    | Here you may define classes of which `Insights` should be ignored.
    |
    */
    'exclude' => [
        // 'path/to/directory-or-file'
    ],

    /*
    |--------------------------------------------------------------------------
    | IDE
    |--------------------------------------------------------------------------
    |
    | Here you may enable adding a link to your IDE in the output.
    |
    | Supported: "textmate", "macvim", "emacs", "sublime", "phpstorm",
    | "atom", "vscode".
    |
    | If you have another IDE that is not in this list but which you would
    | like to use, please open an issue on GitHub.
    |
    */
    'ide' => 'vscode',

    /*
    |--------------------------------------------------------------------------
    | Insights
    |--------------------------------------------------------------------------
    |
    | Here you may add custom insights or remove existing ones.
    |
    */
    'remove' => [
        // Remove insights from the list
        ForbiddenNormalClasses::class,
        ForbiddenTraits::class,
        EvalUsage::class,
        GotoUsage::class,
        SilencedErrors::class,
        ForbiddenSetterSniff::class,
        SuperfluousExceptionNamingSniff::class,
        SuperfluousInterfaceNamingSniff::class,
        SuperfluousTraitNamingSniff::class,
        UselessFunctionDocCommentSniff::class,
        DisallowShortTernaryOperatorSniff::class,
    ],

    /*
    |--------------------------------------------------------------------------
    | Configure
    |--------------------------------------------------------------------------
    |
    | Here you may adjust the configuration of the various `Insights`.
    |
    */
    'config' => [
        // Your configuration here
        LineLengthSniff::class => [
            'lineLimit' => 120,
            'absoluteLineLimit' => 120,
            'ignoreComments' => false,
        ],
        FunctionLengthSniff::class => [
            'maxLinesLength' => 50,
        ],
        DocCommentSpacingSniff::class => [
            'linesCountBetweenDifferentAnnotationsTypes' => 1,
            'linesCountBetweenAnnotationsGroups' => 1,
            'annotationsGroups' => [
                ['@param'],
                ['@return'],
                ['@throws'],
            ],
        ],
        ReturnTypeHintSniff::class => [
            'traversableTypeHints' => [
                'Traversable',
                'Iterator',
                'IteratorAggregate',
                'ArrayAccess',
                'Countable',
                'ArrayIterator',
            ],
        ],
        CamelCapsFunctionNameSniff::class => [
            'properties' => [
                'strict' => false,
            ],
        ],
        CamelCapsMethodNameSniff::class => [
            'properties' => [
                'strict' => false,
            ],
        ],
    ],
];
