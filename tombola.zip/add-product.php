<?php
session_start();
define('ROOT_PATH', realpath(dirname(__FILE__))); 
require_once 'includes/config.php';
require_once 'includes/functions.php';

// Vérifier si l'utilisateur est connecté et est un vendeur
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'seller') {
    header('Location: login.php');
    exit;
}

// Générer un token CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$errors = [];
$success = false;

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validation CSRF
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $errors[] = "Erreur de sécurité. Veuillez réessayer.";
    } else {
        // Récupération et validation des données
        $title = trim($_POST['title']);
        $category_id = intval($_POST['category']);
        $price = floatval($_POST['price']);
        $ticket_price = floatval($_POST['ticket_price']);
        $description = trim($_POST['description']);
        
        // Validation des champs
        if (empty($title)) $errors[] = "Le titre est obligatoire";
        if ($category_id <= 0) $errors[] = "Veuillez sélectionner une catégorie";
        if ($price <= 0) $errors[] = "Le prix doit être supérieur à 0";
        if ($ticket_price < 0.1) $errors[] = "Le prix du ticket doit être d'au moins 0,10€";
        if (empty($description)) $errors[] = "La description est obligatoire";
        if ($ticket_price > $price) $errors[] = "Le prix du ticket ne peut pas être supérieur au prix du produit";
        if (!isset($_POST['terms'])) $errors[] = "Vous devez accepter les conditions";

        // Validation des fichiers
        $has_images = isset($_FILES['images']) && !empty($_FILES['images']['name'][0]);
        if (!$has_images) {
            $errors[] = "Au moins une image est obligatoire";
        }

        if (empty($errors)) {
            try {
                $pdo->beginTransaction();

                // Insertion du produit
                $stmt = $pdo->prepare("
                    INSERT INTO products (title, description, price, ticket_price, total_tickets, 
                                        category_id, seller_id, status, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', NOW())
                ");
                
                $total_tickets = ceil($price / $ticket_price);
                
                $stmt->execute([
                    $title, 
                    $description, 
                    $price, 
                    $ticket_price, 
                    $total_tickets,
                    $category_id, 
                    $_SESSION['user_id']
                ]);
                
                $product_id = $pdo->lastInsertId();

                // Traitement des images
                $upload_dir = 'uploads/products/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }

                $uploaded_count = 0;
                foreach ($_FILES['images']['tmp_name'] as $key => $tmp_name) {
                    if ($uploaded_count >= 5) break;
                    
                    // Validation du fichier
                    $finfo = finfo_open(FILEINFO_MIME_TYPE);
                    $mime = finfo_file($finfo, $tmp_name);
                    finfo_close($finfo);
                    
                    $allowed_mimes = ['image/jpeg', 'image/png', 'image/gif'];
                    if (!in_array($mime, $allowed_mimes)) continue;
                    
                    // Génération d'un nom unique
                    $ext = pathinfo($_FILES['images']['name'][$key], PATHINFO_EXTENSION);
                    $filename = "product_{$product_id}_" . uniqid() . ".$ext";
                    $filepath = $upload_dir . $filename;
                    
                    if (move_uploaded_file($tmp_name, $filepath)) {
                        // Redimensionnement si nécessaire
                        if (function_exists('resizeImage')) {
                            resizeImage($filepath, $filepath, 800, 600);
                        }
                        
                        // Enregistrement en base
                        $is_primary = ($uploaded_count === 0) ? 1 : 0;
                        $stmt = $pdo->prepare("
                            INSERT INTO product_images (product_id, image_path, is_primary)
                            VALUES (?, ?, ?)
                        ");
                        $stmt->execute([$product_id, $filepath, $is_primary]);
                        
                        $uploaded_count++;
                    }
                }

                $pdo->commit();
                $success = true;
                
                // Redirection après succès
                $_SESSION['success_message'] = "Produit ajouté avec succès!";
                header('Location: seller-dashboard.php');
                exit;
                
            } catch (Exception $e) {
                $pdo->rollBack();
                error_log("Erreur ajout produit: " . $e->getMessage());
                $errors[] = "Une erreur est survenue lors de l'ajout du produit";
            }
        }
    }
}

// Récupérer les catégories
$categories = [];
try {
    $stmt = $pdo->query("SELECT category_id, name FROM categories WHERE status = 'active' ORDER BY name");
    $categories = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Erreur récupération catégories: " . $e->getMessage());
    $errors[] = "Erreur lors du chargement des catégories";
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un Produit - Tombola</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .progress-bar {
            height: 8px;
            background-color: #e5e7eb;
            border-radius: 4px;
            overflow: hidden;
        }
        .progress-fill {
            height: 100%;
            background-color: #3b82f6;
            transition: width 0.3s ease;
        }
        .drop-zone {
            border: 2px dashed #d1d5db;
            border-radius: 0.5rem;
            padding: 2rem;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s;
        }
        .drop-zone:hover, .drop-zone.dragover {
            border-color: #3b82f6;
            background-color: #f8fafc;
        }
        .image-preview {
            position: relative;
            width: 120px;
            height: 120px;
            border-radius: 0.5rem;
            overflow: hidden;
        }
        .image-preview img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .remove-image {
            position: absolute;
            top: 0.25rem;
            right: 0.25rem;
            background-color: rgba(0,0,0,0.5);
            color: white;
            border: none;
            border-radius: 50%;
            width: 1.5rem;
            height: 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }
        .notification {
            position: fixed;
            bottom: 1rem;
            right: 1rem;
            padding: 1rem 1.5rem;
            border-radius: 0.5rem;
            color: white;
            transform: translateY(100px);
            opacity: 0;
            transition: all 0.3s ease;
        }
        .notification.show {
            transform: translateY(0);
            opacity: 1;
        }
        .notification.error {
            background-color: #ef4444;
        }
        .notification.success {
            background-color: #10b981;
        }
        [contenteditable="true"] {
            min-height: 200px;
            border: 1px solid #d1d5db;
            border-radius: 0.5rem;
            padding: 1rem;
            margin-top: 0.5rem;
        }
    </style>
</head>
<body class="bg-gray-50">
    <div class="container mx-auto px-4 py-8 max-w-4xl">
        <!-- Header -->
        <div class="text-center mb-8">
            <h1 class="text-4xl font-bold text-gray-800 mb-2">
                <i class="fas fa-plus-circle text-blue-600 mr-3"></i>
                Créer une Tombola
            </h1>
            <p class="text-gray-600">Vendez vos produits via notre système de tombola</p>
            <div class="progress-bar mt-6">
                <div class="progress-fill" style="width: 0%" id="progressBar"></div>
            </div>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="notification error show" id="errorNotification">
                <i class="fas fa-exclamation-circle mr-2"></i>
                <?= implode('<br>', $errors) ?>
            </div>
        <?php endif; ?>

        <form id="sellForm" method="POST" enctype="multipart/form-data" class="space-y-6">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            
            <!-- Section 1: Informations Générales -->
            <div class="form-section">
                <h2 class="text-2xl font-semibold text-gray-800 mb-6 flex items-center">
                    <i class="fas fa-info-circle text-blue-600 mr-3"></i>
                    Informations Générales
                </h2>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Titre de l'annonce *
                        </label>
                        <input type="text" id="title" name="title" required
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                               value="<?= htmlspecialchars($_POST['title'] ?? '') ?>"
                               placeholder="Ex: iPhone 14 Pro Max 256GB Noir">
                        <div class="text-red-500 text-sm mt-1 hidden" id="titleError"></div>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Catégorie *
                        </label>
                        <select id="category" name="category" required
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                            <option value="">Sélectionnez une catégorie</option>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?= $category['category_id'] ?>" <?= isset($_POST['category']) && $_POST['category'] == $category['category_id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($category['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="text-red-500 text-sm mt-1 hidden" id="categoryError"></div>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Prix de vente *
                        </label>
                        <div class="relative">
                            <input type="number" id="price" name="price" required min="0.01" step="0.01"
                                   class="w-full px-4 py-3 pr-12 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                   value="<?= htmlspecialchars($_POST['price'] ?? '') ?>"
                                   placeholder="0.00">
                            <span class="absolute right-3 top-3 text-gray-500">€</span>
                        </div>
                        <div class="text-red-500 text-sm mt-1 hidden" id="priceError"></div>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Prix par ticket *
                        </label>
                        <div class="relative">
                            <input type="number" id="ticketPrice" name="ticketPrice" required min="0.10" step="0.01"
                                   class="w-full px-4 py-3 pr-12 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                   value="<?= htmlspecialchars($_POST['ticketPrice'] ?? '') ?>"
                                   placeholder="0.00">
                            <span class="absolute right-3 top-3 text-gray-500">€</span>
                        </div>
                        <div class="text-red-500 text-sm mt-1 hidden" id="ticketPriceError"></div>
                    </div>

                    <div class="md:col-span-2">
                        <div class="ticket-calculation hidden bg-blue-50 p-4 rounded-lg" id="ticketCalculation">
                            <div class="flex items-center justify-between">
                                <div>
                                    <h3 class="text-lg font-semibold text-gray-800">Calcul automatique</h3>
                                    <p class="text-sm text-gray-600">Nombre de tickets qui seront générés</p>
                                </div>
                                <div class="text-right">
                                    <div class="text-3xl font-bold text-gray-800" id="totalTickets">0</div>
                                    <div class="text-sm text-gray-600">tickets</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Section 2: Description -->
            <div class="form-section">
                <h2 class="text-2xl font-semibold text-gray-800 mb-6 flex items-center">
                    <i class="fas fa-edit text-blue-600 mr-3"></i>
                    Description du Produit
                </h2>
                
                <div class="editor-toolbar mb-2">
                    <div class="flex flex-wrap gap-2">
                        <button type="button" onclick="formatText('bold')" class="px-3 py-1 bg-white border border-gray-300 rounded hover:bg-gray-50">
                            <i class="fas fa-bold"></i>
                        </button>
                        <button type="button" onclick="formatText('italic')" class="px-3 py-1 bg-white border border-gray-300 rounded hover:bg-gray-50">
                            <i class="fas fa-italic"></i>
                        </button>
                        <button type="button" onclick="formatText('underline')" class="px-3 py-1 bg-white border border-gray-300 rounded hover:bg-gray-50">
                            <i class="fas fa-underline"></i>
                        </button>
                        <div class="border-l border-gray-300 mx-2"></div>
                        <button type="button" onclick="formatText('insertUnorderedList')" class="px-3 py-1 bg-white border border-gray-300 rounded hover:bg-gray-50">
                            <i class="fas fa-list-ul"></i>
                        </button>
                        <button type="button" onclick="formatText('insertOrderedList')" class="px-3 py-1 bg-white border border-gray-300 rounded hover:bg-gray-50">
                            <i class="fas fa-list-ol"></i>
                        </button>
                        <div class="border-l border-gray-300 mx-2"></div>
                        <input type="color" onchange="formatText('foreColor', this.value)" class="w-8 h-8 border border-gray-300 rounded cursor-pointer">
                    </div>
                </div>
                
                <div class="editor-content" contenteditable="true" id="description" name="description">
                    <?= isset($_POST['description']) ? htmlspecialchars_decode($_POST['description']) : '' ?>
                </div>
                <input type="hidden" name="description" id="descriptionInput">
                <div class="text-red-500 text-sm mt-1 hidden" id="descriptionError"></div>
            </div>

            <!-- Section 3: Images -->
            <div class="form-section">
                <h2 class="text-2xl font-semibold text-gray-800 mb-6 flex items-center">
                    <i class="fas fa-images text-blue-600 mr-3"></i>
                    Photos du Produit
                </h2>
                
                <div class="drop-zone" id="dropZone">
                    <i class="fas fa-cloud-upload-alt text-4xl text-gray-400 mb-4"></i>
                    <p class="text-lg text-gray-600 mb-2">Glissez vos images ici ou cliquez pour sélectionner</p>
                    <p class="text-sm text-gray-500">Maximum 5 images - JPG, PNG (5MB max par image)</p>
                    <input type="file" id="imageInput" name="images[]" multiple accept="image/*" class="hidden">
                </div>
                
                <div class="flex flex-wrap gap-4 mt-6" id="imagePreview">
                    <?php if (isset($_FILES['images']) && !empty($_FILES['images']['tmp_name'][0])): ?>
                        <?php for ($i = 0; $i < count($_FILES['images']['tmp_name']); $i++): ?>
                            <?php if ($_FILES['images']['error'][$i] === 0): ?>
                                <div class="image-preview">
                                    <img src="<?= htmlspecialchars($_FILES['images']['tmp_name'][$i]) ?>" alt="Aperçu">
                                </div>
                            <?php endif; ?>
                        <?php endfor; ?>
                    <?php endif; ?>
                </div>
                <div class="text-red-500 text-sm mt-1 hidden" id="imageError"></div>
            </div>

            <!-- Section 4: Validation -->
            <div class="form-section">
                <h2 class="text-2xl font-semibold text-gray-800 mb-6 flex items-center">
                    <i class="fas fa-check-circle text-blue-600 mr-3"></i>
                    Validation
                </h2>
                
                <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
                    <h3 class="font-semibold text-yellow-800 mb-2">Conditions de vente</h3>
                    <ul class="text-sm text-yellow-700 space-y-1">
                        <li>• Votre produit doit être en bon état</li>
                        <li>• Les photos doivent être récentes et représentatives</li>
                        <li>• La description doit être honnête et complète</li>
                        <li>• Une commission de 10% sera prélevée sur la vente</li>
                    </ul>
                </div>
                
                <div class="flex items-center">
                    <input type="checkbox" id="terms" name="terms" required class="mr-3 rounded" <?= isset($_POST['terms']) ? 'checked' : '' ?>>
                    <label for="terms" class="text-sm text-gray-700">
                        J'accepte les <a href="#" class="text-blue-600 hover:underline">conditions générales</a> et certifie que les informations fournies sont exactes
                    </label>
                </div>
                <div class="text-red-500 text-sm mt-1 hidden" id="termsError"></div>
            </div>

            <!-- Bouton de soumission -->
            <div class="text-center">
                <button type="submit" class="btn-primary bg-blue-600 text-white px-8 py-4 rounded-lg font-semibold text-lg shadow-lg hover:shadow-xl transform transition-all duration-200 hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed" id="submitBtn">
                    <i class="fas fa-rocket mr-2"></i>
                    Créer ma Tombola
                </button>
            </div>
        </form>
    </div>

    <script>
        // Variables globales
        let uploadedImages = [];
        let currentStep = 0;
        const totalSteps = 4;

        // Initialisation
        document.addEventListener('DOMContentLoaded', function() {
            setupEventListeners();
            updateProgress();
            
            // Masquer la notification d'erreur après 5s
            const errorNotification = document.getElementById('errorNotification');
            if (errorNotification) {
                setTimeout(() => {
                    errorNotification.classList.remove('show');
                }, 5000);
            }
        });

        function setupEventListeners() {
            // Drag & Drop
            const dropZone = document.getElementById('dropZone');
            const imageInput = document.getElementById('imageInput');

            dropZone.addEventListener('click', () => imageInput.click());
            dropZone.addEventListener('dragover', handleDragOver);
            dropZone.addEventListener('dragleave', handleDragLeave);
            dropZone.addEventListener('drop', handleDrop);
            imageInput.addEventListener('change', handleFileSelect);

            // Validation en temps réel
            document.getElementById('title').addEventListener('input', validateTitle);
            document.getElementById('category').addEventListener('change', validateCategory);
            document.getElementById('price').addEventListener('input', validatePrice);
            document.getElementById('ticketPrice').addEventListener('input', validateTicketPrice);
            document.getElementById('description').addEventListener('input', validateDescription);
            document.getElementById('terms').addEventListener('change', validateTerms);

            // Calcul des tickets
            document.getElementById('price').addEventListener('input', calculateTickets);
            document.getElementById('ticketPrice').addEventListener('input', calculateTickets);

            // Soumission du formulaire
            document.getElementById('sellForm').addEventListener('submit', handleSubmit);
        }

        // Gestion des images
        function handleDragOver(e) {
            e.preventDefault();
            e.currentTarget.classList.add('dragover');
        }

        function handleDragLeave(e) {
            e.currentTarget.classList.remove('dragover');
        }

        function handleDrop(e) {
            e.preventDefault();
            e.currentTarget.classList.remove('dragover');
            const files = e.dataTransfer.files;
            processFiles(files);
        }

        function handleFileSelect(e) {
            const files = e.target.files;
            processFiles(files);
        }

        function processFiles(files) {
            if (uploadedImages.length >= 5) {
                showNotification('Vous ne pouvez pas ajouter plus de 5 images', 'error');
                return;
            }

            for (let i = 0; i < files.length && uploadedImages.length < 5; i++) {
                const file = files[i];
                
                // Validation du fichier
                if (!file.type.match('image.*')) {
                    showNotification('Seules les images sont autorisées', 'error');
                    continue;
                }

                if (file.size > 5 * 1024 * 1024) {
                    showNotification('L\'image doit faire moins de 5MB', 'error');
                    continue;
                }

                // Lecture et prévisualisation
                const reader = new FileReader();
                reader.onload = function(e) {
                    const imageData = {
                        file: file,
                        dataUrl: e.target.result,
                        id: Date.now() + Math.random()
                    };
                    uploadedImages.push(imageData);
                    displayImagePreview(imageData);
                    updateProgress();
                };
                reader.readAsDataURL(file);
            }
        }

        function displayImagePreview(imageData) {
            const preview = document.getElementById('imagePreview');
            const div = document.createElement('div');
            div.className = 'image-preview';
            div.innerHTML = `
                <img src="${imageData.dataUrl}" alt="Aperçu">
                <button type="button" class="remove-image" onclick="removeImage(${imageData.id})">
                    <i class="fas fa-times"></i>
                </button>
            `;
            preview.appendChild(div);
        }

        function removeImage(id) {
            uploadedImages = uploadedImages.filter(img => img.id !== id);
            const preview = document.getElementById('imagePreview');
            preview.innerHTML = '';
            uploadedImages.forEach(img => displayImagePreview(img));
            updateProgress();
        }

        // Éditeur de texte
        function formatText(command, value = null) {
            document.execCommand(command, false, value);
            document.getElementById('description').focus();
        }

        // Validation
        function validateTitle() {
            const title = document.getElementById('title').value.trim();
            const error = document.getElementById('titleError');
            
            if (title.length < 5) {
                error.textContent = 'Le titre doit contenir au moins 5 caractères';
                error.classList.remove('hidden');
                return false;
            } else {
                error.classList.add('hidden');
                return true;
            }
        }

        function validateCategory() {
            const category = document.getElementById('category').value;
            const error = document.getElementById('categoryError');
            
            if (!category) {
                error.textContent = 'Veuillez sélectionner une catégorie';
                error.classList.remove('hidden');
                return false;
            } else {
                error.classList.add('hidden');
                return true;
            }
        }

        function validatePrice() {
            const price = parseFloat(document.getElementById('price').value);
            const error = document.getElementById('priceError');
            
            if (isNaN(price) || price <= 0) {
                error.textContent = 'Le prix doit être supérieur à 0';
                error.classList.remove('hidden');
                return false;
            } else {
                error.classList.add('hidden');
                return true;
            }
        }

        function validateTicketPrice() {
            const ticketPrice = parseFloat(document.getElementById('ticketPrice').value);
            const error = document.getElementById('ticketPriceError');
            
            if (isNaN(ticketPrice) || ticketPrice < 0.10) {
                error.textContent = 'Le prix du ticket doit être d\'au moins 0,10€';
                error.classList.remove('hidden');
                return false;
            } else {
                error.classList.add('hidden');
                return true;
            }
        }

        function validateDescription() {
            const description = document.getElementById('description').innerHTML.trim();
            const error = document.getElementById('descriptionError');
            
            if (description.length < 20) {
                error.textContent = 'La description doit contenir au moins 20 caractères';
                error.classList.remove('hidden');
                return false;
            } else {
                error.classList.add('hidden');
                return true;
            }
        }

        function validateTerms() {
            const terms = document.getElementById('terms').checked;
            const error = document.getElementById('termsError');
            
            if (!terms) {
                error.textContent = 'Vous devez accepter les conditions générales';
                error.classList.remove('hidden');
                return false;
            } else {
                error.classList.add('hidden');
                return true;
            }
        }

        function calculateTickets() {
            const price = parseFloat(document.getElementById('price').value) || 0;
            const ticketPrice = parseFloat(document.getElementById('ticketPrice').value) || 0;
            
            if (price > 0 && ticketPrice > 0) {
                const totalTickets = Math.ceil(price / ticketPrice);
                document.getElementById('totalTickets').textContent = totalTickets;
                document.getElementById('ticketCalculation').classList.remove('hidden');
            } else {
                document.getElementById('ticketCalculation').classList.add('hidden');
            }
        }

        function updateProgress() {
            let progress = 0;
            
            // Titre et catégorie
            if (document.getElementById('title').value.trim().length >= 5) progress += 25;
            if (document.getElementById('category').value) progress += 25;
            
            // Prix
            if (parseFloat(document.getElementById('price').value) > 0) progress += 15;
            if (parseFloat(document.getElementById('ticketPrice'].value) >= 0.10) progress += 15;
            
            // Description
            if (document.getElementById('description').textContent.trim().length >= 20) progress += 10;
            
            // Images
            if (uploadedImages.length > 0) progress += 10;
            
            document.getElementById('progressBar').style.width = progress + '%';
        }

        // Soumission du formulaire
        function handleSubmit(e) {
            // Mettre à jour le champ description caché
            document.getElementById('descriptionInput').value = document.getElementById('description').innerHTML;
            
            // Validation complète
            const isValid = validateTitle() && validateCategory() && validatePrice() && 
                           validateTicketPrice() && validateDescription() && validateTerms();
            
            if (!isValid) {
                e.preventDefault();
                showNotification('Veuillez corriger les erreurs du formulaire', 'error');
                return;
            }

            if (uploadedImages.length === 0) {
                e.preventDefault();
                showNotification('Veuillez ajouter au moins une image', 'error');
                return;
            }

            // Désactiver le bouton pendant l'envoi
            const submitBtn = document.getElementById('submitBtn');
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Création en cours...';
        }

        function showNotification(message, type) {
            const notification = document.createElement('div');
            notification.className = `notification ${type} show`;
            notification.innerHTML = `
                <i class="fas fa-${type === 'error' ? 'exclamation-circle' : 'check-circle'} mr-2"></i>
                ${message}
            `;
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.classList.remove('show');
                setTimeout(() => {
                    notification.remove();
                }, 300);
            }, 5000);
        }
    </script>
</body>
</html>