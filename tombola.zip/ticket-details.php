<?php
session_start();
define('ROOT_PATH', realpath(dirname(__FILE__)));
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'auth.php';

if (!isLoggedIn() || ($_SESSION['role'] ?? '') !== 'seller') {
    redirectToLogin();
}

$user_id = $_SESSION['user_id'];
$ticket_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

try {
    // Récupérer le ticket et vérifier qu'il appartient à un produit du vendeur
    $stmt = $pdo->prepare("
        SELECT t.*, p.title as product_title, p.user_id as seller_id,
               u.username as buyer_username, u.email as buyer_email
        FROM tickets t
        JOIN products p ON t.product_id = p.product_id
        JOIN users u ON t.user_id = u.user_id
        WHERE t.ticket_id = ? AND p.user_id = ?
    ");
    $stmt->execute([$ticket_id, $user_id]);
    $ticket = $stmt->fetch();

    if (!$ticket) {
        die("Ticket introuvable ou accès refusé.");
    }
} catch (PDOException $e) {
    die("Erreur ticket : " . $e->getMessage());
}

// Transactions du ticket
try {
    $stmt = $pdo->prepare("SELECT * FROM ticket_transactions WHERE ticket_id = ? ORDER BY transaction_date DESC");
    $stmt->execute([$ticket_id]);
    $transactions = $stmt->fetchAll();
} catch (PDOException $e) {
    $transactions = [];
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Détails du Ticket</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/vendez.css">
</head>
<body class="bg-gradient-to-br from-purple-900 to-gray-900 min-h-screen text-white">
    <div class="container mx-auto px-4 py-8 max-w-3xl">
        <div class="text-center mb-8">
            <h1 class="text-3xl font-bold">
                <i class="fas fa-ticket-alt mr-2 text-purple-400"></i>
                Ticket #<?= htmlspecialchars($ticket['ticket_number']) ?>
            </h1>
            <p class="text-sm text-gray-300">Produit : <?= htmlspecialchars($ticket['product_title']) ?></p>
        </div>

        <div class="bg-white bg-opacity-10 p-6 rounded-lg mb-6">
            <h2 class="text-lg font-semibold mb-2 text-purple-300"><i class="fas fa-user"></i> Acheteur</h2>
            <p><strong>Nom :</strong> <?= htmlspecialchars($ticket['buyer_username']) ?></p>
            <p><strong>Email :</strong> <?= htmlspecialchars($ticket['buyer_email']) ?></p>
        </div>

        <div class="bg-white bg-opacity-10 p-6 rounded-lg mb-6">
            <h2 class="text-lg font-semibold mb-2 text-purple-300"><i class="fas fa-info-circle"></i> Informations Ticket</h2>
            <p><strong>Statut :</strong> <?= htmlspecialchars($ticket['status']) ?></p>
            <p><strong>Date de création :</strong> <?= htmlspecialchars($ticket['created_at']) ?></p>
            <p><strong>Produit associé :</strong> <?= htmlspecialchars($ticket['product_title']) ?></p>
        </div>

        <?php if ($transactions): ?>
            <div class="bg-white bg-opacity-10 p-6 rounded-lg mb-6">
                <h2 class="text-lg font-semibold mb-2 text-purple-300"><i class="fas fa-history"></i> Transactions</h2>
                <ul class="list-disc list-inside space-y-2 text-sm text-gray-200">
                    <?php foreach ($transactions as $txn): ?>
                        <li>
                            [<?= htmlspecialchars($txn['transaction_date']) ?>] 
                            <?= htmlspecialchars($txn['type']) ?> - 
                            <?= htmlspecialchars($txn['details']) ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php else: ?>
            <p class="text-gray-400 italic mb-6">Aucune transaction enregistrée pour ce ticket.</p>
        <?php endif; ?>

        <div class="text-center">
            <a href="seller-products.php" class="text-purple-400 underline hover:text-purple-200">
                <i class="fas fa-arrow-left"></i> Retour à mes produits
            </a>
        </div>
    </div>
</body>
</html>
