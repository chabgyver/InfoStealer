<?php
session_start();
define('ROOT_PATH', realpath(dirname(__FILE__)));
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'auth.php';

if (!isLoggedIn() || ($_SESSION['role'] ?? '') !== 'seller') {
    redirectToLogin();
}

$user_id = $_SESSION['user_id'];

// Récupération des produits
try {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->execute([$user_id]);
    $products = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Erreur chargement produits : " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mes tombolas - Tombola</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/vendez.css">
</head>
<body class="bg-gradient-to-br from-purple-900 to-gray-900 min-h-screen text-white">
    <div class="container mx-auto px-4 py-8 max-w-5xl">
        <div class="text-center mb-10 fade-in">
            <h1 class="text-4xl font-bold mb-2">
                <i class="fas fa-boxes mr-2" style="color: var(--primary-color);"></i>
                Mes Tombolas
            </h1>
            <p class="text-gray-300">Liste de vos produits mis en vente sous forme de tombola</p>
        </div>

        <?php if (empty($products)) : ?>
            <div class="text-center text-gray-400">
                <i class="fas fa-info-circle text-2xl mb-2"></i>
                <p>Vous n’avez encore créé aucune tombola.</p>
                <a href="sell.php" class="underline text-purple-400 mt-4 inline-block">Créer une première tombola</a>
            </div>
        <?php else : ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 fade-in">
                <?php foreach ($products as $product): ?>
                    <div class="bg-white bg-opacity-10 rounded-lg p-6 shadow-md">
                        <?php if (!empty($product['image'])): ?>
                            <img src="<?= htmlspecialchars($product['image']) ?>" alt="Produit" class="w-full h-48 object-cover mb-4 rounded">
                        <?php endif; ?>

                        <h2 class="text-xl font-semibold mb-2"><?= htmlspecialchars($product['title']) ?></h2>
                        <p class="text-sm text-gray-300 mb-2"><?= htmlspecialchars(substr($product['description'], 0, 120)) ?>...</p>
                        <p class="text-sm text-gray-400">Tickets : <?= $product['total_tickets'] ?> | Prix unitaire : <?= number_format($product['price'], 2, ',', ' ') ?> €</p>

                        <div class="mt-4 flex justify-between items-center">
                            <a href="ticket-details.php?product_id=<?= $product['product_id'] ?>" class="text-purple-400 hover:underline text-sm">
                                <i class="fas fa-ticket-alt"></i> Voir les tickets
                            </a>
                            <a href="edit-product.php?id=<?= $product['product_id'] ?>" class="text-blue-400 hover:underline text-sm">
                                <i class="fas fa-edit"></i> Modifier
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
