<?php
session_start();
define('ROOT_PATH', realpath(dirname(__FILE__)));
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'auth.php';

if (!isLoggedIn() || ($_SESSION['role'] ?? '') !== 'seller') {
    redirectToLogin();
}

$user_id = $_SESSION['user_id'];
$product_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Récupérer le produit à modifier
try {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE product_id = ? AND user_id = ?");
    $stmt->execute([$product_id, $user_id]);
    $product = $stmt->fetch();

    if (!$product) {
        die("Produit introuvable ou accès refusé.");
    }
} catch (PDOException $e) {
    die("Erreur récupération produit : " . $e->getMessage());
}

// Récupérer les catégories
try {
    $stmt = $pdo->query("SELECT id, name FROM categories WHERE status = 'active' ORDER BY name");
    $categories = $stmt->fetchAll();
} catch (PDOException $e) {
    $categories = [];
}

// CSRF
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier un produit</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/vendez.css">
</head>
<body class="bg-gradient-to-br from-purple-900 to-gray-900 min-h-screen text-white">
    <div class="container mx-auto px-4 py-8 max-w-4xl">
        <div class="text-center mb-10 fade-in">
            <h1 class="text-4xl font-bold mb-2">
                <i class="fas fa-edit mr-2" style="color: var(--primary-color);"></i>
                Modifier votre produit
            </h1>
            <p class="text-gray-300">Mettez à jour les informations de votre tombola</p>
        </div>

        <form action="update-product.php" method="POST" enctype="multipart/form-data" class="space-y-6">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            <input type="hidden" name="product_id" value="<?= $product['product_id'] ?>">

            <div>
                <label class="block text-sm font-medium text-gray-300 mb-2">Titre *</label>
                <input type="text" name="title" value="<?= htmlspecialchars($product['title']) ?>" required class="form-input">
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-300 mb-2">Description *</label>
                <textarea name="description" rows="4" required class="form-input"><?= htmlspecialchars($product['description']) ?></textarea>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-300 mb-2">Catégorie *</label>
                <select name="category_id" class="form-input" required>
                    <option value="">-- Choisir une catégorie --</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>" <?= ($cat['id'] == $product['category_id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-300 mb-2">Nombre de tickets *</label>
                <input type="number" name="total_tickets" value="<?= $product['total_tickets'] ?>" required class="form-input">
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-300 mb-2">Prix par ticket (€) *</label>
                <input type="number" step="0.01" name="price" value="<?= $product['price'] ?>" required class="form-input">
            </div>

            <!-- Optionnel : changer l’image -->
            <div>
                <label class="block text-sm font-medium text-gray-300 mb-2">Changer l’image (facultatif)</label>
                <input type="file" name="image" accept="image/*" class="form-input bg-white text-black">
                <?php if (!empty($product['image'])): ?>
                    <p class="text-xs mt-2">Image actuelle : <a href="<?= $product['image'] ?>" class="underline text-purple-400" target="_blank">voir</a></p>
                <?php endif; ?>
            </div>

            <button type="submit" class="w-full py-3 bg-purple-600 hover:bg-purple-700 text-white font-semibold rounded-lg transition">
                <i class="fas fa-save mr-2"></i>Enregistrer les modifications
            </button>
        </form>
    </div>
</body>
</html>
