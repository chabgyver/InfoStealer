// Gestion des pages
function showPage(pageId) {
    document.querySelectorAll('.page-content').forEach(page => {
        page.classList.remove('active');
    });
    document.getElementById(pageId)?.classList.add('active');
    currentPage = pageId;
    
    if (pageId === 'admin-dashboard') {
        initializeAdminDashboard();
    }
}

// Gestion du menu utilisateur
function toggleUserMenu() {
    const dropdown = document.getElementById('userDropdown');
    if (dropdown) {
        dropdown.classList.toggle('show');
    }
}

// Fermeture du menu utilisateur en cliquant ailleurs
document.addEventListener('click', function(e) {
    if (!e.target.closest('.user-menu')) {
        const dropdown = document.getElementById('userDropdown');
        if (dropdown) {
            dropdown.classList.remove('show');
        }
    }
});

// Gestion des touches du clavier
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closePurchasePopup();
        const dropdown = document.getElementById('userDropdown');
        if (dropdown) {
            dropdown.classList.remove('show');
        }
    }
});

// Initialisation de la barre de recherche
function initializeSearchBar() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const query = this.value.toLowerCase();
            const filteredProducts = products.filter(p => 
                p.title.toLowerCase().includes(query) || 
                p.description.toLowerCase().includes(query)
            );
            renderProducts(filteredProducts);
        });
    }
}

// Initialisation des méthodes de paiement
function initializePaymentMethods() {
    document.querySelectorAll('.payment-method').forEach(method => {
        method.addEventListener('click', function() {
            document.querySelectorAll('.payment-method').forEach(m => m.classList.remove('selected'));
            this.classList.add('selected');
        });
    });
}

// Affichage des notifications
function showNotification(message, type = 'success') {
    const notification = document.getElementById('notification');
    const notificationText = document.getElementById('notificationText');
    
    if (notification && notificationText) {
        notification.className = `notification ${type}`;
        notificationText.textContent = message;
        notification.classList.add('show');
        
        setTimeout(() => {
            notification.classList.remove('show');
        }, 3000);
    }
}

// Variables globales
let currentUser = null;
let currentPage = 'home';
let currentFilter = 'all';
let currentProduct = null;
let products = [];

// Filtrage des produits par catégorie
function filterByCategory(category) {
    currentFilter = category;
    
    // Mettre à jour le bouton actif
    document.querySelectorAll('.category-filter button').forEach(btn => {
        btn.classList.toggle('active', btn.getAttribute('data-category') === category);
    });
    
    // Filtrer les produits
    let filteredProducts = [...products];
    
    if (category !== 'all') {
        filteredProducts = filteredProducts.filter(
            product => product.category_slug === category
        );
    }
    
    // Appliquer les autres filtres actifs
    filteredProducts = applyActiveFilters(filteredProducts);
    
    // Afficher les produits filtrés
    renderProducts(filteredProducts);
}

// Filtrage des produits par statut (nouveautés, populaires, etc.)
function filterProducts(filterType) {
    let filteredProducts = [...products];
    
    // Réinitialiser tous les boutons de filtre
    document.querySelectorAll('.filter-buttons button').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Activer le bouton cliqué
    event.target.classList.add('active');
    
    // Appliquer le filtre
    switch(filterType) {
        case 'new':
            filteredProducts = filteredProducts.filter(p => p.is_new);
            break;
        case 'popular':
            filteredProducts = filteredProducts.filter(p => p.is_popular);
            break;
        case 'almost-sold':
            filteredProducts = filteredProducts.filter(p => 
                (p.tickets_sold / p.total_tickets) >= 0.8
            );
            break;
        case 'ending-soon':
            // Exemple: produits qui se terminent dans moins de 3 jours
            filteredProducts = filteredProducts.filter(p => {
                const endDate = new Date(p.end_date);
                const now = new Date();
                const diffTime = endDate - now;
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                return diffDays <= 3 && diffDays >= 0;
            });
            break;
        // 'all' est géré par défaut
    }
    
    // Appliquer les autres filtres actifs (catégorie, recherche)
    filteredProducts = applyActiveFilters(filteredProducts);
    
    // Afficher les produits filtrés
    renderProducts(filteredProducts);
}

// Appliquer tous les filtres actifs
function applyActiveFilters(productsToFilter) {
    let result = [...productsToFilter];
    
    // Filtre de recherche
    const searchInput = document.getElementById('searchInput');
    if (searchInput && searchInput.value) {
        const query = searchInput.value.toLowerCase();
        result = result.filter(p => 
            p.title.toLowerCase().includes(query) || 
            p.description.toLowerCase().includes(query)
        );
    }
    
    // Filtre de catégorie (si autre que 'all')
    if (currentFilter && currentFilter !== 'all') {
        result = result.filter(p => p.category_slug === currentFilter);
    }
    
    return result;
}

// Initialisation au chargement du DOM
document.addEventListener('DOMContentLoaded', function() {
    // Charger les produits depuis l'API
    fetchProducts();
    
    // Initialiser les composants
    initializeSearchBar();
    initializePaymentMethods();
    checkAuthStatus();
});

// Fonction pour charger les produits depuis l'API
async function fetchProducts() {
    try {
        const response = await fetch('api/products.php');
        if (!response.ok) {
            throw new Error('Erreur lors du chargement des produits');
        }
        products = await response.json();
        renderProducts(products);
    } catch (error) {
        console.error('Erreur:', error);
        showNotification('Erreur lors du chargement des produits', 'error');
    }
}

// Rendu des produits
function renderProducts(productsToRender = []) {
    const grid = document.getElementById('productGrid');
    if (!grid) return;
    
    grid.innerHTML = '';
    
    if (productsToRender.length === 0) {
        grid.innerHTML = '<div class="no-products">Aucun produit trouvé</div>';
        return;
    }
    
    productsToRender.forEach(product => {
        const productCard = createProductCard(product);
        grid.appendChild(productCard);
    });
}

// Création d'une carte de produit
function createProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card';
    
    const progressPercentage = Math.min(100, (product.tickets_sold / product.total_tickets) * 100);
    const remainingTickets = product.total_tickets - product.tickets_sold;
    
    let badges = '';
    if (product.is_new) badges += '<span class="badge new">Nouveau</span>';
    if (product.is_popular) badges += '<span class="badge hot">Populaire</span>';
    
    card.innerHTML = `
        <div class="product-image-container">
            <img src="${product.images?.[0] || 'assets/images/placeholder.jpg'}" alt="${product.title}" class="product-image">
            ${badges}
        </div>
        <div class="product-content">
            <h3 class="product-title">${product.title}</h3>
            <p class="product-description">${product.description || ''}</p>
            <div class="product-meta">
                <div class="product-price">${parseFloat(product.price).toFixed(2)}€</div>
                <div class="ticket-info">
                    <span>${product.ticket_price}€/ticket</span>
                    <span>${remainingTickets}/${product.total_tickets} tickets</span>
                </div>
            </div>
            <div class="progress-bar">
                <div class="progress-fill" style="width: ${progressPercentage}%"></div>
            </div>
            <button class="btn btn-success w-full mt-4" onclick="openPurchasePopup(${product.id})">
                <i class="fas fa-ticket-alt mr-2"></i>
                Acheter un ticket
            </button>
        </div>
    `;
    
    return card;
}

// Gestion de l'authentification
function checkAuthStatus() {
    // Vérifier si l'utilisateur est connecté
    const userData = localStorage.getItem('currentUser');
    if (userData) {
        currentUser = JSON.parse(userData);
        updateUserMenu();
    }
}

// Mise à jour du menu utilisateur
function updateUserMenu() {
    const userMenuText = document.getElementById('userMenuText');
    const userMenuBtn = document.getElementById('userMenuBtn');
    
    if (currentUser && userMenuText && userMenuBtn) {
        userMenuText.textContent = currentUser.username;
        userMenuBtn.innerHTML = `
            <i class="fas fa-user"></i> ${currentUser.username}
        `;
    }
}

// Déconnexion
function logout() {
    currentUser = null;
    localStorage.removeItem('currentUser');
    
    const userMenuText = document.getElementById('userMenuText');
    const userMenuBtn = document.getElementById('userMenuBtn');
    
    if (userMenuText && userMenuBtn) {
        userMenuText.textContent = 'Se connecter';
        userMenuBtn.innerHTML = '<i class="fas fa-user"></i> Se connecter';
    }
    
    const dropdown = document.getElementById('userDropdown');
    if (dropdown) {
        dropdown.classList.remove('show');
    }
    
    showNotification('Déconnexion réussie', 'success');
}
