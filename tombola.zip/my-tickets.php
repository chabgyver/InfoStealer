<?php
require_once 'includes/config.php';
require_once 'auth.php';

// Check if user is logged in
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Get user's tickets
try {
    $stmt = $pdo->prepare("
        SELECT 
            t.ticket_id,
            t.serial_number,
            t.purchase_date,
            p.product_id,
            p.title as product_title,
            p.description,
            p.price as product_price,
            p.ticket_price,
            p.total_tickets,
            p.tickets_sold,
            p.status as product_status,
            p.winner_id,
            p.draw_date,
            pi.image_path as product_image,
            c.name as category_name,
            trans.amount as paid_amount,
            trans.created_at as purchase_time
        FROM tickets t
        JOIN products p ON t.product_id = p.product_id
        LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
        LEFT JOIN categories c ON p.category_id = c.category_id
        LEFT JOIN transactions trans ON t.transaction_id = trans.transaction_id
        WHERE t.buyer_id = ?
        ORDER BY t.purchase_date DESC
    ");
    $stmt->execute([$user_id]);
    $tickets = $stmt->fetchAll();
} catch (PDOException $e) {
    $tickets = [];
    $error = "Erreur lors du chargement des tickets";
}

// Group tickets by product
$grouped_tickets = [];
foreach ($tickets as $ticket) {
    $product_id = $ticket['product_id'];
    if (!isset($grouped_tickets[$product_id])) {
        $grouped_tickets[$product_id] = [
            'product' => $ticket,
            'tickets' => []
        ];
    }
    $grouped_tickets[$product_id]['tickets'][] = $ticket;
}

include 'includes/header.php';
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes Tickets - Tombola</title>
    <link rel="stylesheet" href="css/layout.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/animations.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="tickets-page">
        <div class="container">
            <div class="page-header">
                <h1>🎫 Mes Tickets</h1>
                <p>Consultez tous vos tickets de tombola et suivez les tirages</p>
            </div>

            <?php if (isset($error)): ?>
                <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <?php if (empty($grouped_tickets)): ?>
                <div class="empty-state">
                    <span class="empty-icon">🎫</span>
                    <h2>Aucun ticket</h2>
                    <p>Vous n'avez encore acheté aucun ticket de tombola</p>
                    <a href="index.php" class="btn btn-primary">Acheter des tickets</a>
                </div>
            <?php else: ?>
                <div class="tickets-grid">
                    <?php foreach ($grouped_tickets as $group): ?>
                        <?php 
                        $product = $group['product'];
                        $product_tickets = $group['tickets'];
                        $tickets_count = count($product_tickets);
                        $progress = ($product['tickets_sold'] / $product['total_tickets']) * 100;
                        $is_winner = $product['winner_id'] == $user_id;
                        $is_completed = $product['product_status'] === 'completed';
                        ?>
                        
                        <div class="ticket-card <?= $is_winner ? 'winner-card' : '' ?>">
                            <?php if ($is_winner): ?>
                                <div class="winner-badge">🏆 GAGNANT !</div>
                            <?php endif; ?>
                            
                            <div class="ticket-header">
                                <div class="product-image">
                                    <?php if ($product['product_image']): ?>
                                        <img src="<?= htmlspecialchars($product['product_image']) ?>" alt="<?= htmlspecialchars($product['product_title']) ?>">
                                    <?php else: ?>
                                        <div class="no-image">📦</div>
                                    <?php endif; ?>
                                </div>
                                <div class="product-info">
                                    <h3><?= htmlspecialchars($product['product_title']) ?></h3>
                                    <p class="category"><?= htmlspecialchars($product['category_name']) ?></p>
                                    <p class="product-value">Valeur: <?= number_format($product['product_price'], 2) ?> €</p>
                                </div>
                            </div>

                            <div class="ticket-details">
                                <div class="tickets-owned">
                                    <h4>Mes tickets (<?= $tickets_count ?>)</h4>
                                    <div class="ticket-numbers">
                                        <?php foreach ($product_tickets as $ticket): ?>
                                            <span class="ticket-number">#<?= htmlspecialchars($ticket['serial_number']) ?></span>
                                        <?php endforeach; ?>
                                    </div>
                                </div>

                                <div class="product-progress">
                                    <div class="progress-info">
                                        <span>Progression</span>
                                        <span><?= $product['tickets_sold'] ?>/<?= $product['total_tickets'] ?> tickets</span>
                                    </div>
                                    <div class="progress-bar">
                                        <div class="progress-fill" style="width: <?= $progress ?>%"></div>
                                    </div>
                                </div>

                                <div class="purchase-info">
                                    <div class="info-row">
                                        <span>Acheté le:</span>
                                        <span><?= date('d/m/Y à H:i', strtotime($product['purchase_time'])) ?></span>
                                    </div>
                                    <div class="info-row">
                                        <span>Montant payé:</span>
                                        <span><?= number_format($product['paid_amount'], 2) ?> €</span>
                                    </div>
                                    <div class="info-row">
                                        <span>Statut:</span>
                                        <span class="status-badge status-<?= $product['product_status'] ?>">
                                            <?= getProductStatusText($product['product_status']) ?>
                                        </span>
                                    </div>
                                </div>

                                <?php if ($product['draw_date']): ?>
                                    <div class="draw-info">
                                        <div class="info-row">
                                            <span>Date de tirage:</span>
                                            <span><?= date('d/m/Y à H:i', strtotime($product['draw_date'])) ?></span>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <?php if ($is_completed && !$is_winner): ?>
                                    <div class="result-info">
                                        <span class="not-winner">❌ Pas gagnant cette fois</span>
                                        <p>Le tirage a été effectué. Tentez votre chance sur d'autres produits !</p>
                                    </div>
                                <?php elseif ($is_winner): ?>
                                    <div class="winner-info">
                                        <h4>🎉 Félicitations !</h4>
                                        <p>Vous avez remporté ce produit ! Nous vous contacterons bientôt pour la livraison.</p>
                                        <button class="btn btn-primary" onclick="contactSupport(<?= $product['product_id'] ?>)">
                                            Contacter le support
                                        </button>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="ticket-actions">
                                <a href="index.php?product=<?= $product['product_id'] ?>" class="btn btn-secondary btn-sm">
                                    Voir le produit
                                </a>
                                <button class="btn btn-outline btn-sm" onclick="shareTicket(<?= $product['product_id'] ?>)">
                                    Partager
                                </button>
                                <button class="btn btn-outline btn-sm" onclick="downloadTicket(<?= $product['product_id'] ?>)">
                                    Télécharger
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Statistics Section -->
                <div class="tickets-stats">
                    <h2>📊 Mes Statistiques</h2>
                    <div class="stats-grid">
                        <div class="stat-card">
                            <div class="stat-icon">🎫</div>
                            <div class="stat-content">
                                <h3>Total Tickets</h3>
                                <p class="stat-number"><?= count($tickets) ?></p>
                            </div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-icon">🛒</div>
                            <div class="stat-content">
                                <h3>Produits</h3>
                                <p class="stat-number"><?= count($grouped_tickets) ?></p>
                            </div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-icon">💰</div>
                            <div class="stat-content">
                                <h3>Total Dépensé</h3>
                                <p class="stat-number"><?= number_format(array_sum(array_column($tickets, 'paid_amount')), 2) ?> €</p>
                            </div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-icon">🏆</div>
                            <div class="stat-content">
                                <h3>Victoires</h3>
                                <p class="stat-number"><?= count(array_filter($grouped_tickets, function($g) use ($user_id) { return $g['product']['winner_id'] == $user_id; })) ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
			</div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script>
        function contactSupport(productId) {
            // Open contact form or redirect to support
            const message = `Bonjour, je suis le gagnant du produit ID ${productId}. Pouvez-vous me contacter pour organiser la livraison ?`;
            const mailtoLink = `mailto:support@tombola.fr?subject=Gagnant - Produit ${productId}&body=${encodeURIComponent(message)}`;
            window.location.href = mailtoLink;
        }

        function shareTicket(productId) {
            if (navigator.share) {
                navigator.share({
                    title: 'Mes tickets de tombola',
                    text: 'Regardez mes tickets pour ce super produit !',
                    url: window.location.origin + '/index.php?product=' + productId
                });
            } else {
                // Fallback - copy to clipboard
                const url = window.location.origin + '/index.php?product=' + productId;
                navigator.clipboard.writeText(url).then(() => {
                    showNotification('Lien copié dans le presse-papiers !', 'success');
                });
            }
        }

        function downloadTicket(productId) {
            // Generate and download ticket PDF
            window.open(`generate-ticket-pdf.php?product=${productId}`, '_blank');
        }

        function showNotification(message, type) {
            const notification = document.createElement('div');
            notification.className = `notification notification-${type}`;
            notification.textContent = message;
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.remove();
            }, 3000);
        }

        // Auto-refresh for active draws
        setInterval(() => {
            const activeCards = document.querySelectorAll('.ticket-card:not(.winner-card)');
            if (activeCards.length > 0) {
                // Check for updates every 30 seconds
                fetch('api/tickets.php?action=check_updates')
                    .then(response => response.json())
                    .then(data => {
                        if (data.hasUpdates) {
                            location.reload();
                        }
                    })
                    .catch(error => console.log('Update check failed'));
            }
        }, 30000);
    </script>

    <style>
        .tickets-page {
            padding: 40px 0;
            min-height: 100vh;
            background: #f8f9fa;
        }

        .page-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .page-header h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            color: #333;
        }

        .page-header p {
            font-size: 1.1rem;
            color: #666;
        }

        .empty-state {
            text-align: center;
            padding: 80px 20px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .empty-icon {
            font-size: 4rem;
            margin-bottom: 20px;
            display: block;
        }

        .empty-state h2 {
            margin-bottom: 10px;
            color: #333;
        }

        .empty-state p {
            margin-bottom: 30px;
            color: #666;
        }

        .tickets-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(400px, 1fr));
            gap: 30px;
            margin-bottom: 60px;
        }

        .ticket-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            position: relative;
        }

        .ticket-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }

        .winner-card {
            border: 3px solid #28a745;
            background: linear-gradient(135deg, #fff 0%, #f8fff8 100%);
        }

        .winner-badge {
            position: absolute;
            top: 15px;
            right: 15px;
            background: #28a745;
            color: white;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            z-index: 2;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }

        .ticket-header {
            display: flex;
            padding: 20px;
            border-bottom: 1px solid #e9ecef;
            gap: 15px;
        }

        .product-image {
            width: 80px;
            height: 80px;
            border-radius: 10px;
            overflow: hidden;
            flex-shrink: 0;
        }

        .product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .no-image {
            width: 100%;
            height: 100%;
            background: #f8f9fa;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            color: #666;
        }

        .product-info {
            flex: 1;
        }

        .product-info h3 {
            margin: 0 0 5px 0;
            color: #333;
            font-size: 1.2rem;
        }

        .category {
            margin: 0 0 10px 0;
            color: #667eea;
            font-size: 14px;
            font-weight: 500;
        }

        .product-value {
            margin: 0;
            color: #28a745;
            font-weight: bold;
            font-size: 1.1rem;
        }

        .ticket-details {
            padding: 20px;
        }

        .tickets-owned {
            margin-bottom: 20px;
        }

        .tickets-owned h4 {
            margin: 0 0 10px 0;
            color: #333;
            font-size: 1rem;
        }

        .ticket-numbers {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .ticket-number {
            background: #667eea;
            color: white;
            padding: 4px 8px;
            border-radius: 6px;
            font-family: monospace;
            font-size: 12px;
            font-weight: bold;
        }

        .product-progress {
            margin-bottom: 20px;
        }

        .progress-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 14px;
            color: #666;
        }

        .progress-bar {
            width: 100%;
            height: 8px;
            background: #e9ecef;
            border-radius: 4px;
            overflow: hidden;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            transition: width 0.3s ease;
        }

        .purchase-info,
        .draw-info {
            margin-bottom: 15px;
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 14px;
        }

        .info-row span:first-child {
            color: #666;
        }

        .info-row span:last-child {
            color: #333;
            font-weight: 500;
        }

        .status-badge {
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 12px;
            font-weight: 500;
        }

        .status-active {
            background: #d1ecf1;
            color: #0c5460;
        }

        .status-completed {
            background: #d4edda;
            color: #155724;
        }

        .status-cancelled {
            background: #f8d7da;
            color: #721c24;
        }

        .result-info {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
            margin-bottom: 15px;
        }

        .not-winner {
            display: block;
            font-size: 16px;
            margin-bottom: 8px;
            color: #dc3545;
        }

        .winner-info {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            margin-bottom: 15px;
        }

        .winner-info h4 {
            margin: 0 0 10px 0;
            font-size: 1.3rem;
        }

        .winner-info p {
            margin: 0 0 15px 0;
        }

        .ticket-actions {
            padding: 15px 20px;
            border-top: 1px solid #e9ecef;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .ticket-actions .btn {
            flex: 1;
            min-width: 100px;
        }

        .tickets-stats {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .tickets-stats h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }

        .stat-card {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 10px;
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-3px);
        }

        .stat-icon {
            font-size: 2rem;
            width: 60px;
            text-align: center;
        }

        .stat-content h3 {
            margin: 0 0 5px 0;
            color: #666;
            font-size: 14px;
            font-weight: 500;
        }

        .stat-number {
            margin: 0;
            font-size: 1.5rem;
            font-weight: bold;
            color: #333;
        }

        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 8px;
            color: white;
            font-weight: 500;
            z-index: 1000;
            transform: translateX(100%);
            transition: transform 0.3s ease;
        }

        .notification.show {
            transform: translateX(0);
        }

        .notification-success {
            background: #28a745;
        }

        .notification-error {
            background: #dc3545;
        }

        .notification-warning {
            background: #ffc107;
            color: #333;
        }

        @media (max-width: 768px) {
            .tickets-grid {
                grid-template-columns: 1fr;
                gap: 20px;
            }

            .ticket-header {
                flex-direction: column;
                text-align: center;
            }

            .product-image {
                align-self: center;
            }

            .ticket-actions {
                flex-direction: column;
            }

            .ticket-actions .btn {
                width: 100%;
            }

            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 480px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</body>
</html>

<?php
function getProductStatusText($status) {
    $statusTexts = [
        'draft' => 'Brouillon',
        'active' => 'Actif',
        'completed' => 'Terminé',
        'cancelled' => 'Annulé'
    ];
    return $statusTexts[$status] ?? $status;
}
?>