<?php
// Activer l'affichage des erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Démarrer la mise en tampon de sortie pour éviter les problèmes d'en-têtes
ob_start();

// Forcer le mode développement
putenv('APP_ENV=development');

echo "Démarrage du script de test...\n";

define('ROOT_PATH', dirname(__DIR__));
echo "ROOT_PATH: " . ROOT_PATH . "\n";

echo "Chargement de la configuration...\n";

// Vérifier si le fichier de configuration existe
$configFile = __DIR__ . '/includes/config.php';
if (!file_exists($configFile)) {
    die("ERREUR: Le fichier de configuration n'existe pas: $configFile\n");
}

// Inclure le fichier de configuration
echo "Inclusion de $configFile\n";
require_once $configFile;

// Vérifier si les constantes de base de données sont définies
$requiredConstants = ['DB_HOST', 'DB_NAME', 'DB_USER', 'DB_PASS'];
foreach ($requiredConstants as $constant) {
    if (!defined($constant)) {
        echo "ATTENTION: La constante $constant n'est pas définie.\n";
    } else {
        echo "$constant = " . (in_array($constant, ['DB_PASS']) ? '***' : constant($constant)) . "\n";
    }
}

echo "Configuration chargée.\n";

echo "Tentative de connexion à la base de données...\n";

try {
    $stmt = $pdo->query('SELECT 1');
    echo "Connexion à la base de données réussie!\n";
    
    // Afficher les informations sur la base de données
    $stmt = $pdo->query("SELECT DATABASE() as db, USER() as user, VERSION() as version");
    $dbInfo = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "\nInformations sur la base de données :\n";
    echo "Base de données : " . $dbInfo['db'] . "\n";
    echo "Utilisateur : " . $dbInfo['user'] . "\n";
    echo "Version MySQL : " . $dbInfo['version'] . "\n\n";
    
    // Vérifier si la table products existe
    $tableExists = $pdo->query("SHOW TABLES LIKE 'products'")->rowCount() > 0;
    echo "Table 'products' existe: " . ($tableExists ? 'Oui' : 'Non') . "\n";
    
    if ($tableExists) {
        // Afficher la structure de la table products
        $stmt = $pdo->query("DESCRIBE products");
        echo "\nStructure de la table 'products':\n";
        echo str_pad("Champ", 20) . str_pad("Type", 20) . "Null\n";
        echo str_repeat("-", 50) . "\n";
        
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo str_pad($row['Field'], 20) . str_pad($row['Type'], 20) . $row['Null'] . "\n";
        }
    }
    
} catch (PDOException $e) {
    echo "Erreur de connexion à la base de données: " . $e->getMessage() . "\n";
    echo "DSN: mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET . "\n";
    echo "Utilisateur: " . DB_USER . "\n";
}
