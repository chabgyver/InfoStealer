<?php
// Configuration des erreurs pour le développement
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Chargement de la configuration
require_once __DIR__ . '/includes/config.php';

// Vérification de la méthode de requête
if (php_sapi_name() === 'cli') {
    // Mode ligne de commande
    $options = getopt('', ['fresh', 'refresh', 'rollback:', 'help']);
    
    if (isset($options['help'])) {
        echo "Utilisation : php migrate.php [options]\n";
        echo "Options :\n";
        echo "  --help       Affiche cette aide\n";
        echo "  --fresh      Supprime toutes les tables et recrée le schéma\n";
        echo "  --refresh    Recrée le schéma (équivaut à --rollback=0 --migrate)\n";
        echo "  --rollback=N  Annule les N dernières migrations\n";
        exit(0);
    }
    
    $migrator = new Migrator($pdo);
    
    try {
        if (isset($options['fresh'])) {
            $migrator->fresh();
        } elseif (isset($options['refresh'])) {
            $migrator->refresh();
        } elseif (isset($options['rollback'])) {
            $migrator->rollback((int)$options['rollback']);
        } else {
            $migrator->migrate();
        }
    } catch (Exception $e) {
        echo "Erreur : " . $e->getMessage() . "\n";
        exit(1);
    }
} else {
    // Mode navigateur
    header('Content-Type: text/plain');
    
    if (!isset($_GET['token']) || $_GET['token'] !== 'your-secure-token') {
        die('Accès non autorisé');
    }
    
    $action = $_GET['action'] ?? 'migrate';
    $migrator = new Migrator($pdo);
    
    try {
        switch ($action) {
            case 'fresh':
                $migrator->fresh();
                break;
            case 'refresh':
                $migrator->refresh();
                break;
            case 'rollback':
                $steps = isset($_GET['steps']) ? (int)$_GET['steps'] : 1;
                $migrator->rollback($steps);
                break;
            case 'migrate':
            default:
                $migrator->migrate();
        }
        
        echo "Migration terminée avec succès.\n";
    } catch (Exception $e) {
        echo "Erreur : " . $e->getMessage() . "\n";
    }
}

class Migrator {
    private $pdo;
    private $migrationsDir;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->migrationsDir = __DIR__ . '/migrations';
        $this->ensureMigrationsTable();
    }
    
    public function migrate() {
        $this->pdo->beginTransaction();
        
        try {
            $appliedMigrations = $this->getAppliedMigrations();
            $migrationFiles = $this->getMigrationFiles();
            $migrationsToRun = array_diff($migrationFiles, $appliedMigrations);
            
            if (empty($migrationsToRun)) {
                echo "Aucune migration à exécuter.\n";
                return;
            }
            
            sort($migrationsToRun);
            
            foreach ($migrationsToRun as $migration) {
                $this->runMigration($migration, 'up');
                $this->saveMigration($migration);
                echo "Migration appliquée : $migration\n";
            }
            
            $this->pdo->commit();
        } catch (Exception $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }
    
    public function rollback($steps = 1) {
        $this->pdo->beginTransaction();
        
        try {
            $appliedMigrations = $this->getAppliedMigrations();
            $migrationsToRollback = array_slice(array_reverse($appliedMigrations), 0, $steps);
            
            if (empty($migrationsToRollback)) {
                echo "Aucune migration à annuler.\n";
                return;
            }
            
            foreach ($migrationsToRollback as $migration) {
                $this->runMigration($migration, 'down');
                $this->removeMigration($migration);
                echo "Migration annulée : $migration\n";
            }
            
            $this->pdo->commit();
        } catch (Exception $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }
    
    public function refresh() {
        $this->rollback(0); // Annule toutes les migrations
        $this->migrate();
    }
    
    public function fresh() {
        $this->pdo->exec('SET FOREIGN_KEY_CHECKS = 0');
        
        $tables = $this->pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
        
        foreach ($tables as $table) {
            if ($table !== 'migrations') {
                $this->pdo->exec("DROP TABLE IF EXISTS `$table`");
            }
        }
        
        $this->pdo->exec('TRUNCATE TABLE migrations');
        $this->pdo->exec('SET FOREIGN_KEY_CHECKS = 1');
        
        $this->migrate();
    }
    
    private function ensureMigrationsTable() {
        $this->pdo->exec("
            CREATE TABLE IF NOT EXISTS migrations (
                migration_id INT AUTO_INCREMENT PRIMARY KEY,
                migration VARCHAR(255) NOT NULL UNIQUE,
                batch INT NOT NULL,
                applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
    }
    
    private function getAppliedMigrations() {
        $stmt = $this->pdo->query('SELECT migration FROM migrations ORDER BY migration');
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    
    private function getMigrationFiles() {
        $files = [];
        $dir = new DirectoryIterator($this->migrationsDir);
        
        foreach ($dir as $file) {
            if ($file->isFile() && $file->getExtension() === 'php') {
                $files[] = $file->getBasename();
            }
        }
        
        sort($files);
        return $files;
    }
    
    private function runMigration($migration, $method) {
        require_once $this->migrationsDir . '/' . $migration;
        
        $className = 'Migration_' . pathinfo($migration, PATHINFO_FILENAME);
        $migrationInstance = new $className();
        
        if (!method_exists($migrationInstance, $method)) {
            throw new Exception("La méthode $method n'existe pas dans la migration $migration");
        }
        
        $migrationInstance->$method($this->pdo);
    }
    
    private function saveMigration($migration) {
        $batch = $this->pdo->query('SELECT COALESCE(MAX(batch), 0) + 1 FROM migrations')->fetchColumn();
        
        $stmt = $this->pdo->prepare('INSERT INTO migrations (migration, batch) VALUES (?, ?)');
        $stmt->execute([$migration, $batch]);
    }
    
    private function removeMigration($migration) {
        $stmt = $this->pdo->prepare('DELETE FROM migrations WHERE migration = ?');
        $stmt->execute([$migration]);
    }
}
