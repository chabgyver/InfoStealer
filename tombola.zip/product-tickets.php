<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/functions.php';

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$product_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Vérifier que le produit appartient bien au vendeur
try {
    $stmt = $pdo->prepare("SELECT title FROM products WHERE product_id = ? AND seller_id = ?");
    $stmt->execute([$product_id, $user_id]);
    $product = $stmt->fetch();

    if (!$product) {
        $_SESSION['error_message'] = "Produit non trouvé ou accès non autorisé";
        header('Location: seller-products.php');
        exit;
    }
} catch (PDOException $e) {
    error_log("Erreur vérification produit: " . $e->getMessage());
    $_SESSION['error_message'] = "Erreur lors de l'accès au produit";
    header('Location: seller-products.php');
    exit;
}

// Récupérer les tickets vendus pour ce produit
try {
    // Pagination
    $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
    $limit = 20;
    $offset = ($page - 1) * $limit;

    $stmt = $pdo->prepare("
        SELECT t.*, u.username, u.email 
        FROM tickets t
        JOIN users u ON t.user_id = u.user_id
        WHERE t.product_id = ?
        ORDER BY t.purchase_date DESC
        LIMIT ? OFFSET ?
    ");
    $stmt->execute([$product_id, $limit, $offset]);
    $tickets = $stmt->fetchAll();

    // Compter le total
    $count_stmt = $pdo->prepare("SELECT COUNT(*) as total FROM tickets WHERE product_id = ?");
    $count_stmt->execute([$product_id]);
    $total_tickets = $count_stmt->fetch()['total'];
    $total_pages = ceil($total_tickets / $limit);

} catch (PDOException $e) {
    error_log("Erreur récupération tickets: " . $e->getMessage());
    $tickets = [];
    $total_pages = 1;
}

$title = "Tickets pour " . htmlspecialchars($product['title']);
include 'includes/header.php';
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Tickets vendus</h1>
        <a href="seller-products.php" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> Retour aux produits
        </a>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <h2><?= htmlspecialchars($product['title']) ?></h2>
            <p class="mb-0">Total tickets vendus: <strong><?= $total_tickets ?></strong></p>
        </div>
    </div>

    <?php if (empty($tickets)): ?>
        <div class="alert alert-info">
            Aucun ticket vendu pour ce produit.
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead class="table-light">
                    <tr>
                        <th>N° Ticket</th>
                        <th>Acheteur</th>
                        <th>Date d'achat</th>
                        <th>Statut</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tickets as $ticket): ?>
                        <tr>
                            <td><?= htmlspecialchars($ticket['ticket_number']) ?></td>
                            <td>
                                <?= htmlspecialchars($ticket['username']) ?><br>
                                <small class="text-muted"><?= htmlspecialchars($ticket['email']) ?></small>
                            </td>
                            <td><?= date('d/m/Y H:i', strtotime($ticket['purchase_date'])) ?></td>
                            <td>
                                <span class="badge bg-<?= $ticket['status'] === 'valid' ? 'success' : 'secondary' ?>">
                                    <?= ucfirst($ticket['status']) ?>
                                </span>
                            </td>
                            <td>
                                <a href="ticket-details.php?id=<?= $ticket['ticket_id'] ?>" 
                                   class="btn btn-sm btn-outline-primary" title="Détails">
                                    <i class="bi bi-eye"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if ($total_pages > 1): ?>
            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center">
                    <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                        <a class="page-link" href="?id=<?= $product_id ?>&page=<?= $page - 1 ?>">Précédent</a>
                    </li>
                    
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                            <a class="page-link" href="?id=<?= $product_id ?>&page=<?= $i ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                    
                    <li class="page-item <?= $page >= $total_pages ? 'disabled' : '' ?>">
                        <a class="page-link" href="?id=<?= $product_id ?>&page=<?= $page + 1 ?>">Suivant</a>
                    </li>
                </ul>
            </nav>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
