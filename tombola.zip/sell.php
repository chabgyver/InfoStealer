<?php
session_start();
define('ROOT_PATH', realpath(dirname(__FILE__)));
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'auth.php';

if (!isLoggedIn() || ($_SESSION['role'] ?? '') !== 'seller') {
    redirectToLogin();
}

$user_id = $_SESSION['user_id'];

try {
    $stmt = $pdo->query("SELECT * FROM categories WHERE status = 'active' ORDER BY name");
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $categories = [];
}

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Créer une Tombola</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/vendez.css">
</head>
<body class="bg-gradient-to-br from-purple-900 to-gray-900 min-h-screen text-white">
    <div class="container mx-auto px-4 py-8 max-w-4xl">
        <div class="text-center mb-10 fade-in">
            <h1 class="text-4xl font-bold mb-2">
                <i class="fas fa-plus-circle mr-2" style="color: var(--primary-color);"></i>
                Créer une Tombola
            </h1>
            <p class="text-gray-300">Vendez vos produits via notre système de tombola</p>
        </div>

        <form id="sellForm" class="space-y-6" action="process_sell.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

            <div>
                <label class="block text-sm font-medium text-gray-300 mb-2">Titre de l’annonce *</label>
                <input type="text" name="title" required class="form-input" placeholder="Ex: iPhone 14 Pro Max 256GB">
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-300 mb-2">Description *</label>
                <textarea name="description" rows="4" required class="form-input" placeholder="Détaillez votre produit..."></textarea>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-300 mb-2">Catégorie *</label>
                <select name="category_id" class="form-input" required>
                    <option value="">-- Choisir une catégorie --</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-300 mb-2">Nombre de tickets *</label>
                <input type="number" name="total_tickets" required class="form-input" placeholder="Ex: 100">
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-300 mb-2">Prix d’un ticket (€) *</label>
                <input type="number" step="0.01" name="price" required class="form-input" placeholder="Ex: 2.50">
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-300 mb-2">Image du produit *</label>
                <input type="file" name="image" accept="image/*" required class="form-input bg-white text-black">
            </div>

            <button type="submit" class="w-full py-3 bg-purple-600 hover:bg-purple-700 text-white font-semibold rounded-lg transition">
                <i class="fas fa-check-circle mr-2"></i>Créer la tombola
            </button>
        </form>
    </div>
</body>
</html>
