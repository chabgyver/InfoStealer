<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

if (!isLoggedIn()) {
    die(json_encode(['error' => 'Veuillez vous connecter']));
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $product_id = $data['product_id'];
    $quantity = $data['quantity'];
    $user_id = $_SESSION['user_id'];
    
    // Vérifier disponibilité
    $stmt = $pdo->prepare("
        SELECT total_tickets, tickets_sold, ticket_price 
        FROM products 
        WHERE product_id = ? AND status = 'active'
    ");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch();
    
    if (!$product || ($product['tickets_sold'] + $quantity) > $product['total_tickets']) {
        die(json_encode(['error' => 'Pas assez de tickets disponibles']));
    }
    
    // Créer transaction
    $amount = $product['ticket_price'] * $quantity;
    
    $stmt = $pdo->prepare("
        INSERT INTO transactions (user_id, product_id, amount, tickets_count, status)
        VALUES (?, ?, ?, ?, 'completed')
    ");
    $stmt->execute([$user_id, $product_id, $amount, $quantity]);
    
    $transaction_id = $pdo->lastInsertId();
    
    // Générer tickets
    for ($i = 0; $i < $quantity; $i++) {
        $serial = generateTicketSerial();
        
        $stmt = $pdo->prepare("
            INSERT INTO tickets (product_id, buyer_id, serial_number, transaction_id)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$product_id, $user_id, $serial, $transaction_id]);
    }
    
    // Mettre à jour compteur
    $stmt = $pdo->prepare("
        UPDATE products 
        SET tickets_sold = tickets_sold + ? 
        WHERE product_id = ?
    ");
    $stmt->execute([$quantity, $product_id]);
    
    echo json_encode(['success' => true, 'transaction_id' => $transaction_id]);
}

function generateTicketSerial() {
    return strtoupper(substr(md5(uniqid()), 0, 8));
}
?>
