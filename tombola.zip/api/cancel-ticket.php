<?php
header('Content-Type: application/json');
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Vérifier CSRF et méthode POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SERVER['HTTP_X_CSRF_TOKEN']) || 
    $_SERVER['HTTP_X_CSRF_TOKEN'] !== $_SESSION['csrf_token']) {
    http_response_code(403);
    die(json_encode(['success' => false, 'error' => 'Accès non autorisé']));
}

$data = json_decode(file_get_contents('php://input'), true);
$ticket_id = isset($data['ticket_id']) ? intval($data['ticket_id']) : 0;
$reason = isset($data['reason']) ? trim($data['reason']) : '';

// Validation
if ($ticket_id <= 0 || empty($reason)) {
    http_response_code(400);
    die(json_encode(['success' => false, 'error' => 'Données invalides']));
}

try {
    // Vérifier permissions + récupérer infos ticket
    // ... (code de vérification et traitement)
    
    // Si tout est valide :
    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    error_log('Erreur annulation ticket: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Erreur serveur']);
}
