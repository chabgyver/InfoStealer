<?php
require_once '../includes/config.php';
require_once '../auth.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

switch ($method) {
    case 'GET':
        handleGet($action);
        break;
    case 'POST':
        handlePost();
        break;
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
}

function handleGet($action) {
    global $pdo;
    
    switch ($action) {
        case 'list':
            getTransactionsList();
            break;
        case 'user':
            getUserTransactions();
            break;
        case 'stats':
            getTransactionsStats();
            break;
        default:
            http_response_code(400);
            echo json_encode(['error' => 'Invalid action']);
    }
}

function getTransactionsList() {
    global $pdo;
    
    if (!isAdmin()) {
        http_response_code(403);
        echo json_encode(['error' => 'Access denied']);
        return;
    }
    
    try {
        $stmt = $pdo->query("
            SELECT t.*, u.username, p.title as product_title
            FROM transactions t
            JOIN users u ON t.user_id = u.user_id
            JOIN products p ON t.product_id = p.product_id
            ORDER BY t.created_at DESC
            LIMIT 100
        ");
        
        $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($transactions);
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['error' => 'Database error']);
    }
}

function getUserTransactions() {
    global $pdo;
    
    session_start();
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Not authenticated']);
        return;
    }
    
    try {
        $stmt = $pdo->prepare("
            SELECT t.*, p.title as product_title, p.price as product_price
            FROM transactions t
            JOIN products p ON t.product_id = p.product_id
            WHERE t.user_id = ?
            ORDER BY t.created_at DESC
        ");
        
        $stmt->execute([$_SESSION['user_id']]);
        $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($transactions);
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['error' => 'Database error']);
    }
}

function getTransactionsStats() {
    global $pdo;
    
    if (!isAdmin()) {
        http_response_code(403);
        echo json_encode(['error' => 'Access denied']);
        return;
    }
    
    try {
        $stmt = $pdo->query("
            SELECT 
                COUNT(*) as total_transactions,
                SUM(amount) as total_revenue,
                SUM(tickets_count) as total_tickets,
                AVG(amount) as avg_transaction,
                COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_transactions,
                COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_transactions
            FROM transactions
        ");
        
        $stats = $stmt->fetch(PDO::FETCH_ASSOC);
        echo json_encode($stats);
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['error' => 'Database error']);
    }
}

function handlePost() {
    global $pdo;
    
    $input = json_decode(file_get_contents('php://input'), true);
    $action = $input['action'] ?? '';
    
    switch ($action) {
        case 'create':
            createTransaction($input);
            break;
        case 'update_status':
            updateTransactionStatus($input);
            break;
        default:
            http_response_code(400);
            echo json_encode(['error' => 'Invalid action']);
    }
}

function createTransaction($data) {
    global $pdo;
    
    session_start();
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Not authenticated']);
        return;
    }
    
    try {
        $pdo->beginTransaction();
        
        // Create transaction
        $stmt = $pdo->prepare("
            INSERT INTO transactions (user_id, product_id, amount, tickets_count, status)
            VALUES (?, ?, ?, ?, 'completed')
        ");
        
        $stmt->execute([
            $_SESSION['user_id'],
            $data['product_id'],
            $data['amount'],
            $data['tickets_count']
        ]);
        
        $transaction_id = $pdo->lastInsertId();
        
        // Generate tickets
        for ($i = 0; $i < $data['tickets_count']; $i++) {
            $serial = generateTicketSerial();
            
            $stmt = $pdo->prepare("
                INSERT INTO tickets (product_id, buyer_id, serial_number, transaction_id)
                VALUES (?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $data['product_id'],
                $_SESSION['user_id'],
                $serial,
                $transaction_id
            ]);
        }
        
        // Update product tickets sold
        $stmt = $pdo->prepare("
            UPDATE products 
            SET tickets_sold = tickets_sold + ? 
            WHERE product_id = ?
        ");
        
        $stmt->execute([$data['tickets_count'], $data['product_id']]);
        
        $pdo->commit();
        
        echo json_encode(['success' => true, 'transaction_id' => $transaction_id]);
    } catch (PDOException $e) {
        $pdo->rollback();
        error_log("Database error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['error' => 'Database error']);
    }
}

function generateTicketSerial() {
    return strtoupper(substr(md5(uniqid()), 0, 8));
}

function updateTransactionStatus($data) {
    global $pdo;
    
    if (!isAdmin()) {
        http_response_code(403);
        echo json_encode(['error' => 'Access denied']);
        return;
    }
    
    try {
        $stmt = $pdo->prepare("
            UPDATE transactions 
            SET status = ? 
            WHERE transaction_id = ?
        ");
        
        $stmt->execute([$data['status'], $data['transaction_id']]);
        
        echo json_encode(['success' => true]);
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['error' => 'Database error']);
    }
}

function isAdmin() {
    session_start();
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;
}
?>
