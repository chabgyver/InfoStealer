<?php
// Configuration des erreurs pour le développement
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Activer la journalisation des erreurs PHP
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/php_errors.log');

// Créer le répertoire de logs s'il n'existe pas
if (!file_exists(__DIR__ . '/../logs')) {
    mkdir(__DIR__ . '/../logs', 0755, true);
}

// Fonction de journalisation personnalisée
function logMessage($message, $data = null) {
    $log = '[' . date('Y-m-d H:i:s') . '] ' . $message . PHP_EOL;
    if ($data !== null) {
        $log .= 'Data: ' . print_r($data, true) . PHP_EOL;
    }
    error_log($log, 3, __DIR__ . '/../logs/api_products.log');
}

logMessage('Début de la requête vers products.php');

require_once __DIR__ . '/../includes/config.php';

// Journalisation des erreurs
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/error.log');

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Gestion des requêtes OPTIONS pour le CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

try {
    // Log des en-têtes HTTP pour le débogage
    $headers = [];
    foreach (getallheaders() as $name => $value) {
        $headers[$name] = $value;
    }
    logMessage('En-têtes de la requête: ', $headers);
    
    logMessage('Méthode de requête: ' . $_SERVER['REQUEST_METHOD']);
    logMessage('Paramètres GET: ', $_GET);
    logMessage('Paramètres POST: ', $_POST);
    
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        if (isset($_GET['id'])) {
            logMessage('Appel à getProduct avec ID: ' . $_GET['id']);
            getProduct($_GET['id']);
        } else {
            $category = isset($_GET['category']) ? $_GET['category'] : null;
            logMessage('Appel à getAllProducts avec catégorie: ' . ($category ?? 'aucune'));
            
            // Test de connexion à la base de données et vérification des tables
            global $pdo;
            try {
                // Test de connexion
                $stmt = $pdo->query('SELECT 1');
                logMessage('Test de connexion à la base de données réussi');
                
                // Vérifier si la table products existe
                $stmt = $pdo->query("SHOW TABLES LIKE 'products'");
                $tableExists = $stmt->rowCount() > 0;
                
                if (!$tableExists) {
                    logMessage('ERREUR: La table products n\'existe pas dans la base de données');
                    throw new Exception('La table products n\'existe pas dans la base de données');
                }
                
                // Vérifier la structure de la table
                $stmt = $pdo->query('DESCRIBE products');
                $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
                logMessage('Colonnes de la table products: ', $columns);
                
            } catch (PDOException $e) {
                logMessage('Erreur de connexion à la base de données: ' . $e->getMessage());
                throw $e;
            }
            
            getAllProducts($category);
        }
    } else {
        $error = 'Méthode non autorisée: ' . $_SERVER['REQUEST_METHOD'];
        logMessage($error);
        http_response_code(405);
        echo json_encode(['error' => $error]);
    }
} catch (Exception $e) {
    $error = 'Erreur dans products.php: ' . $e->getMessage();
    logMessage($error);
    logMessage('Stack trace: ' . $e->getTraceAsString());
    
    http_response_code(500);
    $response = ['error' => 'Une erreur est survenue lors du chargement des produits.'];
    if (defined('APP_DEBUG') && APP_DEBUG) {
        $response['debug'] = [
            'message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine()
        ];
    }
    echo json_encode($response);
}

function getAllProducts($category = null) {
    global $pdo;
    logMessage('Début de getAllProducts avec catégorie: ' . ($category ?? 'toutes'));
    
    $query = "
        SELECT 
            p.product_id as id,
            p.title,
            p.description,
            p.price,
            p.ticket_price,
            p.total_tickets,
            p.tickets_sold,
            p.created_at,
            p.status,
            c.name as category,
            (
                SELECT JSON_ARRAYAGG(image_path)
                FROM product_images pi 
                WHERE pi.product_id = p.product_id
            ) as images,
            (p.tickets_sold / p.total_tickets) >= 0.8 as is_hot,
            p.created_at > DATE_SUB(NOW(), INTERVAL 7 DAY) as is_new
        FROM products p
        JOIN categories c ON p.category_id = c.category_id
        WHERE p.status = 'active'
    ";
    
    $params = [];
    
    if ($category) {
        $query .= " AND c.slug = ?";
        $params[] = $category;
    }
    
    $query .= " ORDER BY p.created_at DESC";
    
    logMessage('Exécution de la requête SQL: ' . $query);
    logMessage('Paramètres de la requête: ', $params);
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    logMessage('Nombre de produits récupérés: ' . count($products));
    
    // Décoder les images JSON et formater les données
    foreach ($products as &$product) {
        $product['images'] = $product['images'] ? json_decode($product['images']) : ['assets/images/placeholder.jpg'];
        $product['is_hot'] = (bool)$product['is_hot'];
        $product['is_new'] = (bool)$product['is_new'];
        $product['price'] = (float)$product['price'];
        $product['ticket_price'] = (float)$product['ticket_price'];
        $product['total_tickets'] = (int)$product['total_tickets'];
        $product['tickets_sold'] = (int)$product['tickets_sold'];
    }
    
    $response = json_encode($products);
    if (json_last_error() !== JSON_ERROR_NONE) {
        $error = 'Erreur d\'encodage JSON: ' . json_last_error_msg();
        logMessage($error);
        http_response_code(500);
        echo json_encode(['error' => $error]);
        return;
    }
    
    logMessage('Réponse JSON générée avec succès');
    echo $response;
}

function getProduct($id) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT 
            p.*,
            c.name as category,
            (
                SELECT JSON_ARRAYAGG(image_path)
                FROM product_images pi 
                WHERE pi.product_id = p.product_id
            ) as images,
            (p.tickets_sold / p.total_tickets) >= 0.8 as is_hot,
            p.created_at > DATE_SUB(NOW(), INTERVAL 7 DAY) as is_new
        FROM products p
        JOIN categories c ON p.category_id = c.category_id
        WHERE p.product_id = ? AND p.status = 'active'
    ");
    
    $stmt->execute([$id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($product) {
        $product['images'] = $product['images'] ? json_decode($product['images']) : ['assets/images/placeholder.jpg'];
        $product['is_hot'] = (bool)$product['is_hot'];
        $product['is_new'] = (bool)$product['is_new'];
        $product['price'] = (float)$product['price'];
        $product['ticket_price'] = (float)$product['ticket_price'];
        $product['total_tickets'] = (int)$product['total_tickets'];
        $product['tickets_sold'] = (int)$product['tickets_sold'];
        
        echo json_encode($product);
    } else {
        http_response_code(404);
        echo json_encode(['error' => 'Produit non trouvé']);
    }
}
?>
