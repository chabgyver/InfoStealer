<?php
session_start();
define('ROOT_PATH', realpath(dirname(__FILE__)));
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'auth.php';

if (!isLoggedIn() || ($_SESSION['role'] ?? '') !== 'seller') {
    redirectToLogin();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Méthode non autorisée.");
}

if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    die("Token CSRF invalide.");
}

$user_id = $_SESSION['user_id'];
$product_id = intval($_POST['product_id'] ?? 0);

// Vérifier que le produit appartient bien à l’utilisateur
try {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE product_id = ? AND user_id = ?");
    $stmt->execute([$product_id, $user_id]);
    $product = $stmt->fetch();

    if (!$product) {
        die("Produit non trouvé ou accès interdit.");
    }
} catch (PDOException $e) {
    die("Erreur de validation : " . $e->getMessage());
}

// Récupérer les données
$title = trim($_POST['title'] ?? '');
$description = trim($_POST['description'] ?? '');
$category_id = intval($_POST['category_id'] ?? 0);
$total_tickets = intval($_POST['total_tickets'] ?? 0);
$price = floatval($_POST['price'] ?? 0);
$errors = [];

// Validation
if ($title === '' || strlen($title) > 100) {
    $errors[] = "Le titre est requis et limité à 100 caractères.";
}
if ($description === '' || strlen($description) > 2000) {
    $errors[] = "La description est requise et limitée à 2000 caractères.";
}
if ($category_id <= 0) {
    $errors[] = "Catégorie invalide.";
}
if ($total_tickets <= 0) {
    $errors[] = "Nombre de tickets invalide.";
}
if ($price <= 0) {
    $errors[] = "Prix invalide.";
}

// Gestion image (facultatif)
$image_path = $product['image'];
if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
    $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
    if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
        $new_name = uniqid("product_") . '.' . $ext;
        $destination = __DIR__ . '/uploads/' . $new_name;
        if (move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {
            $image_path = 'uploads/' . $new_name;
        } else {
            $errors[] = "Erreur lors de l’upload de la nouvelle image.";
        }
    } else {
        $errors[] = "Format d’image invalide.";
    }
}

// En cas d’erreur
if (!empty($errors)) {
    echo "<h2>Erreurs :</h2><ul>";
    foreach ($errors as $e) {
        echo "<li>" . htmlspecialchars($e) . "</li>";
    }
    echo "</ul><a href='edit-product.php?id=$product_id'>⟵ Retour</a>";
    exit;
}

// Mise à jour
try {
    $stmt = $pdo->prepare("
        UPDATE products SET
            title = ?, description = ?, category_id = ?, total_tickets = ?, price = ?, image = ?, updated_at = NOW()
        WHERE product_id = ? AND user_id = ?
    ");
    $stmt->execute([
        $title,
        $description,
        $category_id,
        $total_tickets,
        $price,
        $image_path,
        $product_id,
        $user_id
    ]);

    header("Location: seller-products.php");
    exit;
} catch (PDOException $e) {
    die("Erreur lors de la mise à jour : " . $e->getMessage());
}
