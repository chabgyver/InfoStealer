<?php
session_start();
require_once 'includes/config.php';

// Vérifier si l'utilisateur est admin
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    header('Location: login.php');
    exit;
}

$message = '';
$error = '';

// Traitement des actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'add_product':
            $error = addProduct();
            break;
        case 'edit_product':
            $error = editProduct();
            break;
        case 'delete_product':
            $error = deleteProduct();
            break;
        case 'change_status':
            $error = changeProductStatus();
            break;
        case 'draw_winner':
            $error = drawWinner();
            break;
    }
}

// Récupération de la liste des produits
try {
    $stmt = $pdo->query("
        SELECT p.*, c.name as category_name, u.username as seller_name,
               COUNT(t.ticket_id) as tickets_sold_count,
               pi.image_path as main_image
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.category_id
        LEFT JOIN users u ON p.seller_id = u.user_id
        LEFT JOIN tickets t ON p.product_id = t.product_id
        LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
        GROUP BY p.product_id
        ORDER BY p.created_at DESC
    ");
    $products = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = "Erreur lors de la récupération des produits";
    $products = [];
}

// Récupération des catégories pour le formulaire
try {
    $stmt = $pdo->query("SELECT * FROM categories ORDER BY name");
    $categories = $stmt->fetchAll();
} catch (PDOException $e) {
    $categories = [];
}

// Récupération des utilisateurs (vendeurs)
try {
    $stmt = $pdo->query("SELECT user_id, username FROM users ORDER BY username");
    $users = $stmt->fetchAll();
} catch (PDOException $e) {
    $users = [];
}

// Fonctions
function addProduct() {
    global $pdo;
    
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $price = floatval($_POST['price']);
    $ticket_price = floatval($_POST['ticket_price']);
    $total_tickets = intval($_POST['total_tickets']);
    $category_id = intval($_POST['category_id']);
    $seller_id = intval($_POST['seller_id']);
    $status = $_POST['status'];
    $draw_date = !empty($_POST['draw_date']) ? $_POST['draw_date'] : null;
    
    // Validation
    if (empty($title) || empty($description) || $price <= 0 || $ticket_price <= 0 || $total_tickets <= 0) {
        return "Tous les champs sont requis et les valeurs numériques doivent être positives";
    }
    
    try {
        $pdo->beginTransaction();
        
        // Insertion du produit
        $stmt = $pdo->prepare("
            INSERT INTO products (title, description, price, ticket_price, total_tickets, 
                                category_id, seller_id, status, draw_date, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $stmt->execute([
            $title, $description, $price, $ticket_price, $total_tickets,
            $category_id, $seller_id, $status, $draw_date
        ]);
        
        $product_id = $pdo->lastInsertId();
        
        // Gestion des images
        if (isset($_FILES['images']) && !empty($_FILES['images']['name'][0])) {
            $upload_dir = 'uploads/products/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            
            foreach ($_FILES['images']['tmp_name'] as $key => $tmp_name) {
                if ($_FILES['images']['error'][$key] === 0) {
                    $filename = 'product_' . $product_id . '_' . $key . '_' . time() . '.jpg';
                    $filepath = $upload_dir . $filename;
                    
                    if (move_uploaded_file($tmp_name, $filepath)) {
                        $is_primary = ($key === 0) ? 1 : 0;
                        
                        $stmt = $pdo->prepare("
                            INSERT INTO product_images (product_id, image_path, is_primary, created_at)
                            VALUES (?, ?, ?, NOW())
                        ");
                        $stmt->execute([$product_id, $filepath, $is_primary]);
                    }
                }
            }
        }
        
        // Log de l'action
        $stmt = $pdo->prepare("
            INSERT INTO product_logs (action, product_id, user_id, data, created_at)
            VALUES ('create', ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $product_id,
            $_SESSION['user_id'],
            json_encode(['title' => $title, 'price' => $price, 'total_tickets' => $total_tickets])
        ]);
        
        $pdo->commit();
        
        global $message;
        $message = "Produit ajouté avec succès";
        return '';
        
    } catch (PDOException $e) {
        $pdo->rollback();
        return "Erreur lors de l'ajout du produit: " . $e->getMessage();
    }
}

function editProduct() {
    global $pdo;
    
    $product_id = intval($_POST['product_id']);
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $price = floatval($_POST['price']);
    $ticket_price = floatval($_POST['ticket_price']);
    $total_tickets = intval($_POST['total_tickets']);
    $category_id = intval($_POST['category_id']);
    $seller_id = intval($_POST['seller_id']);
    $status = $_POST['status'];
    $draw_date = !empty($_POST['draw_date']) ? $_POST['draw_date'] : null;
    
    try {
        $pdo->beginTransaction();
        
        // Mise à jour du produit
        $stmt = $pdo->prepare("
            UPDATE products 
            SET title = ?, description = ?, price = ?, ticket_price = ?, 
                total_tickets = ?, category_id = ?, seller_id = ?, 
                status = ?, draw_date = ?, updated_at = NOW()
            WHERE product_id = ?
        ");
        
        $stmt->execute([
            $title, $description, $price, $ticket_price, $total_tickets,
            $category_id, $seller_id, $status, $draw_date, $product_id
        ]);
        
        // Gestion des nouvelles images si présentes
        if (isset($_FILES['images']) && !empty($_FILES['images']['name'][0])) {
            $upload_dir = 'uploads/products/';
            
            foreach ($_FILES['images']['tmp_name'] as $key => $tmp_name) {
                if ($_FILES['images']['error'][$key] === 0) {
                    $filename = 'product_' . $product_id . '_' . $key . '_' . time() . '.jpg';
                    $filepath = $upload_dir . $filename;
                    
                    if (move_uploaded_file($tmp_name, $filepath)) {
                        $stmt = $pdo->prepare("
                            INSERT INTO product_images (product_id, image_path, is_primary, created_at)
                            VALUES (?, ?, 0, NOW())
                        ");
                        $stmt->execute([$product_id, $filepath]);
                    }
                }
            }
        }
        
        // Log de l'action
        $stmt = $pdo->prepare("
            INSERT INTO product_logs (action, product_id, user_id, data, created_at)
            VALUES ('update', ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $product_id,
            $_SESSION['user_id'],
            json_encode(['title' => $title, 'price' => $price])
        ]);
        
        $pdo->commit();
        
        global $message;
        $message = "Produit modifié avec succès";
        return '';
        
    } catch (PDOException $e) {
        $pdo->rollback();
        return "Erreur lors de la modification: " . $e->getMessage();
    }
}

function deleteProduct() {
    global $pdo;
    
    $product_id = intval($_POST['product_id']);
    
    try {
        $pdo->beginTransaction();
        
        // Vérifier s'il y a des tickets vendus
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM tickets WHERE product_id = ?");
        $stmt->execute([$product_id]);
        $ticket_count = $stmt->fetchColumn();
        
        if ($ticket_count > 0) {
            return "Impossible de supprimer un produit avec des tickets vendus";
        }
        
        // Supprimer les images
        $stmt = $pdo->prepare("SELECT image_path FROM product_images WHERE product_id = ?");
        $stmt->execute([$product_id]);
        $images = $stmt->fetchAll();
        
        foreach ($images as $image) {
            if (file_exists($image['image_path'])) {
                unlink($image['image_path']);
            }
        }
        
        // Supprimer de la base de données
        $stmt = $pdo->prepare("DELETE FROM product_images WHERE product_id = ?");
        $stmt->execute([$product_id]);
        
        $stmt = $pdo->prepare("DELETE FROM products WHERE product_id = ?");
        $stmt->execute([$product_id]);
        
        // Log de l'action
        $stmt = $pdo->prepare("
            INSERT INTO product_logs (action, product_id, user_id, data, created_at)
            VALUES ('delete', ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $product_id,
            $_SESSION['user_id'],
            json_encode(['deleted_at' => date('Y-m-d H:i:s')])
        ]);
        
        $pdo->commit();
        
        global $message;
        $message = "Produit supprimé avec succès";
        return '';
        
    } catch (PDOException $e) {
        $pdo->rollback();
        return "Erreur lors de la suppression: " . $e->getMessage();
    }
}

function changeProductStatus() {
    global $pdo;
    
    $product_id = intval($_POST['product_id']);
    $new_status = $_POST['new_status'];
    
    try {
        $stmt = $pdo->prepare("
            UPDATE products 
            SET status = ?, updated_at = NOW()
            WHERE product_id = ?
        ");
        $stmt->execute([$new_status, $product_id]);
        
        // Log de l'action
        $stmt = $pdo->prepare("
            INSERT INTO product_logs (action, product_id, user_id, data, created_at)
            VALUES ('status_change', ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $product_id,
            $_SESSION['user_id'],
            json_encode(['new_status' => $new_status])
        ]);
        
        global $message;
        $message = "Statut modifié avec succès";
        return '';
        
    } catch (PDOException $e) {
        return "Erreur lors du changement de statut: " . $e->getMessage();
    }
}

function drawWinner() {
    global $pdo;
    
    $product_id = intval($_POST['product_id']);
    
    try {
        $pdo->beginTransaction();
        
        // Vérifier que le produit est éligible au tirage
        $stmt = $pdo->prepare("
            SELECT p.*, COUNT(t.ticket_id) as tickets_sold_count
            FROM products p
            LEFT JOIN tickets t ON p.product_id = t.product_id
            WHERE p.product_id = ? AND p.status = 'active'
            GROUP BY p.product_id
        ");
        $stmt->execute([$product_id]);
        $product = $stmt->fetch();
        
        if (!$product) {
            return "Produit non trouvé ou non actif";
        }
        
        if ($product['tickets_sold_count'] == 0) {
            return "Aucun ticket vendu pour ce produit";
        }
        
        // Sélectionner un ticket gagnant au hasard
        $stmt = $pdo->prepare("
            SELECT t.*, u.username, u.email
            FROM tickets t
            JOIN users u ON t.buyer_id = u.user_id
            WHERE t.product_id = ?
            ORDER BY RAND()
            LIMIT 1
        ");
        $stmt->execute([$product_id]);
        $winning_ticket = $stmt->fetch();
        
        if (!$winning_ticket) {
            return "Erreur lors de la sélection du gagnant";
        }
        
        // Mettre à jour le produit avec le gagnant
        $stmt = $pdo->prepare("
            UPDATE products 
            SET winner_id = ?, status = 'completed', updated_at = NOW()
            WHERE product_id = ?
        ");
        $stmt->execute([$winning_ticket['buyer_id'], $product_id]);
        
        // Créer une notification pour le gagnant
        $stmt = $pdo->prepare("
            INSERT INTO notifications (user_id, type, message, created_at)
            VALUES (?, 'winner', ?, NOW())
        ");
        $notification_message = "Félicitations ! Vous avez remporté le produit : " . $product['title'];
        $stmt->execute([$winning_ticket['buyer_id'], $notification_message]);
        
        // Log de l'action
        $stmt = $pdo->prepare("
            INSERT INTO product_logs (action, product_id, user_id, data, created_at)
            VALUES ('draw_winner', ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $product_id,
            $_SESSION['user_id'],
            json_encode([
                'winner_id' => $winning_ticket['buyer_id'],
                'winning_ticket' => $winning_ticket['serial_number'],
                'winner_username' => $winning_ticket['username']
            ])
        ]);
        
        $pdo->commit();
        
        global $message;
        $message = "Tirage effectué ! Gagnant : " . $winning_ticket['username'] . " (Ticket #" . $winning_ticket['serial_number'] . ")";
        return '';
        
    } catch (PDOException $e) {
        $pdo->rollback();
        return "Erreur lors du tirage: " . $e->getMessage();
    }
}

function getStatusBadge($status) {
    switch ($status) {
        case 'draft':
            return '<span class="badge badge-secondary">Brouillon</span>';
        case 'active':
            return '<span class="badge badge-success">Actif</span>';
        case 'completed':
            return '<span class="badge badge-primary">Terminé</span>';
        case 'cancelled':
            return '<span class="badge badge-danger">Annulé</span>';
        default:
            return '<span class="badge badge-light">' . htmlspecialchars($status) . '</span>';
    }
}

function formatDate($date) {
    return $date ? date('d/m/Y H:i', strtotime($date)) : '-';
}

function formatPrice($price) {
    return number_format($price, 2, ',', ' ') . ' €';
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Articles - Admin Tombola</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .admin-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 0;
            margin-bottom: 30px;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .btn-custom {
            border-radius: 25px;
            padding: 8px 20px;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 12px;
            letter-spacing: 0.5px;
        }
        .table {
            font-size: 14px;
        }
        .table th {
            border-top: none;
            background-color: #f8f9fa;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 12px;
            letter-spacing: 0.5px;
        }
        .badge {
            font-size: 11px;
            padding: 5px 10px;
            border-radius: 20px;
        }
        .product-image {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 8px;
        }
        .modal-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px 15px 0 0;
        }
        .form-control, .form-select {
            border-radius: 10px;
            border: 2px solid #e9ecef;
        }
        .form-control:focus, .form-select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        .alert {
            border-radius: 15px;
            border: none;
        }
        .navbar-custom {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-radius: 15px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<!-- Header Admin -->
<div class="admin-header">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1><i class="fas fa-boxes"></i> Gestion des Articles</h1>
                <p class="mb-0">Administration des produits de tombola</p>
            </div>
            <div class="col-md-6 text-end">
                <a href="admin.php" class="btn btn-light btn-custom me-2">
                    <i class="fas fa-arrow-left"></i> Retour Dashboard
                </a>
                <a href="logout.php" class="btn btn-outline-light btn-custom">
                    <i class="fas fa-sign-out-alt"></i> Déconnexion
                </a>
            </div>
        </div>
    </div>
</div>

<div class="container mt-4">
    <div class="d-flex justify-content-between mb-4">
        <h1>Gestion des Articles</h1>
        <a href="add-product.php" class="btn btn-primary">
            <i class="bi bi-plus-circle"></i> Ajouter un article
        </a>
    </div>

    <!-- Messages -->
    <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i><?= htmlspecialchars($message) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i><?= htmlspecialchars($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Navigation rapide -->
    <nav class="navbar navbar-expand-lg navbar-light navbar-custom mb-4">
        <div class="container-fluid">
            <div class="navbar-nav">
                <a class="nav-link active" href="#"><i class="fas fa-list"></i> Liste des Articles</a>
                <a class="nav-link" href="admin-categories.php"><i class="fas fa-tags"></i> Catégories</a>
                <a class="nav-link" href="admin-users.php"><i class="fas fa-users"></i> Utilisateurs</a>
            </div>
        </div>
    </nav>

    <!-- Statistiques rapides -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <i class="fas fa-boxes fa-2x text-primary mb-2"></i>
                    <h4><?= count($products) ?></h4>
                    <small class="text-muted">Total Articles</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <i class="fas fa-play fa-2x text-success mb-2"></i>
                    <h4><?= count(array_filter($products, function($p) { return $p['status'] === 'active'; })) ?></h4>
                    <small class="text-muted">Articles Actifs</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <i class="fas fa-check fa-2x text-info mb-2"></i>
                    <h4><?= count(array_filter($products, function($p) { return $p['status'] === 'completed'; })) ?></h4>
                    <small class="text-muted">Articles Terminés</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <i class="fas fa-ticket-alt fa-2x text-warning mb-2"></i>
                    <h4><?= array_sum(array_column($products, 'tickets_sold_count')) ?></h4>
                    <small class="text-muted">Tickets Vendus</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Tableau des articles -->
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="fas fa-list"></i> Liste des Articles</h5>
            <button class="btn btn-primary btn-custom" data-bs-toggle="modal" data-bs-target="#addProductModal">
                <i class="fas fa-plus"></i> Nouvel Article
            </button>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Image</th>
                            <th>Titre</th>
                            <th>Catégorie</th>
                            <th>Vendeur</th>
                            <th>Prix</th>
                            <th>Tickets</th>
                            <th>Statut</th>
                            <th>Date Création</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product): ?>
                            <tr>
                                <td>
                                    <?php if ($product['main_image']): ?>
                                        <img src="<?= htmlspecialchars($product['main_image']) ?>" class="product-image" alt="Image produit">
                                    <?php else: ?>
                                        <div class="product-image bg-light d-flex align-items-center justify-content-center">
                                            <i class="fas fa-image text-muted"></i>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <strong><?= htmlspecialchars($product['title']) ?></strong>
                                    <br><small class="text-muted"><?= htmlspecialchars(substr($product['description'], 0, 50)) ?>...</small>
                                </td>
                                <td><?= htmlspecialchars($product['category_name']) ?></td>
                                <td><?= htmlspecialchars($product['seller_name']) ?></td>
                                <td>
                                    <strong><?= formatPrice($product['price']) ?></strong>
                                    <br><small class="text-muted">Ticket: <?= formatPrice($product['ticket_price']) ?></small>
                                </td>
                                <td>
                                    <span class="fw-bold"><?= $product['tickets_sold_count'] ?></span> / <?= $product['total_tickets'] ?>
                                    <div class="progress mt-1" style="height: 4px;">
                                        <div class="progress-bar" style="width: <?= ($product['tickets_sold_count'] / $product['total_tickets']) * 100 ?>%"></div>
                                    </div>
                                </td>
                                <td><?= getStatusBadge($product['status']) ?></td>
                                <td><small><?= formatDate($product['created_at']) ?></small></td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <button class="btn btn-outline-primary" onclick="editProduct(<?= $product['product_id'] ?>)" title="Modifier">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        
                                        <?php if ($product['status'] === 'active' && $product['tickets_sold_count'] > 0): ?>
                                            <button class="btn btn-outline-success" onclick="drawWinner(<?= $product['product_id'] ?>)" title="Effectuer le tirage">
                                                <i class="fas fa-trophy"></i>
                                            </button>
                                        <?php endif; ?>
                                        
                                        <div class="btn-group btn-group-sm">
                                            <button class="btn btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown" title="Changer statut">
                                                <i class="fas fa-cog"></i>
                                            </button>
                                            <ul class="dropdown-menu">
                                                <?php foreach (['draft' => 'Brouillon', 'active' => 'Actif', 'completed' => 'Terminé', 'cancelled' => 'Annulé'] as $status_key => $status_label): ?>
                                                    <?php if ($status_key !== $product['status']): ?>
                                                        <li>
                                                            <a class="dropdown-item" href="#" onclick="changeStatus(<?= $product['product_id'] ?>, '<?= $status_key ?>')">
                                                                <?= $status_label ?>
                                                            </a>
                                                        </li>
                                                    <?php endif; ?>
                                                <?php endforeach; ?>
                                            </ul>
                                        </div>
                                        
                                        <?php if ($product['tickets_sold_count'] == 0): ?>
                                            <button class="btn btn-outline-danger" onclick="deleteProduct(<?= $product['product_id'] ?>)" title="Supprimer">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Ajout Produit -->
<div class="modal fade" id="addProductModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-plus"></i> Ajouter un Produit</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" value="add_product">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Titre *</label>
                                <input type="text" name="title" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Catégorie *</label>
                                <select name="category_id" class="form-select" required>
                                    <option value="">Choisir une catégorie</option>
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?= $category['category_id'] ?>"><?= htmlspecialchars($category['name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Description *</label>
                        <textarea name="description" class="form-control" rows="3" required></textarea>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-4">
						<div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Prix du produit (€) *</label>
                                <input type="number" name="price" class="form-control" step="0.01" min="0" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Prix du ticket (€) *</label>
                                <input type="number" name="ticket_price" class="form-control" step="0.01" min="0" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Nombre total de tickets *</label>
                                <input type="number" name="total_tickets" class="form-control" min="1" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Vendeur *</label>
                                <select name="seller_id" class="form-select" required>
                                    <option value="">Choisir un vendeur</option>
                                    <?php foreach ($users as $user): ?>
                                        <option value="<?= $user['user_id'] ?>"><?= htmlspecialchars($user['username']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Statut *</label>
                                <select name="status" class="form-select" required>
                                    <option value="draft">Brouillon</option>
                                    <option value="active">Actif</option>
                                    <option value="completed">Terminé</option>
                                    <option value="cancelled">Annulé</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Date de tirage (optionnel)</label>
                        <input type="datetime-local" name="draw_date" class="form-control">
                        <small class="form-text text-muted">Si laissé vide, le tirage sera manuel</small>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Images du produit (max 5)</label>
                        <input type="file" name="images[]" class="form-control" multiple accept="image/*">
                        <small class="form-text text-muted">Formats acceptés: JPG, PNG, GIF. La première image sera l'image principale.</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Ajouter le Produit
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Modification Produit -->
<div class="modal fade" id="editProductModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-edit"></i> Modifier le Produit</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" enctype="multipart/form-data" id="editProductForm">
                <input type="hidden" name="action" value="edit_product">
                <input type="hidden" name="product_id" id="edit_product_id">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Titre *</label>
                                <input type="text" name="title" id="edit_title" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Catégorie *</label>
                                <select name="category_id" id="edit_category_id" class="form-select" required>
                                    <option value="">Choisir une catégorie</option>
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?= $category['category_id'] ?>"><?= htmlspecialchars($category['name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Description *</label>
                        <textarea name="description" id="edit_description" class="form-control" rows="3" required></textarea>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Prix du produit (€) *</label>
                                <input type="number" name="price" id="edit_price" class="form-control" step="0.01" min="0" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Prix du ticket (€) *</label>
                                <input type="number" name="ticket_price" id="edit_ticket_price" class="form-control" step="0.01" min="0" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label class="form-label">Nombre total de tickets *</label>
                                <input type="number" name="total_tickets" id="edit_total_tickets" class="form-control" min="1" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Vendeur *</label>
                                <select name="seller_id" id="edit_seller_id" class="form-select" required>
                                    <option value="">Choisir un vendeur</option>
                                    <?php foreach ($users as $user): ?>
                                        <option value="<?= $user['user_id'] ?>"><?= htmlspecialchars($user['username']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Statut *</label>
                                <select name="status" id="edit_status" class="form-select" required>
                                    <option value="draft">Brouillon</option>
                                    <option value="active">Actif</option>
                                    <option value="completed">Terminé</option>
                                    <option value="cancelled">Annulé</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Date de tirage (optionnel)</label>
                        <input type="datetime-local" name="draw_date" id="edit_draw_date" class="form-control">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Nouvelles images (optionnel)</label>
                        <input type="file" name="images[]" class="form-control" multiple accept="image/*">
                        <small class="form-text text-muted">Les nouvelles images seront ajoutées aux existantes</small>
                    </div>
                    
                    <div id="current_images"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Sauvegarder
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Formulaires cachés pour actions -->
<form id="statusForm" method="POST" style="display: none;">
    <input type="hidden" name="action" value="change_status">
    <input type="hidden" name="product_id" id="status_product_id">
    <input type="hidden" name="new_status" id="new_status">
</form>

<form id="deleteForm" method="POST" style="display: none;">
    <input type="hidden" name="action" value="delete_product">
    <input type="hidden" name="product_id" id="delete_product_id">
</form>

<form id="drawForm" method="POST" style="display: none;">
    <input type="hidden" name="action" value="draw_winner">
    <input type="hidden" name="product_id" id="draw_product_id">
</form>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Données des produits pour JS
const products = <?= json_encode($products) ?>;

function editProduct(productId) {
    const product = products.find(p => p.product_id == productId);
    if (!product) return;
    
    // Remplir le formulaire
    document.getElementById('edit_product_id').value = product.product_id;
    document.getElementById('edit_title').value = product.title;
    document.getElementById('edit_description').value = product.description;
    document.getElementById('edit_price').value = product.price;
    document.getElementById('edit_ticket_price').value = product.ticket_price;
    document.getElementById('edit_total_tickets').value = product.total_tickets;
    document.getElementById('edit_category_id').value = product.category_id;
    document.getElementById('edit_seller_id').value = product.seller_id;
    document.getElementById('edit_status').value = product.status;
    
    // Date de tirage
    if (product.draw_date) {
        const date = new Date(product.draw_date);
        const localDate = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
        document.getElementById('edit_draw_date').value = localDate.toISOString().slice(0, 16);
    } else {
        document.getElementById('edit_draw_date').value = '';
    }
    
    // Afficher les images actuelles
    displayCurrentImages(product.product_id);
    
    // Ouvrir le modal
    new bootstrap.Modal(document.getElementById('editProductModal')).show();
}

function displayCurrentImages(productId) {
    // Cette fonction pourrait faire un appel AJAX pour récupérer les images
    // Pour l'instant, on affiche juste un message
    document.getElementById('current_images').innerHTML = 
        '<div class="alert alert-info"><i class="fas fa-info-circle"></i> Les images actuelles seront conservées. Les nouvelles images seront ajoutées.</div>';
}

function changeStatus(productId, newStatus) {
    if (confirm('Êtes-vous sûr de vouloir changer le statut de ce produit ?')) {
        document.getElementById('status_product_id').value = productId;
        document.getElementById('new_status').value = newStatus;
        document.getElementById('statusForm').submit();
    }
}

function deleteProduct(productId) {
    if (confirm('Êtes-vous sûr de vouloir supprimer ce produit ?\n\nATTENTION: Cette action est irréversible !')) {
        document.getElementById('delete_product_id').value = productId;
        document.getElementById('deleteForm').submit();
    }
}

function drawWinner(productId) {
    const product = products.find(p => p.product_id == productId);
    if (!product) return;
    
    const ticketsSold = product.tickets_sold_count;
    
    if (ticketsSold === 0) {
        alert('Aucun ticket vendu pour ce produit !');
        return;
    }
    
    if (confirm(`Effectuer le tirage pour "${product.title}" ?\n\n${ticketsSold} ticket(s) vendu(s).\n\nCette action est irréversible !`)) {
        document.getElementById('draw_product_id').value = productId;
        document.getElementById('drawForm').submit();
    }
}

// Auto-hide alerts après 5 secondes
setTimeout(function() {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        if (alert.classList.contains('alert-dismissible')) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }
    });
}, 5000);

// Preview d'image lors de l'upload
document.addEventListener('DOMContentLoaded', function() {
    const imageInputs = document.querySelectorAll('input[type="file"][accept*="image"]');
    
    imageInputs.forEach(input => {
        input.addEventListener('change', function() {
            const files = this.files;
            let preview = this.parentNode.querySelector('.image-preview');
            
            if (!preview) {
                preview = document.createElement('div');
                preview.className = 'image-preview mt-2';
                this.parentNode.appendChild(preview);
            }
            
            preview.innerHTML = '';
            
            if (files.length > 5) {
                alert('Maximum 5 images autorisées');
                this.value = '';
                return;
            }
            
            Array.from(files).forEach((file, index) => {
                if (file.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        const img = document.createElement('img');
                        img.src = e.target.result;
                        img.style.width = '60px';
                        img.style.height = '60px';
                        img.style.objectFit = 'cover';
                        img.style.margin = '5px';
                        img.style.border = '2px solid #ddd';
                        img.style.borderRadius = '8px';
                        
                        if (index === 0) {
                            img.style.borderColor = '#007bff';
                            img.title = 'Image principale';
                        }
                        
                        preview.appendChild(img);
                    };
                    reader.readAsDataURL(file);
                }
            });
        });
    });
});

// Calcul automatique du nombre de tickets selon le prix
document.addEventListener('DOMContentLoaded', function() {
    const priceInputs = document.querySelectorAll('input[name="price"], input[name="ticket_price"]');
    
    priceInputs.forEach(input => {
        input.addEventListener('input', function() {
            const form = this.closest('form');
            const priceInput = form.querySelector('input[name="price"]');
            const ticketPriceInput = form.querySelector('input[name="ticket_price"]');
            const totalTicketsInput = form.querySelector('input[name="total_tickets"]');
            
            if (priceInput.value && ticketPriceInput.value) {
                const suggestedTickets = Math.ceil(parseFloat(priceInput.value) / parseFloat(ticketPriceInput.value));
                
                // Afficher une suggestion
                let suggestion = form.querySelector('.ticket-suggestion');
                if (!suggestion) {
                    suggestion = document.createElement('small');
                    suggestion.className = 'ticket-suggestion text-muted';
                    totalTicketsInput.parentNode.appendChild(suggestion);
                }
                
                suggestion.textContent = `Suggestion: ${suggestedTickets} tickets`;
            }
        });
    });
});

// Validation du formulaire
document.addEventListener('DOMContentLoaded', function() {
    const forms = document.querySelectorAll('form[method="POST"]');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const requiredFields = form.querySelectorAll('[required]');
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.classList.add('is-invalid');
                } else {
                    field.classList.remove('is-invalid');
                }
            });
            
            if (!isValid) {
                e.preventDefault();
                alert('Veuillez remplir tous les champs obligatoires');
            }
        });
    });
});

// Recherche en temps réel dans le tableau
function filterTable() {
    const searchInput = document.getElementById('tableSearch');
    if (!searchInput) return;
    
    const filter = searchInput.value.toLowerCase();
    const table = document.querySelector('table tbody');
    const rows = table.querySelectorAll('tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(filter) ? '' : 'none';
    });
}

// Ajouter la barre de recherche si elle n'existe pas
document.addEventListener('DOMContentLoaded', function() {
    const tableCard = document.querySelector('.card .card-header');
    if (tableCard && !document.getElementById('tableSearch')) {
        const searchDiv = document.createElement('div');
        searchDiv.innerHTML = `
            <div class="input-group" style="width: 300px;">
                <span class="input-group-text"><i class="fas fa-search"></i></span>
                <input type="text" id="tableSearch" class="form-control" placeholder="Rechercher..." onkeyup="filterTable()">
            </div>
        `;
        tableCard.appendChild(searchDiv);
    }
});
</script>

<style>
.image-preview img:first-child {
    border-color: #007bff !important;
}

.table tbody tr:hover {
    background-color: rgba(102, 126, 234, 0.05);
}

.product-image {
    transition: transform 0.3s ease;
}

.product-image:hover {
    transform: scale(1.1);
}

.badge {
    font-weight: 500;
}

.btn-group-sm .btn {
    padding: 0.25rem 0.5rem;
}

.progress {
    background-color: #e9ecef;
}

.progress-bar {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.modal-content {
    border: none;
    border-radius: 15px;
}

.form-control:focus,
.form-select:focus {
    box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
}

.ticket-suggestion {
    display: block;
    margin-top: 5px;
    font-style: italic;
}

.is-invalid {
    border-color: #dc3545 !important;
}

@media (max-width: 768px) {
    .admin-header .col-md-6:last-child {
        text-align: left !important;
        margin-top: 15px;
    }
    
    .btn-group {
        flex-direction: column;
    }
    
    .table-responsive {
        font-size: 12px;
    }
    
    .product-image {
        width: 30px;
        height: 30px;
    }
}
</style>

</body>
</html>