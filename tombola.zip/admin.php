<?php
session_start();

define('ROOT_PATH', realpath(dirname(__FILE__)));
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'auth.php';

// Vérification de la connexion et du rôle admin
if (!isLoggedIn() || ($_SESSION['role'] ?? '') !== 'admin') {
    redirectToLogin();
}

$username = htmlspecialchars($_SESSION['username']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Admin - Tombola</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body class="bg-gray-100 font-sans">
    <div class="min-h-screen flex flex-col">
        <header class="bg-purple-600 text-white p-6 shadow">
            <h1 class="text-3xl font-bold"><i class="fas fa-crown mr-2"></i>Panneau d'administration</h1>
            <p class="text-sm mt-1">Bienvenue, <?= $username ?> (administrateur)</p>
        </header>

        <main class="flex-grow p-6">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <a href="admin-articles.php" class="block p-6 bg-white rounded-lg shadow hover:shadow-lg transition">
                    <i class="fas fa-box-open text-2xl text-purple-500 mb-2"></i>
                    <h2 class="text-lg font-bold">Gérer les articles</h2>
                </a>
                <a href="users.php" class="block p-6 bg-white rounded-lg shadow hover:shadow-lg transition">
                    <i class="fas fa-users text-2xl text-purple-500 mb-2"></i>
                    <h2 class="text-lg font-bold">Utilisateurs</h2>
                </a>
                <a href="transactions.php" class="block p-6 bg-white rounded-lg shadow hover:shadow-lg transition">
                    <i class="fas fa-receipt text-2xl text-purple-500 mb-2"></i>
                    <h2 class="text-lg font-bold">Transactions</h2>
                </a>
            </div>

            <div class="mt-10">
                <a href="logout.php" class="text-red-600 hover:underline">
                    <i class="fas fa-sign-out-alt"></i> Déconnexion
                </a>
            </div>
        </main>
    </div>
</body>
</html>
