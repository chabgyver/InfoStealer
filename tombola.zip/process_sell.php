<?php
session_start();
define('ROOT_PATH', realpath(dirname(__FILE__)));
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'auth.php';

if (!isLoggedIn() || ($_SESSION['role'] ?? '') !== 'seller') {
    redirectToLogin();
}

// CSRF
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    die("Token CSRF invalide.");
}

$user_id = $_SESSION['user_id'];
$errors = [];

// Récupération des données
$title = trim($_POST['title'] ?? '');
$description = trim($_POST['description'] ?? '');
$category_id = intval($_POST['category_id'] ?? 0);
$total_tickets = intval($_POST['total_tickets'] ?? 0);
$price = floatval($_POST['price'] ?? 0.0);

// Validation
if ($title === '' || strlen($title) > 100) {
    $errors[] = "Le titre est requis et doit faire moins de 100 caractères.";
}
if ($description === '' || strlen($description) > 2000) {
    $errors[] = "La description est requise (max 2000 caractères).";
}
if ($category_id <= 0) {
    $errors[] = "Catégorie invalide.";
}
if ($total_tickets <= 0) {
    $errors[] = "Nombre de tickets invalide.";
}
if ($price <= 0) {
    $errors[] = "Prix du ticket invalide.";
}

// Upload d'image
$image_path = null;
if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
    $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
        $errors[] = "Format d’image non supporté.";
    } else {
        $new_name = uniqid("product_") . '.' . $ext;
        $destination = __DIR__ . '/uploads/' . $new_name;
        if (!move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {
            $errors[] = "Erreur lors de l’upload de l’image.";
        } else {
            $image_path = 'uploads/' . $new_name;
        }
    }
} else {
    $errors[] = "Image du produit obligatoire.";
}

// Si erreurs, afficher
if (!empty($errors)) {
    echo "<h2>Erreur lors de la création :</h2><ul>";
    foreach ($errors as $e) {
        echo "<li>" . htmlspecialchars($e) . "</li>";
    }
    echo "</ul><a href='sell.php'>⟵ Revenir</a>";
    exit;
}

// Insertion dans la base
try {
    $stmt = $pdo->prepare("
        INSERT INTO products (user_id, category_id, title, description, image, price, total_tickets, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    $stmt->execute([
        $user_id,
        $category_id,
        $title,
        $description,
        $image_path,
        $price,
        $total_tickets
    ]);

    header("Location: seller-products.php");
    exit;
} catch (PDOException $e) {
    echo "Erreur enregistrement : " . $e->getMessage();
}
