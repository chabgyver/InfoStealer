<?php
require_once 'includes/config.php';
require_once 'auth.php';

// Check if user is logged in
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Get user information
try {
    $stmt = $pdo->prepare("
        SELECT u.*, 
               COUNT(DISTINCT t.transaction_id) as total_purchases,
               COUNT(DISTINCT tk.ticket_id) as total_tickets,
               COALESCE(SUM(t.amount), 0) as total_spent
        FROM users u
        LEFT JOIN transactions t ON u.user_id = t.user_id AND t.status = 'completed'
        LEFT JOIN tickets tk ON u.user_id = tk.buyer_id
        WHERE u.user_id = ?
        GROUP BY u.user_id
    ");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if (!$user) {
        header('Location: login.php');
        exit;
    }
} catch (PDOException $e) {
    die("Erreur de base de données");
}

// Get recent transactions
try {
    $stmt = $pdo->prepare("
        SELECT t.*, p.title as product_title, p.price as product_price
        FROM transactions t
        JOIN products p ON t.product_id = p.product_id
        WHERE t.user_id = ?
        ORDER BY t.created_at DESC
        LIMIT 10
    ");
    $stmt->execute([$user_id]);
    $recent_transactions = $stmt->fetchAll();
} catch (PDOException $e) {
    $recent_transactions = [];
}

// Get active tickets
try {
    $stmt = $pdo->prepare("
        SELECT tk.*, p.title as product_title, p.total_tickets, p.tickets_sold, p.status as product_status
        FROM tickets tk
        JOIN products p ON tk.product_id = p.product_id
        WHERE tk.buyer_id = ? AND p.status IN ('active', 'completed')
        ORDER BY tk.purchase_date DESC
    ");
    $stmt->execute([$user_id]);
    $active_tickets = $stmt->fetchAll();
} catch (PDOException $e) {
    $active_tickets = [];
}

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    $errors = [];
    
    // Validate inputs
    if (empty($username)) {
        $errors[] = "Le nom d'utilisateur est requis";
    }
    
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Email valide requis";
    }
    
    // Check if email is already taken by another user
    $stmt = $pdo->prepare("SELECT user_id FROM users WHERE email = ? AND user_id != ?");
    $stmt->execute([$email, $user_id]);
    if ($stmt->fetch()) {
        $errors[] = "Cet email est déjà utilisé";
    }
    
    // Password change validation
    if (!empty($new_password)) {
        if (empty($current_password)) {
            $errors[] = "Mot de passe actuel requis pour changer de mot de passe";
        } elseif (!password_verify($current_password, $user['password'])) {
            $errors[] = "Mot de passe actuel incorrect";
        } elseif ($new_password !== $confirm_password) {
            $errors[] = "Les nouveaux mots de passe ne correspondent pas";
        } elseif (strlen($new_password) < 6) {
            $errors[] = "Le nouveau mot de passe doit contenir au moins 6 caractères";
        }
    }
    
    // Update profile if no errors
    if (empty($errors)) {
        try {
            if (!empty($new_password)) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("
                    UPDATE users 
                    SET username = ?, email = ?, password = ?, updated_at = NOW()
                    WHERE user_id = ?
                ");
                $stmt->execute([$username, $email, $hashed_password, $user_id]);
            } else {
                $stmt = $pdo->prepare("
                    UPDATE users 
                    SET username = ?, email = ?, updated_at = NOW()
                    WHERE user_id = ?
                ");
                $stmt->execute([$username, $email, $user_id]);
            }
            
            $success_message = "Profil mis à jour avec succès";
            
            // Refresh user data
            $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch();
            
        } catch (PDOException $e) {
            $errors[] = "Erreur lors de la mise à jour";
        }
    }
}

include 'includes/header.php';
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mon Profil - Tombola</title>
    <link rel="stylesheet" href="css/layout.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/animations.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="main-container">
        <div class="profile-container">
            <div class="profile-header">
                <div class="profile-avatar">
                    <div class="avatar-circle">
                        <span class="avatar-text"><?= strtoupper(substr($user['username'], 0, 2)) ?></span>
                    </div>
                    <div class="profile-info">
                        <h1><?= htmlspecialchars($user['username']) ?></h1>
                        <p class="profile-email"><?= htmlspecialchars($user['email']) ?></p>
                        <p class="profile-since">Membre depuis <?= date('F Y', strtotime($user['created_at'])) ?></p>
                    </div>
                </div>
                
                <div class="profile-stats">
                    <div class="stat-item">
                        <span class="stat-number"><?= $user['total_purchases'] ?></span>
                        <span class="stat-label">Achats</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number"><?= $user['total_tickets'] ?></span>
                        <span class="stat-label">Tickets</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number"><?= number_format($user['total_spent'], 2) ?> €</span>
                        <span class="stat-label">Dépensé</span>
                    </div>
                </div>
            </div>

            <div class="profile-content">
                <div class="profile-tabs">
                    <button class="tab-btn active" onclick="showTab('profile-edit')">✏️ Modifier le profil</button>
                    <button class="tab-btn" onclick="showTab('recent-activity')">📊 Activité récente</button>
                    <button class="tab-btn" onclick="showTab('my-tickets')">🎫 Mes tickets</button>
                    <button class="tab-btn" onclick="showTab('settings')">⚙️ Paramètres</button>
                </div>

                <!-- Profile Edit Tab -->
                <div id="profile-edit" class="tab-content active">
                    <div class="card">
                        <div class="card-header">
                            <h3>Modifier mon profil</h3>
                        </div>
                        <div class="card-body">
                            <?php if (isset($success_message)): ?>
                                <div class="alert alert-success"><?= $success_message ?></div>
                            <?php endif; ?>
                            
                            <?php if (!empty($errors)): ?>
                                <div class="alert alert-error">
                                    <?php foreach ($errors as $error): ?>
                                        <p><?= $error ?></p>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                            
                            <form method="POST" class="profile-form">
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="username">Nom d'utilisateur</label>
                                        <input type="text" id="username" name="username" 
                                               value="<?= htmlspecialchars($user['username']) ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Email</label>
                                        <input type="email" id="email" name="email" 
                                               value="<?= htmlspecialchars($user['email']) ?>" required>
                                    </div>
                                </div>
                                
                                <hr class="form-divider">
                                <h4>Changer le mot de passe (optionnel)</h4>
                                
                                <div class="form-group">
                                    <label for="current_password">Mot de passe actuel</label>
                                    <input type="password" id="current_password" name="current_password">
                                </div>
                                
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="new_password">Nouveau mot de passe</label>
                                        <input type="password" id="new_password" name="new_password">
                                    </div>
                                    <div class="form-group">
                                        <label for="confirm_password">Confirmer le nouveau mot de passe</label>
                                        <input type="password" id="confirm_password" name="confirm_password">
                                    </div>
                                </div>
                                
                                <div class="form-actions">
                                    <button type="submit" name="update_profile" class="btn btn-primary">
                                        Mettre à jour le profil
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Recent Activity Tab -->
                <div id="recent-activity" class="tab-content">
                    <div class="card">
                        <div class="card-header">
                            <h3>Activité récente</h3>
                        </div>
                        <div class="card-body">
                            <?php if (empty($recent_transactions)): ?>
                                <div class="empty-state">
                                    <span class="empty-icon">📊</span>
                                    <p>Aucune activité récente</p>
                                </div>
                            <?php else: ?>
                                <div class="activity-list">
                                    <?php foreach ($recent_transactions as $transaction): ?>
                                        <div class="activity-item">
                                            <div class="activity-icon">🎫</div>
                                            <div class="activity-details">
                                                <h4><?= htmlspecialchars($transaction['product_title']) ?></h4>
                                                <p>
                                                    <?= $transaction['tickets_count'] ?> ticket<?= $transaction['tickets_count'] > 1 ? 's' : '' ?> 
                                                    pour <?= number_format($transaction['amount'], 2) ?> €
                                                </p>
                                                <span class="activity-date">
                                                    <?= date('d/m/Y à H:i', strtotime($transaction['created_at'])) ?>
                                                </span>
                                            </div>
                                            <div class="activity-status">
                                                <span class="status-badge status-<?= $transaction['status'] ?>">
                                                    <?= ucfirst($transaction['status']) ?>
                                                </span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- My Tickets Tab -->
                <div id="my-tickets" class="tab-content">
                    <div class="card">
                        <div class="card-header">
                            <h3>Mes tickets actifs</h3>
                        </div>
                        <div class="card-body">
                            <?php if (empty($active_tickets)): ?>
                                <div class="empty-state">
                                    <span class="empty-icon">🎫</span>
                                    <p>Aucun ticket actif</p>
                                    <a href="index.php" class="btn btn-primary">Acheter des tickets</a>
                                </div>
                            <?php else: ?>
                                <div class="tickets-grid">
                                    <?php foreach ($active_tickets as $ticket): ?>
                                        <div class="ticket-card">
                                            <div class="ticket-header">
                                                <h4><?= htmlspecialchars($ticket['product_title']) ?></h4>
                                                <span class="ticket-number">#<?= $ticket['serial_number'] ?></span>
                                            </div>
                                            <div class="ticket-progress">
                                                <?php 
                                                $progress = ($ticket['tickets_sold'] / $ticket['total_tickets']) * 100;
                                                ?>
                                                <div class="progress-bar">
                                                    <div class="progress-fill" style="width: <?= $progress ?>%"></div>
                                                </div>
                                                <span class="progress-text">
                                                    <?= $ticket['tickets_sold'] ?>/<?= $ticket['total_tickets'] ?> tickets vendus
                                                </span>
                                            </div>
                                            <div class="ticket-status">
                                                <?php if ($ticket['product_status'] === 'active'): ?>
                                                    <span class="status-badge status-active">🟢 En cours</span>
                                                <?php elseif ($ticket['product_status'] === 'completed'): ?>
                                                    <span class="status-badge status-completed">🏆 Terminé</span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="ticket-date">
                                                Acheté le <?= date('d/m/Y', strtotime($ticket['purchase_date'])) ?>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Settings Tab -->
                <div id="settings" class="tab-content">
                    <div class="card">
                        <div class="card-header">
                            <h3>Paramètres du compte</h3>
                        </div>
                        <div class="card-body">
                            <div class="settings-section">
                                <h4>Notifications</h4>
                                <div class="setting-item">
                                    <label class="setting-label">
                                        <input type="checkbox" checked>
                                        <span>Recevoir des notifications par email</span>
                                    </label>
                                </div>
                                <div class="setting-item">
                                    <label class="setting-label">
                                        <input type="checkbox" checked>
                                        <span>Notifications de nouveaux produits</span>
                                    </label>
                                </div>
                                <div class="setting-item">
                                    <label class="setting-label">
                                        <input type="checkbox">
                                        <span>Newsletter hebdomadaire</span>
                                    </label>
                                </div>
                            </div>

                            <div class="settings-section">
                                <h4>Sécurité</h4>
                                <div class="setting-item">
                                    <p>Dernière connexion: <?= $user['last_login'] ? date('d/m/Y à H:i', strtotime($user['last_login'])) : 'Jamais' ?></p>
                                </div>
                                <div class="setting-item">
                                    <button class="btn btn-warning">Télécharger mes données</button>
                                </div>
                            </div>

                            <div class="settings-section danger-zone">
                                <h4>Zone de danger</h4>
                                <div class="setting-item">
                                    <p>Supprimer définitivement votre compte et toutes vos données.</p>
                                    <button class="btn btn-danger" onclick="confirmDeleteAccount()">
                                        Supprimer mon compte
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script>
        function showTab(tabId) {
            // Hide all tabs
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Remove active class from all buttons
            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            
            // Show selected tab
            document.getElementById(tabId).classList.add('active');
            
            // Add active class to clicked button
            event.target.classList.add('active');
        }

        function confirmDeleteAccount() {
            if (confirm('Êtes-vous sûr de vouloir supprimer votre compte ? Cette action est irréversible.')) {
                if (confirm('Dernière confirmation: Voulez-vous vraiment supprimer définitivement votre compte ?')) {
                    // Redirect to delete account page
                    window.location.href = 'delete-account.php';
                }
            }
        }
    </script>

    <style>
        .profile-container {
            max-width: 1000px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .profile-header {
            background: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 30px;
        }

        .profile-avatar {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .avatar-circle {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .avatar-text {
            font-size: 2rem;
            font-weight: bold;
            color: white;
        }

        .profile-info h1 {
            margin: 0 0 5px 0;
            color: #333;
        }

        .profile-email {
            color: #666;
            margin: 0 0 5px 0;
        }

        .profile-since {
            color: #999;
            margin: 0;
            font-size: 14px;
        }

        .profile-stats {
            display: flex;
            gap: 30px;
        }

        .stat-item {
            text-align: center;
        }

        .stat-number {
            display: block;
            font-size: 2rem;
            font-weight: bold;
            color: #667eea;
        }

        .stat-label {
            display: block;
            color: #666;
            font-size: 14px;
        }

        .profile-tabs {
            display: flex;
            background: white;
            border-radius: 15px 15px 0 0;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .tab-btn {
            flex: 1;
            padding: 15px 20px;
            border: none;
            background: white;
            cursor: pointer;
            transition: all 0.3s ease;
            border-bottom: 3px solid transparent;
        }

        .tab-btn:hover,
        .tab-btn.active {
            background: #f8f9fa;
            border-bottom-color: #667eea;
        }

        .tab-content {
            display: none;
            background: white;
            border-radius: 0 0 15px 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .tab-content.active {
            display: block;
        }

        .card {
            background: white;
            border-radius: 0 0 15px 15px;
        }

        .card-header {
            padding: 20px 30px;
            border-bottom: 1px solid #e9ecef;
        }

        .card-header h3 {
            margin: 0;
            color: #333;
        }

        .card-body {
            padding: 30px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .form-divider {
            margin: 30px 0;
            border: none;
            border-top: 1px solid #e9ecef;
        }

        .form-actions {
            margin-top: 30px;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #666;
        }

        .empty-icon {
            display: block;
            font-size: 4rem;
            margin-bottom: 20px;
        }

        .activity-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .activity-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            border: 1px solid #e9ecef;
            border-radius: 10px;
            transition: all 0.3s ease;
        }

        .activity-item:hover {
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .activity-icon {
            font-size: 1.5rem;
            width: 40px;
            text-align: center;
        }

        .activity-details {
            flex: 1;
        }

        .activity-details h4 {
            margin: 0 0 5px 0;
            color: #333;
        }

        .activity-details p {
            margin: 0 0 5px 0;
            color: #666;
        }

        .activity-date {
            font-size: 12px;
            color: #999;
        }

        .status-badge {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 500;
        }

        .status-completed {
            background: #d4edda;
            color: #155724;
        }

        .status-active {
            background: #d1ecf1;
            color: #0c5460;
        }

        .tickets-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
        }

        .ticket-card {
            border: 1px solid #e9ecef;
            border-radius: 10px;
            padding: 20px;
            transition: all 0.3s ease;
        }

        .ticket-card:hover {
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .ticket-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .ticket-header h4 {
            margin: 0;
            color: #333;
            flex: 1;
        }

        .ticket-number {
            background: #f8f9fa;
            padding: 4px 8px;
            border-radius: 6px;
            font-family: monospace;
            font-size: 12px;
            color: #666;
        }

        .ticket-progress {
            margin-bottom: 15px;
        }

        .progress-bar {
            width: 100%;
            height: 6px;
            background: #f8f9fa;
            border-radius: 3px;
            overflow: hidden;
            margin-bottom: 5px;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            transition: width 0.3s ease;
        }

        .progress-text {
            font-size: 12px;
            color: #666;
        }

        .ticket-status {
            margin-bottom: 10px;
        }

        .ticket-date {
            font-size: 12px;
            color: #999;
        }

        .settings-section {
            margin-bottom: 40px;
        }

        .settings-section h4 {
            margin-bottom: 20px;
            color: #333;
        }

        .setting-item {
            margin-bottom: 15px;
        }

        .setting-label {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
        }

        .danger-zone {
            border-top: 1px solid #dc3545;
            padding-top: 30px;
        }

        .danger-zone h4 {
            color: #dc3545;
        }

        @media (max-width: 768px) {
            .profile-header {
                flex-direction: column;
                text-align: center;
            }

            .profile-stats {
                justify-content: center;
            }

            .form-row {
                grid-template-columns: 1fr;
            }

            .tab-btn {
                font-size: 12px;
                padding: 10px;
            }
        }
    </style>
</body>
</html>
