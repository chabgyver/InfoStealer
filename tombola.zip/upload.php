<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

if (!isLoggedIn()) {
    die(json_encode(['error' => 'Non connecté']));
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['images'])) {
    $product_id = $_POST['product_id'];
    $uploaded_files = [];
    
    foreach ($_FILES['images']['tmp_name'] as $key => $tmp_name) {
        if ($_FILES['images']['error'][$key] == 0) {
            $filename = 'img_' . uniqid() . '.' . pathinfo($_FILES['images']['name'][$key], PATHINFO_EXTENSION);
            $filepath = 'images/uploads/' . $filename;
            
            if (move_uploaded_file($tmp_name, $filepath)) {
                // Enregistrer en base
                $stmt = $pdo->prepare("
                    INSERT INTO product_images (product_id, image_path, is_primary)
                    VALUES (?, ?, ?)
                ");
                $is_primary = empty($uploaded_files) ? 1 : 0;
                $stmt->execute([$product_id, $filepath, $is_primary]);
                
                $uploaded_files[] = $filepath;
            }
        }
    }
    
    echo json_encode(['success' => true, 'files' => $uploaded_files]);
}
?>
