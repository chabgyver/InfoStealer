<?php
/**
 * AUTH.PHP - Fonctions d'authentification
 */

/**
 * Vérifier si l'utilisateur est connecté
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Obtenir l'ID de l'utilisateur connecté
 */
function getCurrentUserId() {
    return $_SESSION['user_id'] ?? null;
}

/**
 * Obtenir les informations de l'utilisateur connecté
 */
function getCurrentUser() {
    if (!isLoggedIn()) {
        return null;
    }

    global $pdo;

    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        return $stmt->fetch();
    } catch (PDOException $e) {
        error_log("Erreur récupération utilisateur: " . $e->getMessage());
        return null;
    }
}

/**
 * Vérifier les permissions d'un utilisateur
 */
function hasPermission($permission) {
    $user = getCurrentUser();
    if (!$user) {
        return false;
    }

    // Logique de vérification des permissions
    // À adapter selon votre système de permissions
    return true;
}

/**
 * Rediriger vers la page de connexion
 */
function redirectToLogin() {
    header('Location: login.php');
    exit();
}

/**
 * Déconnecter l'utilisateur
 */
function logout() {
    session_destroy();
    header('Location: index.php');
    exit();
}

/**
 * Générer un token CSRF
 */
function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Vérifier un token CSRF
 */
function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Hacher un mot de passe
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

/**
 * Vérifier un mot de passe
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Générer un mot de passe aléatoire
 */
function generateRandomPassword($length = 12) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*';
    $password = '';

    for ($i = 0; $i < $length; $i++) {
        $password .= $characters[rand(0, strlen($characters) - 1)];
    }

    return $password;
}

/**
 * Vérifier la force d'un mot de passe
 */
function checkPasswordStrength($password) {
    $strength = 0;

    if (strlen($password) >= 8) $strength++;
    if (preg_match('/[a-z]/', $password)) $strength++;
    if (preg_match('/[A-Z]/', $password)) $strength++;
    if (preg_match('/[0-9]/', $password)) $strength++;
    if (preg_match('/[^A-Za-z0-9]/', $password)) $strength++;

    return $strength;
}

/**
 * Logger une action utilisateur
 */
function logUserAction($user_id, $action, $details = null) {
    global $pdo;

    try {
        $stmt = $pdo->prepare("
            INSERT INTO user_logs (user_id, action, details, ip_address, user_agent, created_at) 
            VALUES (?, ?, ?, ?, ?, NOW())
        ");

        $stmt->execute([
            $user_id,
            $action,
            $details ? json_encode($details) : null,
            $_SERVER['REMOTE_ADDR'] ?? null,
            $_SERVER['HTTP_USER_AGENT'] ?? null
        ]);

        return true;
    } catch (PDOException $e) {
        error_log("Erreur log action: " . $e->getMessage());
        return false;
    }
}

/**
 * Vérifier si un utilisateur est banni
 */
function isUserBanned($user_id) {
    global $pdo;

    try {
        $stmt = $pdo->prepare("SELECT status FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();

        return $user && $user['status'] === 'banned';
    } catch (PDOException $e) {
        error_log("Erreur vérification ban: " . $e->getMessage());
        return false;
    }
}

/**
 * Limiter les tentatives de connexion
 */
function checkLoginAttempts($email) {
    global $pdo;

    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as attempts 
            FROM login_attempts 
            WHERE email = ? AND created_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)
        ");
        $stmt->execute([$email]);
        $result = $stmt->fetch();

        return $result['attempts'] < 5; // Max 5 tentatives en 15 minutes
    } catch (PDOException $e) {
        error_log("Erreur vérification tentatives: " . $e->getMessage());
        return true; // En cas d'erreur, autoriser la connexion
    }
}

/**
 * Enregistrer une tentative de connexion
 */
function recordLoginAttempt($email, $success = false) {
    global $pdo;

    try {
        $stmt = $pdo->prepare("
            INSERT INTO login_attempts (email, success, ip_address, user_agent, created_at) 
            VALUES (?, ?, ?, ?, NOW())
        ");

        $stmt->execute([
            $email,
            $success ? 1 : 0,
            $_SERVER['REMOTE_ADDR'] ?? null,
            $_SERVER['HTTP_USER_AGENT'] ?? null
        ]);

        return true;
    } catch (PDOException $e) {
        error_log("Erreur enregistrement tentative: " . $e->getMessage());
        return false;
    }
}
?>