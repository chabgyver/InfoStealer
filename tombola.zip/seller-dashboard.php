<?php
session_start();

define('ROOT_PATH', realpath(dirname(__FILE__)));
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'auth.php';

// Vérification que l'utilisateur est un vendeur connecté
if (!isLoggedIn() || ($_SESSION['role'] ?? '') !== 'seller') {
    redirectToLogin();
}

$username = htmlspecialchars($_SESSION['username']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Tableau de bord vendeur</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/vendez.css">
</head>
<body class="bg-gradient-to-br from-purple-900 to-gray-900 min-h-screen text-white">
    <div class="container mx-auto px-4 py-8 max-w-4xl">
        <!-- Header -->
        <div class="text-center mb-10 fade-in">
            <h1 class="text-4xl font-bold mb-2">
                <i class="fas fa-store mr-2" style="color: var(--primary-color);"></i>
                Tableau de bord Vendeur
            </h1>
            <p class="text-gray-300">Bienvenue, <?= $username ?> ! Gérer vos ventes et tombolas</p>
        </div>

        <!-- Actions -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <a href="sell.php" class="block bg-white bg-opacity-10 hover:bg-opacity-20 transition p-6 rounded-lg shadow-lg fade-in">
                <i class="fas fa-plus-circle text-3xl mb-2 text-purple-400"></i>
                <h2 class="text-xl font-semibold">Créer une tombola</h2>
            </a>

            <a href="seller-products.php" class="block bg-white bg-opacity-10 hover:bg-opacity-20 transition p-6 rounded-lg shadow-lg fade-in">
                <i class="fas fa-boxes text-3xl mb-2 text-purple-400"></i>
                <h2 class="text-xl font-semibold">Gérer mes produits</h2>
            </a>

            <a href="my-tickets.php" class="block bg-white bg-opacity-10 hover:bg-opacity-20 transition p-6 rounded-lg shadow-lg fade-in">
                <i class="fas fa-ticket-alt text-3xl mb-2 text-purple-400"></i>
                <h2 class="text-xl font-semibold">Voir les tickets vendus</h2>
            </a>

            <a href="logout.php" class="block bg-white bg-opacity-10 hover:bg-opacity-20 transition p-6 rounded-lg shadow-lg fade-in text-red-400">
                <i class="fas fa-sign-out-alt text-3xl mb-2"></i>
                <h2 class="text-xl font-semibold">Déconnexion</h2>
            </a>
        </div>
    </div>
</body>
</html>
