<?php
// Vérifier si l'utilisateur est connecté
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// Vérifier si l'utilisateur est administrateur
function isAdmin() {
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true;
}

// Rediriger vers la page de connexion si non connecté
function requireLogin() {
    if (!isLoggedIn()) {
        $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
        header('Location: /login.php');
        exit();
    }
}

// Rediriger vers le tableau de bord admin si non admin
function requireAdmin() {
    requireLogin();
    
    if (!isAdmin()) {
        $_SESSION['error'] = 'Accès refusé. Vous devez être administrateur pour accéder à cette page.';
        header('Location: /index.php');
        exit();
    }
}

// Générer un jeton CSRF
function generateCsrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Vérifier le jeton CSRF
function verifyCsrfToken($token) {
    if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        return false;
    }
    return true;
}

// Hacher un mot de passe
function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
}

// Vérifier un mot de passe
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

// Déconnecter l'utilisateur
function logout() {
    // Détruire toutes les variables de session
    $_SESSION = [];
    
    // Détruire le cookie de session
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }
    
    // Détruire la session
    session_destroy();
}

// Vérifier les tentatives de connexion
function checkLoginAttempts($email, $maxAttempts = 5, $lockoutTime = 900) { // 15 minutes
    $key = 'login_attempts_' . md5($email);
    
    if (!isset($_SESSION[$key])) {
        $_SESSION[$key] = [
            'attempts' => 0,
            'last_attempt' => 0
        ];
    }
    
    $now = time();
    $attempts = &$_SESSION[$key];
    
    // Réinitialiser les tentatives si le délai est écoulé
    if ($attempts['last_attempt'] < ($now - $lockoutTime)) {
        $attempts = [
            'attempts' => 0,
            'last_attempt' => $now
        ];
    }
    
    return $attempts['attempts'] < $maxAttempts;
}

// Enregistrer une tentative de connexion échouée
function recordFailedLoginAttempt($email) {
    $key = 'login_attempts_' . md5($email);
    
    if (!isset($_SESSION[$key])) {
        $_SESSION[$key] = [
            'attempts' => 0,
            'last_attempt' => time()
        ];
    }
    
    $_SESSION[$key]['attempts']++;
    $_SESSION[$key]['last_attempt'] = time();
}

// Réinitialiser les tentatives de connexion
function resetLoginAttempts($email) {
    $key = 'login_attempts_' . md5($email);
    unset($_SESSION[$key]);
}
