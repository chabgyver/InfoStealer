<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle ?? 'Tombola') ?></title>
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-dark">
    <header class="main-header shadow-lg">
        <div class="container flex justify-between items-center py-4">
            <a href="../index.php" class="logo-link hover:scale-105 transition-transform">
                <img src="../images/logo.png" alt="Logo Tombola" class="h-12">
            </a>
            
            <nav class="main-nav hidden md:block">
                <ul class="flex space-x-6">
                    <li><a href="../index.php" class="text-light hover:text-primary flex items-center gap-2">
                        <i class="fas fa-home"></i> Accueil
                    </a></li>
                    <li><a href="../add-product.php" class="text-light hover:text-primary flex items-center gap-2">
                        <i class="fas fa-plus-circle"></i> Vendre
                    </a></li>
                    <li><a href="../tickets.php" class="text-light hover:text-primary flex items-center gap-2">
                        <i class="fas fa-ticket-alt"></i> Tickets
                    </a></li>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li><a href="../profile.php" class="text-light hover:text-primary flex items-center gap-2">
                            <i class="fas fa-user"></i> Compte
                        </a></li>
                    <?php endif; ?>
                </ul>
            </nav>
            
            <div class="flex items-center space-x-4">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="../logout.php" class="btn btn-outline">
                        <i class="fas fa-sign-out-alt"></i>
                    </a>
                <?php else: ?>
                    <a href="../login.php" class="btn btn-primary">
                        <i class="fas fa-sign-in-alt"></i> Connexion
                    </a>
                <?php endif; ?>
                
                <button class="mobile-menu-toggle md:hidden text-2xl text-light">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </div>
    </header>
    
    <main class="container py-8">
    <?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Get current user if logged in
$currentUser = null;
if (isset($_SESSION['user_id'])) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $currentUser = $stmt->fetch();
    } catch (PDOException $e) {
        // Handle error silently
    }
}
?>
