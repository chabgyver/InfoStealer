<?php
// Protection contre l'accès direct aux fichiers de configuration
$scriptPath = $_SERVER['SCRIPT_FILENAME'] ?? '';
$isApiAccess = strpos($scriptPath, 'api/') !== false;

if (!defined('ROOT_PATH') && !$isApiAccess) {
    die('Accès interdit');
}

// Définir ROOT_PATH si ce n'est pas déjà fait
if (!defined('ROOT_PATH')) {
    define('ROOT_PATH', dirname(__DIR__));
}

// Définition de l'environnement (développement, production, etc.)
define('ENVIRONMENT', getenv('APP_ENV') ?: 'production');

// Niveau de rapport d'erreurs en fonction de l'environnement
if (ENVIRONMENT === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
    define('DEBUG_MODE', true);
} else {
    error_reporting(E_ALL & ~E_DEPRECATED & ~E_STRICT);
    ini_set('display_errors', '0');
    define('DEBUG_MODE', false);
}

// Chargement manuel des variables d'environnement
if (file_exists(__DIR__ . '/../.env')) {
    $lines = file(__DIR__ . '/../.env');
    foreach ($lines as $line) {
        $line = trim($line);
        if (strpos($line, '#') !== 0 && strpos($line, '=') !== false) {
            putenv($line);
        }
    }
}

// Configuration DB avec valeurs par défaut
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'thiebtcz_tombola');
define('DB_USER', getenv('DB_USER') ?: 'thiebtcz');
define('DB_PASS', getenv('DB_PASS') ?: 'Jesuisnele15!');
define('DB_PORT', getenv('DB_PORT') ?: '3306');

// Configuration de l'application
define('APP_NAME', getenv('APP_NAME') ?: 'Tombola');
define('APP_URL', getenv('APP_URL') ?: 'http://localhost');
$appDebug = getenv('APP_DEBUG') ?: 'false';
define('APP_DEBUG', filter_var($appDebug, FILTER_VALIDATE_BOOLEAN));

// Configuration des sessions
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 1 : 0);
ini_set('session.cookie_samesite', 'Lax');

// Configuration du fuseau horaire
date_default_timezone_set(getenv('TIMEZONE') ?: 'Europe/Paris');

// Initialisation de la session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Initialisation du logger
require_once __DIR__ . '/logger.php';
$logger = Logger::getInstance();

// Configuration de la base de données
if (!defined('DB_PASS')) {
    define('DB_PASS', 'Jesuisnele15!');
}
if (!defined('DB_CHARSET')) {
    define('DB_CHARSET', 'utf8mb4');
}

// Configuration de la journalisation des erreurs
$logDir = __DIR__ . '/../logs';
if (!file_exists($logDir)) {
    mkdir($logDir, 0755, true);
}

$errorLog = $logDir . '/php_errors.log';
@ini_set('log_errors', '1');
@ini_set('error_log', $errorLog);
@ini_set('display_errors', DEBUG_MODE ? '1' : '0'); // Afficher les erreurs uniquement en mode debug

// Vérifier que le fichier de log est accessible en écriture
if (!is_writable($errorLog) && file_exists($errorLog)) {
    die('Le fichier de log n\'est pas accessible en écriture : ' . $errorLog);
}

// Fonction de journalisation personnalisée
function logConfigMessage($message, $data = null) {
    $log = '[' . date('Y-m-d H:i:s') . '] ' . $message . PHP_EOL;
    if ($data !== null) {
        $log .= 'Data: ' . print_r($data, true) . PHP_EOL;
    }
    error_log($log, 3, __DIR__ . '/../logs/config.log');
}

logConfigMessage('Début de la configuration');
logConfigMessage('DB_HOST: ' . DB_HOST);
logConfigMessage('DB_NAME: ' . DB_NAME);
logConfigMessage('DB_USER: ' . DB_USER);

// Configuration de la connexion PDO
try {
    logConfigMessage('Tentative de connexion à la base de données');
    $dsn = "mysql:host=".DB_HOST.";port=".DB_PORT.";dbname=".DB_NAME.";charset=".DB_CHARSET;
    logConfigMessage('DSN: ' . $dsn);
    
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::ATTR_PERSISTENT         => false,
    ];
    
    logConfigMessage('Options PDO: ', $options);
    
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    logConfigMessage('Connexion PDO établie avec succès');
    
    // Tester la connexion
    $pdo->query('SELECT 1');
    logConfigMessage('Test de requête SELECT 1 réussi');
    
} catch (PDOException $e) {
    // En cas d'erreur de connexion, afficher un message d'erreur
    $errorMessage = "Erreur de connexion à la base de données : " . $e->getMessage();
    logConfigMessage('ERREUR: ' . $errorMessage);
    logConfigMessage('Code d\'erreur: ' . $e->getCode());
    logConfigMessage('Fichier: ' . $e->getFile() . ' à la ligne ' . $e->getLine());
    
    if (defined('ENVIRONMENT') && ENVIRONMENT === 'development') {
        // En développement, afficher plus de détails
        $debugInfo = [
            'message' => $e->getMessage(),
            'code' => $e->getCode(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
            'dsn' => $dsn ?? 'Non défini',
            'user' => DB_USER,
            'charset' => DB_CHARSET
        ];
        logConfigMessage('Détails de débogage: ', $debugInfo);
        die(json_encode(['error' => $errorMessage, 'debug' => $debugInfo]));
    } else {
        // En production, logger l'erreur et afficher un message générique
        error_log($errorMessage);
        logConfigMessage('Erreur en production: ' . $errorMessage);
        die(json_encode(['error' => 'Une erreur est survenue lors de la connexion à la base de données.']));
    }
}

// Journalisation de la requête
if (function_exists('log_request')) {
    $logger->logRequest();
}

// Journalisation des données de session
if (function_exists('log_debug') && DEBUG_MODE) {
    $logger->logSessionData();
}

// Gestion des erreurs et exceptions
set_error_handler(function($errno, $errstr, $errfile, $errline) use ($logger) {
    $errorTypes = [
        E_ERROR => 'Error',
        E_WARNING => 'Warning',
        E_PARSE => 'Parse Error',
        E_NOTICE => 'Notice',
        E_CORE_ERROR => 'Core Error',
        E_CORE_WARNING => 'Core Warning',
        E_COMPILE_ERROR => 'Compile Error',
        E_COMPILE_WARNING => 'Compile Warning',
        E_USER_ERROR => 'User Error',
        E_USER_WARNING => 'User Warning',
        E_USER_NOTICE => 'User Notice',
        E_STRICT => 'Strict Standards',
        E_RECOVERABLE_ERROR => 'Recoverable Error',
        E_DEPRECATED => 'Deprecated',
        E_USER_DEPRECATED => 'User Deprecated'
    ];
    
    $errorType = $errorTypes[$errno] ?? 'Unknown Error';
    $message = "$errorType: $errstr in $errfile on line $errline";
    
    $logger->error($message, [
        'file' => $errfile,
        'line' => $errline,
        'error_type' => $errorType
    ]);
    
    // Ne pas exécuter le gestionnaire d'erreurs interne de PHP
    return true;
});

set_exception_handler(function(Throwable $e) use ($logger) {
    $logger->logException($e, [
        'uri' => $_SERVER['REQUEST_URI'] ?? '',
        'method' => $_SERVER['REQUEST_METHOD'] ?? 'CLI'
    ]);
    
    if (ENVIRONMENT === 'development') {
        echo "<h1>Une erreur est survenue</h1>";
        echo "<p><strong>Message:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
        echo "<p><strong>Fichier:</strong> " . htmlspecialchars($e->getFile()) . "</p>";
        echo "<p><strong>Ligne:</strong> " . htmlspecialchars($e->getLine()) . "</p>";
        echo "<pre>" . htmlspecialchars($e->getTraceAsString()) . "</pre>";
    } else {
        // En production, afficher un message générique
        if (!headers_sent()) {
            header('HTTP/1.1 500 Internal Server Error');
        }
        echo "<h1>Une erreur est survenue</h1>";
        echo "<p>Veuillez réessayer plus tard ou contacter l'administrateur.</p>";
    }
});

// Fonction pour charger les classes automatiquement
spl_autoload_register(function ($class) {
    $prefix = 'App\\';
    $baseDir = __DIR__ . '/../src/';
    
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }
    
    $relativeClass = substr($class, $len);
    $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';
    
    if (file_exists($file)) {
        require $file;
    }
});
define('DB_PASS', getenv('DB_PASS') ?: 'Jesuisnele15!');
define('DB_CHARSET', 'utf8mb4');

// Fin du fichier de configuration
