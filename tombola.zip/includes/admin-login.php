<section class="p-4 bg-gray-100">
    <h2 class="text-xl font-bold mb-2">Connexion admin</h2>
    <form method="post" action="admin-dashboard.php">
        <input type="password" name="password" placeholder="Mot de passe" class="border p-2 mr-2">
        <button type="submit" class="bg-blue-500 text-white px-4 py-2">Se connecter</button>
    </form>
</section>
