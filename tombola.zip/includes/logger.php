<?php

class Logger {
    private static $instance = null;
    private $logFile;
    private $enabled = true;
    
    private function __construct() {
        $logDir = __DIR__ . '/../logs';
        
        // Créer le dossier de logs s'il n'existe pas
        if (!file_exists($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $this->logFile = $logDir . '/app_' . date('Y-m-d') . '.log';
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function enable() {
        $this->enabled = true;
    }
    
    public function disable() {
        $this->enabled = false;
    }
    
    public function log($level, $message, array $context = []) {
        if (!$this->enabled) {
            return;
        }
        
        $level = strtoupper($level);
        $timestamp = date('Y-m-d H:i:s');
        $contextStr = !empty($context) ? ' ' . json_encode($context, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) : '';
        $logMessage = "[$timestamp] [$level] $message$contextStr" . PHP_EOL;
        
        file_put_contents($this->logFile, $logMessage, FILE_APPEND);
        
        // En mode développement, afficher aussi dans la sortie
        if (defined('ENVIRONMENT') && ENVIRONMENT === 'development') {
            error_log($logMessage);
        }
    }
    
    public function error($message, array $context = []) {
        $this->log('ERROR', $message, $context);
    }
    
    public function warning($message, array $context = []) {
        $this->log('WARNING', $message, $context);
    }
    
    public function info($message, array $context = []) {
        $this->log('INFO', $message, $context);
    }
    
    public function debug($message, array $context = []) {
        if (defined('DEBUG_MODE') && DEBUG_MODE) {
            $this->log('DEBUG', $message, $context);
        }
    }
    
    public function logException(Throwable $e, array $context = []) {
        $this->error(sprintf(
            'Exception: %s in %s:%d',
            $e->getMessage(),
            $e->getFile(),
            $e->getLine()
        ), $context);
    }
    
    public function logSessionData() {
        if (session_status() === PHP_SESSION_ACTIVE && !empty($_SESSION)) {
            $this->debug('Session data', ['session' => $_SESSION]);
        }
    }
    
    public function logRequest() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $postData = $_POST;
            
            // Ne pas logger les mots de passe
            if (isset($postData['password'])) {
                $postData['password'] = '***';
            }
            
            $this->info('Request', [
                'method' => $_SERVER['REQUEST_METHOD'],
                'uri' => $_SERVER['REQUEST_URI'],
                'post' => $postData,
                'get' => $_GET,
                'ip' => $_SERVER['REMOTE_ADDR'],
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null
            ]);
        } else {
            $this->info('Request', [
                'method' => $_SERVER['REQUEST_METHOD'],
                'uri' => $_SERVER['REQUEST_URI'],
                'get' => $_GET,
                'ip' => $_SERVER['REMOTE_ADDR']
            ]);
        }
    }
}

// Fonctions d'aide globales
function log_error($message, array $context = []) {
    Logger::getInstance()->error($message, $context);
}

function log_warning($message, array $context = []) {
    Logger::getInstance()->warning($message, $context);
}

function log_info($message, array $context = []) {
    Logger::getInstance()->info($message, $context);
}

function log_debug($message, array $context = []) {
    Logger::getInstance()->debug($message, $context);
}

function log_exception(Throwable $e, array $context = []) {
    Logger::getInstance()->logException($e, $context);
}
