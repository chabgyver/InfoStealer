<?php
// Common functions for Tombola application

function sanitizeInput($input) {
    return htmlspecialchars(strip_tags(trim($input)));
}

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

function uploadImage($file, $directory = 'uploads/products/') {
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $maxSize = 5 * 1024 * 1024; // 5MB
    
    if (!in_array($file['type'], $allowedTypes)) {
        return ['success' => false, 'message' => 'Type de fichier non autorisé'];
    }
    
    if ($file['size'] > $maxSize) {
        return ['success' => false, 'message' => 'Fichier trop volumineux'];
    }
    
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = 'img_' . uniqid() . '.' . $extension;
    $filepath = $directory . $filename;
    
    if (!is_dir($directory)) {
        mkdir($directory, 0755, true);
    }
    
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        return ['success' => true, 'filepath' => $filepath];
    } else {
        return ['success' => false, 'message' => 'Erreur lors du téléchargement'];
    }
}

function resizeImage($source, $destination, $maxWidth, $maxHeight) {
    $info = getimagesize($source);
    $width = $info[0];
    $height = $info[1];
    $type = $info[2];
    
    $ratio = min($maxWidth / $width, $maxHeight / $height);
    
    $newWidth = $width * $ratio;
    $newHeight = $height * $ratio;
    
    $newImage = imagecreatetruecolor($newWidth, $newHeight);
    
    switch ($type) {
        case IMAGETYPE_JPEG:
            $image = imagecreatefromjpeg($source);
            break;
        case IMAGETYPE_PNG:
            $image = imagecreatefrompng($source);
            imagealphablending($newImage, false);
            imagesavealpha($newImage, true);
            break;
        case IMAGETYPE_GIF:
            $image = imagecreatefromgif($source);
            break;
        default:
            return false;
    }
    
    imagecopyresampled($newImage, $image, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
    
    switch ($type) {
        case IMAGETYPE_JPEG:
            imagejpeg($newImage, $destination, 85);
            break;
        case IMAGETYPE_PNG:
            imagepng($newImage, $destination);
            break;
        case IMAGETYPE_GIF:
            imagegif($newImage, $destination);
            break;
    }
    
    imagedestroy($image);
    imagedestroy($newImage);
    
    return true;
}

function sendEmail($to, $subject, $message, $headers = '') {
    // Configuration SMTP
    $defaultHeaders = "From: " . SITE_EMAIL . "\r\n";
    $defaultHeaders .= "Reply-To: " . SITE_EMAIL . "\r\n";
    $defaultHeaders .= "Content-Type: text/html; charset=UTF-8\r\n";
    
    $finalHeaders = $defaultHeaders . $headers;
    
    return mail($to, $subject, $message, $finalHeaders);
}

function logActivity($userId, $action, $data = null) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO user_logs (user_id, action, data, created_at)
            VALUES (?, ?, ?, NOW())
        ");
        
        $stmt->execute([
            $userId,
            $action,
            $data ? json_encode($data) : null
        ]);
    } catch (PDOException $e) {
        error_log("Log error: " . $e->getMessage());
    }
}

function formatPrice($price) {
    return number_format($price, 2, ',', ' ') . ' €';
}

function formatDate($date) {
    return date('d/m/Y H:i', strtotime($date));
}

function getProductStatus($product) {
    $percentage = ($product['tickets_sold'] / $product['total_tickets']) * 100;
    
    if ($percentage >= 100) {
        return 'Complet';
    } elseif ($percentage >= 85) {
        return 'Presque épuisé';
    } elseif ($percentage >= 50) {
        return 'En cours';
    } else {
        return 'Nouveau';
    }
}

function generateTicketNumber() {
    return strtoupper(substr(md5(uniqid()), 0, 8));
}

function isValidTicketNumber($ticketNumber) {
    return preg_match('/^[A-Z0-9]{8}$/', $ticketNumber);
}

function getRemainingTime($endDate) {
    $now = new DateTime();
    $end = new DateTime($endDate);
    $interval = $now->diff($end);
    
    if ($interval->invert) {
        return 'Terminé';
    }
    
    $days = $interval->d;
    $hours = $interval->h;
    $minutes = $interval->i;
    
    if ($days > 0) {
        return $days . ' jour' . ($days > 1 ? 's' : '');
    } elseif ($hours > 0) {
        return $hours . ' heure' . ($hours > 1 ? 's' : '');
    } else {
        return $minutes . ' minute' . ($minutes > 1 ? 's' : '');
    }
}

function getCategoryIcon($categoryId) {
    $icons = [
        1 => '📱', // Électronique
        2 => '👕', // Mode
        3 => '🏠', // Maison
        4 => '⚽', // Sport
        5 => '🎮', // Jeux
        6 => '📦'  // Autres
    ];
    
    return $icons[$categoryId] ?? '📦';
}

function getCategoryName($categoryId) {
    $names = [
        1 => 'Électronique',
        2 => 'Mode',
        3 => 'Maison',
        4 => 'Sport',
        5 => 'Jeux',
        6 => 'Autres'
    ];
    
    return $names[$categoryId] ?? 'Autres';
}

function validateProductData($data) {
    $errors = [];
    
    if (empty($data['title'])) {
        $errors[] = 'Le titre est requis';
    }
    
    if (empty($data['description'])) {
        $errors[] = 'La description est requise';
    }
    
    if (!is_numeric($data['price']) || $data['price'] <= 0) {
        $errors[] = 'Le prix doit être un nombre positif';
    }
    
    if (!is_numeric($data['ticket_price']) || $data['ticket_price'] <= 0) {
        $errors[] = 'Le prix du ticket doit être un nombre positif';
    }
    
    if (!is_numeric($data['total_tickets']) || $data['total_tickets'] <= 0) {
        $errors[] = 'Le nombre de tickets doit être un nombre positif';
    }
    
    if (!in_array($data['category_id'], [1, 2, 3, 4, 5, 6])) {
        $errors[] = 'Catégorie invalide';
    }
    
    return $errors;
}

function checkProductAvailability($productId, $quantity) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            SELECT total_tickets, tickets_sold
            FROM products
            WHERE product_id = ? AND status = 'active'
        ");
        
        $stmt->execute([$productId]);
        $product = $stmt->fetch();
        
        if (!$product) {
            return ['available' => false, 'message' => 'Produit non trouvé'];
        }
        
        $remaining = $product['total_tickets'] - $product['tickets_sold'];
        
        if ($remaining < $quantity) {
            return ['available' => false, 'message' => 'Pas assez de tickets disponibles'];
        }
        
        return ['available' => true, 'remaining' => $remaining];
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        return ['available' => false, 'message' => 'Erreur de base de données'];
    }
}

function createNotification($userId, $type, $message) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO notifications (user_id, type, message, created_at)
            VALUES (?, ?, ?, NOW())
        ");
        
        $stmt->execute([$userId, $type, $message]);
        return true;
    } catch (PDOException $e) {
        error_log("Notification error: " . $e->getMessage());
        return false;
    }
}

function getUnreadNotifications($userId) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            SELECT * FROM notifications
            WHERE user_id = ? AND is_read = 0
            ORDER BY created_at DESC
        ");
        
        $stmt->execute([$userId]);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        return [];
    }
}

function markNotificationAsRead($notificationId) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            UPDATE notifications
            SET is_read = 1
            WHERE notification_id = ?
        ");
        
        $stmt->execute([$notificationId]);
        return true;
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        return false;
    }
}

// Fonction pour vérifier un remember token
function verifyRememberToken($token) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("SELECT user_id, username FROM remember_tokens WHERE token = ? AND expires_at > NOW()");
        $stmt->execute([hash('sha256', $token)]);
        $tokenData = $stmt->fetch();
        
        if ($tokenData) {
            return [
                'id' => $tokenData['user_id'],
                'username' => $tokenData['username']
            ];
        }
    } catch (PDOException $e) {
        error_log("Remember token error: " . $e->getMessage());
    }
    
    return false;
}

// Fonction pour enregistrer un remember token
function setRememberToken($userId, $token) {
    global $pdo;
    
    try {
        $hashedToken = hash('sha256', $token);
        $expires = date('Y-m-d H:i:s', time() + 60*60*24*30); // 30 jours
        
        $pdo->prepare("DELETE FROM remember_tokens WHERE user_id = ?")->execute([$userId]);
        
        $stmt = $pdo->prepare("INSERT INTO remember_tokens (user_id, token, expires_at) VALUES (?, ?, ?)");
        $stmt->execute([$userId, $hashedToken, $expires]);
        
        return true;
    } catch (PDOException $e) {
        error_log("Set remember token error: " . $e->getMessage());
        return false;
    }
}

?>
