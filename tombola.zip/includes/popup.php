<div id="popup" class="fixed inset-0 bg-black bg-opacity-50 hidden justify-center items-center">
    <div class="bg-white p-4 rounded shadow-lg max-w-md">
        <h2 class="text-xl font-semibold mb-2">Détail du produit</h2>
        <div id="popupContent">Contenu à charger dynamiquement.</div>
        <button onclick="document.getElementById('popup').classList.add('hidden')" class="mt-4 bg-red-500 text-white px-4 py-2 rounded">Fermer</button>
    </div>
</div>
