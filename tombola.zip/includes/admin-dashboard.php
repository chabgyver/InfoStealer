<?php
session_start();

// Redirige vers login.old si l'utilisateur n'est pas connecté ou pas admin
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: login.old');
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Système de Tombola - Administration</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
	<link rel="stylesheet" href="css/admin.css">
</head>
<body class="bg-gray-100 font-sans">
    <!-- Page de Connexion -->
    <div id="loginPage" class="min-h-screen flex items-center justify-center gradient-bg">
        <div class="bg-white p-8 rounded-lg shadow-2xl w-full max-w-md fade-in">
            <div class="text-center mb-8">
                <i class="fas fa-crown text-4xl text-purple-600 mb-4"></i>
                <h1 class="text-3xl font-bold text-gray-800">Administration</h1>
                <p class="text-gray-600 mt-2">Système de Tombola</p>
            </div>
            
            <form id="loginForm" class="space-y-6">
                <div>
                    <label class="block text-gray-700 text-sm font-bold mb-2">Email</label>
                    <div class="relative">
                        <input type="email" id="loginEmail" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 pl-10" placeholder="Votre email" required>
                        <i class="fas fa-envelope absolute left-3 top-4 text-gray-400"></i>
                    </div>
                </div>
                
                <div>
                    <label class="block text-gray-700 text-sm font-bold mb-2">Mot de passe</label>
                    <div class="relative">
                        <input type="password" id="loginPassword" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 pl-10 pr-10" placeholder="Votre mot de passe" required>
                        <i class="fas fa-lock absolute left-3 top-4 text-gray-400"></i>
                        <button type="button" id="togglePassword" class="absolute right-3 top-4 text-gray-400 hover:text-gray-600">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>
                
                <div id="loginError" class="text-red-500 text-sm hidden"></div>
                
                <button type="submit" class="w-full btn-primary text-white py-3 rounded-lg font-bold hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500">
                    <i class="fas fa-sign-in-alt mr-2"></i>Se connecter
                </button>
            </form>
            
            <div class="mt-6 text-center text-sm text-gray-600">
                <p>Identifiants de test :</p>
                <p class="font-mono bg-gray-100 p-2 rounded mt-2">
                    chabgyver@gmail.com<br>
                    Jesuisnele15!
                </p>
            </div>
        </div>
    </div>

    <!-- Interface Admin -->
    <div id="adminInterface" class="hidden min-h-screen bg-gray-100">
        <!-- Sidebar -->
        <div class="fixed inset-y-0 left-0 z-50 w-64 sidebar slide-in">
            <div class="flex items-center justify-center h-16 bg-black bg-opacity-20">
                <h1 class="text-white text-xl font-bold">
                    <i class="fas fa-crown mr-2"></i>Administration
                </h1>
            </div>
            
            <nav class="mt-8">
                <div class="px-4 space-y-2">
                    <a href="#" class="nav-item flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-20 rounded-lg transition-colors duration-200" data-section="dashboard">
                        <i class="fas fa-tachometer-alt mr-3"></i>
                        <span>Tableau de bord</span>
                    </a>
                    
                    <a href="#" class="nav-item flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-20 rounded-lg transition-colors duration-200" data-section="products">
                        <i class="fas fa-gift mr-3"></i>
                        <span>Produits</span>
                    </a>
                    
                    <a href="#" class="nav-item flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-20 rounded-lg transition-colors duration-200" data-section="users">
                        <i class="fas fa-users mr-3"></i>
                        <span>Utilisateurs</span>
                    </a>
                    
                    <a href="#" class="nav-item flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-20 rounded-lg transition-colors duration-200" data-section="transactions">
                        <i class="fas fa-credit-card mr-3"></i>
                        <span>Transactions</span>
                    </a>
                    
                    <a href="#" class="nav-item flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-20 rounded-lg transition-colors duration-200" data-section="categories">
                        <i class="fas fa-tags mr-3"></i>
                        <span>Catégories</span>
                    </a>
                    
                    <a href="#" class="nav-item flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-20 rounded-lg transition-colors duration-200" data-section="settings">
                        <i class="fas fa-cog mr-3"></i>
                        <span>Paramètres</span>
                    </a>
                </div>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="ml-64 min-h-screen">
            <!-- Header -->
            <header class="bg-white shadow-sm border-b border-gray-200">
                <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div class="flex justify-between items-center h-16">
                        <div class="flex items-center">
                            <h2 id="pageTitle" class="text-2xl font-bold text-gray-800">Tableau de bord</h2>
                        </div>
                        
                        <div class="flex items-center space-x-4">
                            <div class="relative">
                                <button class="flex items-center text-gray-600 hover:text-gray-800">
                                    <i class="fas fa-bell mr-2"></i>
                                    <span class="bg-red-500 text-white text-xs rounded-full px-2 py-1">3</span>
                                </button>
                            </div>
							
                            
                            <div class="relative">
                                <button id="userMenuBtn" class="flex items-center text-gray-600 hover:text-gray-800">
                                    <i class="fas fa-user-circle mr-2 text-2xl"></i>
                                    <span id="userName">Admin</span>
                                    <i class="fas fa-chevron-down ml-2"></i>
                                </button>
                                
                                <div id="userMenu" class="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2 hidden">
                                    <a href="#" class="block px-4 py-2 text-gray-800 hover:bg-gray-100">
                                        <i class="fas fa-user mr-2"></i>Profil
                                    </a>
                                    <a href="#" class="block px-4 py-2 text-gray-800 hover:bg-gray-100">
                                        <i class="fas fa-cog mr-2"></i>Paramètres
                                    </a>
                                    <hr class="my-2">
                                    <a href="logout.php" id="logoutBtn" class="block px-4 py-2 text-red-600 hover:bg-gray-100">						
                                        <i class="fas fa-sign-out-alt mr-2"></i>Déconnexion
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Content Area -->
            <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                
                <!-- Dashboard Section -->
                <div id="dashboardSection" class="fade-in">
                    <!-- Statistics Cards -->
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                        <div class="stats-card text-white p-6 rounded-lg shadow-lg card-hover">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-sm font-medium opacity-90">Produits Actifs</p>
                                    <p class="text-3xl font-bold">127</p>
                                </div>
                                <i class="fas fa-gift text-4xl opacity-80"></i>
                            </div>
                        </div>
                        
                        <div class="stats-card-2 text-white p-6 rounded-lg shadow-lg card-hover">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-sm font-medium opacity-90">Utilisateurs</p>
                                    <p class="text-3xl font-bold">2,847</p>
                                </div>
                                <i class="fas fa-users text-4xl opacity-80"></i>
                            </div>
                        </div>
                        
                        <div class="stats-card-3 text-white p-6 rounded-lg shadow-lg card-hover">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-sm font-medium opacity-90">Revenus</p>
                                    <p class="text-3xl font-bold">€48,392</p>
                                </div>
                                <i class="fas fa-euro-sign text-4xl opacity-80"></i>
                            </div>
                        </div>
                        
                        <div class="stats-card-4 text-white p-6 rounded-lg shadow-lg card-hover">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-sm font-medium opacity-90">Tickets Vendus</p>
                                    <p class="text-3xl font-bold">12,389</p>
                                </div>
                                <i class="fas fa-ticket-alt text-4xl opacity-80"></i>
                            </div>
                        </div>
                    </div>

                    <!-- Charts -->
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                        <div class="bg-white p-6 rounded-lg shadow-lg">
                            <h3 class="text-lg font-semibold mb-4">Revenus par Catégorie</h3>
                            <div style="height: 300px;">
                                <canvas id="categoryChart"></canvas>
                            </div>
                        </div>
                        
                        <div class="bg-white p-6 rounded-lg shadow-lg">
                            <h3 class="text-lg font-semibold mb-4">Évolution des Ventes</h3>
                            <div style="height: 300px;">
                                <canvas id="salesChart"></canvas>
                            </div>
                        </div>
                    </div>

                    <!-- Recent Activity -->
                    <div class="bg-white rounded-lg shadow-lg">
                        <div class="p-6 border-b border-gray-200">
                            <h3 class="text-lg font-semibold">Activité Récente</h3>
                        </div>
                        <div class="p-6">
                            <div class="space-y-4">
                                <div class="flex items-center space-x-4">
                                    <div class="w-2 h-2 bg-green-500 rounded-full"></div>
                                    <div class="flex-1">
                                        <p class="text-sm text-gray-800">Nouveau produit ajouté : "iPhone 14 Pro"</p>
                                        <p class="text-xs text-gray-500">Il y a 2 minutes</p>
                                    </div>
                                </div>
                                
                                <div class="flex items-center space-x-4">
                                    <div class="w-2 h-2 bg-blue-500 rounded-full"></div>
                                    <div class="flex-1">
                                        <p class="text-sm text-gray-800">Utilisateur "john_doe" a acheté 5 tickets</p>
                                        <p class="text-xs text-gray-500">Il y a 15 minutes</p>
                                    </div>
                                </div>
                                
                                <div class="flex items-center space-x-4">
                                    <div class="w-2 h-2 bg-yellow-500 rounded-full"></div>
                                    <div class="flex-1">
                                        <p class="text-sm text-gray-800">Tirage effectué pour "PlayStation 5"</p>
                                        <p class="text-xs text-gray-500">Il y a 1 heure</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Products Section -->
                <div id="productsSection" class="hidden">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-2xl font-bold">Gestion des Produits</h3>
                        <button id="addProductBtn" class="btn-primary text-white px-4 py-2 rounded-lg">
                            <i class="fas fa-plus mr-2"></i>Nouveau Produit
                        </button>
                    </div>
                    
                    <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                        <div class="p-6 border-b border-gray-200">
                            <div class="flex items-center space-x-4">
                                <div class="relative">
                                    <input type="text" id="searchProducts" class="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500" placeholder="Rechercher un produit...">
                                    <i class="fas fa-search absolute left-3 top-3 text-gray-400"></i>
                                </div>
                                <select id="filterCategory" class="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500">
                                    <option value="">Toutes les catégories</option>
                                    <option value="electronique">Électronique</option>
                                    <option value="mode">Mode</option>
                                    <option value="maison">Maison</option>
                                    <option value="sport">Sport</option>
                                    <option value="jeux">Jeux</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="overflow-x-auto">
                            <table class="w-full table-hover">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Produit</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Catégorie</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Prix</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tickets</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="productsTableBody" class="bg-white divide-y divide-gray-200">
                                    <!-- Les produits seront ajoutés ici -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Users Section -->
                <div id="usersSection" class="hidden">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-2xl font-bold">Gestion des Utilisateurs</h3>
                        <button id="addUserBtn" class="btn-primary text-white px-4 py-2 rounded-lg">
                            <i class="fas fa-plus mr-2"></i>Nouvel Utilisateur
                        </button>
                    </div>
                    
                    <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                        <div class="p-6 border-b border-gray-200">
                            <div class="flex items-center space-x-4">
                                <div class="relative">
                                    <input type="text" id="searchUsers" class="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500" placeholder="Rechercher un utilisateur...">
                                    <i class="fas fa-search absolute left-3 top-3 text-gray-400"></i>
                                </div>
                                <select id="filterUserType" class="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500">
                                    <option value="">Tous les types</option>
                                    <option value="admin">Administrateur</option>
                                    <option value="seller">Vendeur</option>
                                    <option value="user">Utilisateur</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="overflow-x-auto">
                            <table class="w-full table-hover">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Utilisateur</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Inscription</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="usersTableBody" class="bg-white divide-y divide-gray-200">
                                    <!-- Les utilisateurs seront ajoutés ici -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Transactions Section -->
                <div id="transactionsSection" class="hidden">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-2xl font-bold">Transactions</h3>
                        <div class="flex space-x-2">
                            <button class="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600">
                                <i class="fas fa-download mr-2"></i>Exporter
                            </button>
                        </div>
                    </div>
                    
                    <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                        <div class="p-6 border-b border-gray-200">
                            <div class="flex items-center space-x-4">
                                <div class="relative">
                                    <input type="text" id="searchTransactions" class="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500" placeholder="Rechercher une transaction...">
                                    <i class="fas fa-search absolute left-3 top-3 text-gray-400"></i>
                                </div>
                                <select id="filterTransactionStatus" class="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500">
                                    <option value="">Tous les statuts</option>
                                    <option value="completed">Terminée</option>
                                    <option value="pending">En attente</option>
                                    <option value="failed">Échouée</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="overflow-x-auto">
                            <table class="w-full table-hover">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Utilisateur</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Produit</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Montant</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tickets</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="transactionsTableBody" class="bg-white divide-y divide-gray-200">
                                    <!-- Les transactions seront ajoutées ici -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Categories Section -->
                <div id="categoriesSection" class="hidden">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-2xl font-bold">Gestion des Catégories</h3>
                        <button id="addCategoryBtn" class="btn-primary text-white px-4 py-2 rounded-lg">
                            <i class="fas fa-plus mr-2"></i>Nouvelle Catégorie
                        </button>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <div class="bg-white p-6 rounded-lg shadow-lg card-hover">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <i class="fas fa-mobile-alt text-2xl text-blue-500 mr-3"></i>
                                    <h4 class="text-lg font-semibold">Électronique</h4>
                                </div>
                                <div class="flex space-x-2">
                                    <button class="text-blue-500 hover:text-blue-700">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="text-red-500 hover:text-red-700">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                            <p class="text-gray-600 mb-4">Produits électroniques, gadgets et accessoires</p>
                            <div class="flex justify-between text-sm">
                                <span class="text-gray-500">Produits : 45</span>
                                <span class="text-green-500">Revenus : €23,450</span>
                            </div>
                        </div>
                        
                        <div class="bg-white p-6 rounded-lg shadow-lg card-hover">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <i class="fas fa-tshirt text-2xl text-pink-500 mr-3"></i>
                                    <h4 class="text-lg font-semibold">Mode</h4>
                                </div>
                                <div class="flex space-x-2">
                                    <button class="text-blue-500 hover:text-blue-700">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="text-red-500 hover:text-red-700">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                            <p class="text-gray-600 mb-4">Vêtements, chaussures et accessoires</p>
                            <div class="flex justify-between text-sm">
                                <span class="text-gray-500">Produits : 32</span>
                                <span class="text-green-500">Revenus : €15,280</span>
                            </div>
                        </div>
                        
                        <div class="bg-white p-6 rounded-lg shadow-lg card-hover">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <i class="fas fa-home text-2xl text-green-500 mr-3"></i>
                                    <h4 class="text-lg font-semibold">Maison</h4>
                                </div>
                                <div class="flex space-x-2">
                                    <button class="text-blue-500 hover:text-blue-700">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="text-red-500 hover:text-red-700">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                            <p class="text-gray-600 mb-4">Décoration, meubles et articles pour la maison</p>
                            <div class="flex justify-between text-sm">
                                <span class="text-gray-500">Produits : 28</span>
                                <span class="text-green-500">Revenus : €9,662</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Settings Section -->
                <div id="settingsSection" class="hidden">
                    <h3 class="text-2xl font-bold mb-6">Paramètres du Système</h3>
                    
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <div class="bg-white p-6 rounded-lg shadow-lg">
                            <h4 class="text-lg font-semibold mb-4">Paramètres Généraux</h4>
                            <div class="space-y-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Nom du site</label>
                                    <input type="text" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500" value="Tombola">
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Email administrateur</label>
                                    <input type="email" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500" value="chabgyver@gmail.com">
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Devise</label>
                                    <select class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500">
                                        <option value="EUR">Euro (€)</option>
                                        <option value="USD">Dollar ($)</option>
                                        <option value="GBP">Livre (£)</option>
                                    </select>
                                </div>
                                
                                <div class="flex items-center">
                                    <input type="checkbox" id="maintenanceMode" class="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500">
                                    <label for="maintenanceMode" class="ml-2 text-sm font-medium text-gray-900">Mode maintenance</label>
                                </div>
                            </div>
                        </div>
                        
                        <div class="bg-white p-6 rounded-lg shadow-lg">
                            <h4 class="text-lg font-semibold mb-4">Paramètres de Sécurité</h4>
                            <div class="space-y-4">
                                <div class="flex items-center">
                                    <input type="checkbox" id="twoFactorAuth" class="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500" checked>
                                    <label for="twoFactorAuth" class="ml-2 text-sm font-medium text-gray-900">Authentification à deux facteurs</label>
                                </div>
                                
                                <div class="flex items-center">
                                    <input type="checkbox" id="loginLogging" class="w-4 h-4 text-purple-600 bg-gray-100 border-gray-300 rounded focus:ring-purple-500" checked>
                                    <label for="loginLogging" class="ml-2 text-sm font-medium text-gray-900">Journalisation des connexions</label>
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Délai de session (minutes)</label>
                                    <input type="number" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500" value="30">
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Tentatives de connexion max</label>
                                    <input type="number" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500" value="5">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mt-6 flex justify-end">
                        <button class="btn-primary text-white px-6 py-2 rounded-lg">
                            <i class="fas fa-save mr-2"></i>Enregistrer les paramètres
                        </button>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Product Modal -->
    <div id="productModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
        <div class="bg-white rounded-lg w-full max-w-2xl mx-4 max-h-screen overflow-y-auto">
            <div class="p-6 border-b border-gray-200">
                <div class="flex justify-between items-center">
                    <h3 id="productModalTitle" class="text-lg font-semibold">Nouveau Produit</h3>
                    <button id="closeProductModal" class="text-gray-400 hover:text-gray-600">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
            
            <div class="p-6">
                <form id="productForm" class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Titre du produit</label>
                        <input type="text" id="productTitle" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500" required>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                        <textarea id="productDescription" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500" rows="4" required></textarea>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Prix du produit (€)</label>
                            <input type="number" id="productPrice" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500" step="0.01" required>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Prix du ticket (€)</label>
                            <input type="number" id="ticketPrice" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500" step="0.01" required>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Nombre total de tickets</label>
                            <input type="number" id="totalTickets" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500" required>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Catégorie</label>
                            <select id="productCategory" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500" required>
                                <option value="">Sélectionner une catégorie</option>
                                <option value="1">Électronique</option>
                                <option value="2">Mode</option>
                                <option value="3">Maison</option>
                                <option value="4">Sport</option>
                                <option value="5">Jeux</option>
                                <option value="6">Autres</option>
                            </select>
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Images du produit</label>
                        <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                            <i class="fas fa-cloud-upload-alt text-3xl text-gray-400 mb-2"></i>
                            <p class="text-gray-600">Glissez vos images ici ou cliquez pour sélectionner</p>
                            <input type="file" id="productImages" class="hidden" multiple accept="image/*">
                        </div>
                        <div id="imagePreview" class="mt-4 grid grid-cols-2 md:grid-cols-3 gap-4"></div>
                    </div>
                    
                    <div class="flex justify-end space-x-4 pt-4">
                        <button type="button" id="cancelProductBtn" class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
                            Annuler
                        </button>
                        <button type="submit" class="btn-primary text-white px-6 py-2 rounded-lg">
                            <i class="fas fa-save mr-2"></i>Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Données simulées
        const mockData = {
            products: [
                {
                    id: 1,
                    title: "iPhone 14 Pro",
                    description: "Smartphone dernière génération",
                    price: 1299.00,
                    ticketPrice: 25.00,
                    totalTickets: 52,
                    ticketsSold: 47,
                    category: "Électronique",
                    seller: "TechStore",
                    status: "active",
                    createdAt: "2024-01-15"
                },
                {
                    id: 2,
                    title: "PlayStation 5",
                    description: "Console de jeu nouvelle génération",
                    price: 599.00,
                    ticketPrice: 15.00,
                    totalTickets: 40,
                    ticketsSold: 32,
                    category: "Jeux",
                    seller: "GameWorld",
                    status: "active",
                    createdAt: "2024-01-14"
                },
                {
                    id: 3,
                    title: "MacBook Pro 16\"",
                    description: "Ordinateur portable professionnel",
                    price: 2499.00,
                    ticketPrice: 50.00,
                    totalTickets: 50,
                    ticketsSold: 18,
                    category: "Électronique",
                    seller: "TechStore",
                    status: "active",
                    createdAt: "2024-01-13"
                }
            ],
            users: [
                {
                    id: 1,
                    username: "chabgyver",
                    email: "chabgyver@gmail.com",
                    type: "admin",
                    status: "active",
                    createdAt: "2024-01-01"
                },
                {
                    id: 2,
                    username: "vendeur1",
                    email: "vendeur@test.com",
                    type: "seller",
                    status: "active",
                    createdAt: "2024-01-02"
                },
                {
                    id: 3,
                    username: "user1",
                    email: "user@test.com",
                    type: "user",
                    status: "active",
                    createdAt: "2024-01-03"
                }
            ],
            transactions: [
                {
                    id: 1,
                    userId: 2,
                    userName: "John Doe",
                    productId: 1,
                    productTitle: "iPhone 14 Pro",
                    amount: 75.00,
                    ticketsCount: 3,
                    status: "completed",
                    createdAt: "2024-01-15 14:30:00"
                },
                {
                    id: 2,
                    userId: 3,
                    userName: "Jane Smith",
                    productId: 2,
                    productTitle: "PlayStation 5",
                    amount: 45.00,
                    ticketsCount: 3,
                    status: "completed",
                    createdAt: "2024-01-15 13:15:00"
                }
            ]
        };

        // Variables globales
        let currentUser = null;
        let currentSection = 'dashboard';

        // Authentification
        const loginForm = document.getElementById('loginForm');
        const loginPage = document.getElementById('loginPage');
        const adminInterface = document.getElementById('adminInterface');

        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = document.getElementById('loginEmail').value;
            const password = document.getElementById('loginPassword').value;
            const errorDiv = document.getElementById('loginError');
            
            // Validation des identifiants
            if (email === 'chabgyver@gmail.com' && password === 'Jesuisnele15!') {
                currentUser = {
                    id: 1,
                    username: 'chabgyver',
                    email: 'chabgyver@gmail.com',
                    isAdmin: true
                };
                
                // Transition vers l'interface admin
                loginPage.classList.add('hidden');
                adminInterface.classList.remove('hidden');
                
                // Initialiser l'interface admin
                initializeAdmin();
            } else {
                errorDiv.textContent = 'Identifiants incorrects. Veuillez réessayer.';
                errorDiv.classList.remove('hidden');
            }
        });

        // Toggle password visibility
        document.getElementById('togglePassword').addEventListener('click', function() {
            const passwordInput = document.getElementById('loginPassword');
            const icon = this.querySelector('i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        });

        // Initialisation de l'interface admin
        function initializeAdmin() {
            // Mettre à jour le nom d'utilisateur
            document.getElementById('userName').textContent = currentUser.username;
            
            // Initialiser les graphiques
            initializeCharts();
            
            // Charger les données
            loadProducts();
            loadUsers();
            loadTransactions();
            
            // Configurer la navigation
            setupNavigation();
            
            // Configurer les modales
            setupModals();
            
            // Configurer le menu utilisateur
            setupUserMenu();
        }

        // Navigation
        function setupNavigation() {
            const navItems = document.querySelectorAll('.nav-item');
            
            navItems.forEach(item => {
                item.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    // Retirer la classe active de tous les items
                    navItems.forEach(nav => nav.classList.remove('bg-white', 'bg-opacity-20'));
                    
                    // Ajouter la classe active à l'item cliqué
                    this.classList.add('bg-white', 'bg-opacity-20');
                    
                    // Changer de section
                    const sectionName = this.dataset.section;
                    showSection(sectionName);
                });
            });
        }

        // Afficher une section
        function showSection(sectionName) {
            // Cacher toutes les sections
            const sections = document.querySelectorAll('[id$="Section"]');
            sections.forEach(section => section.classList.add('hidden'));
            
            // Afficher la section demandée
            const targetSection = document.getElementById(sectionName + 'Section');
            if (targetSection) {
                targetSection.classList.remove('hidden');
                targetSection.classList.add('fade-in');
            }
            
            // Mettre à jour le titre
            const titles = {
                dashboard: 'Tableau de bord',
                products: 'Gestion des Produits',
                users: 'Gestion des Utilisateurs',
                transactions: 'Transactions',
                categories: 'Gestion des Catégories',
                settings: 'Paramètres'
            };
            
            document.getElementById('pageTitle').textContent = titles[sectionName] || 'Administration';
            currentSection = sectionName;
        }

        // Initialiser les graphiques
        function initializeCharts() {
            // Graphique des revenus par catégorie
            const categoryCtx = document.getElementById('categoryChart').getContext('2d');
            new Chart(categoryCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Électronique', 'Mode', 'Maison', 'Sport', 'Jeux', 'Autres'],
                    datasets: [{
                        data: [23450, 15280, 9662, 12890, 18750, 5680],
                        backgroundColor: [
                            '#667eea',
                            '#764ba2',
                            '#f093fb',
                            '#f5576c',
                            '#4facfe',
                            '#00f2fe'
                        ]
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });

            // Graphique de l'évolution des ventes
            const salesCtx = document.getElementById('salesChart').getContext('2d');
            new Chart(salesCtx, {
                type: 'line',
                data: {
                    labels: ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun'],
                    datasets: [{
                        label: 'Ventes',
                        data: [3200, 4100, 3800, 5200, 4900, 6100],
                        borderColor: '#667eea',
                        backgroundColor: 'rgba(102, 126, 234, 0.1)',
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }

        // Charger les produits
        function loadProducts() {
            const tbody = document.getElementById('productsTableBody');
            tbody.innerHTML = '';
            
            mockData.products.forEach(product => {
                const row = document.createElement('tr');
                const progressPercentage = Math.round((product.ticketsSold / product.totalTickets) * 100);
                
                row.innerHTML = `
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="flex items-center">
                            <div class="flex-shrink-0 h-10 w-10">
                                <div class="h-10 w-10 rounded-full bg-gradient-to-r from-purple-400 to-pink-400 flex items-center justify-center">
                                    <i class="fas fa-gift text-white"></i>
                                </div>
                            </div>
                            <div class="ml-4">
                                <div class="text-sm font-medium text-gray-900">${product.title}</div>
                                <div class="text-sm text-gray-500">${product.description.substring(0, 30)}...</div>
                            </div>
                        </div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                            ${product.category}
                        </span>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ${product.price.toFixed(2)}€
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="text-sm text-gray-900">${product.ticketsSold}/${product.totalTickets}</div>
                        <div class="w-full bg-gray-200 rounded-full h-2">
                            <div class="bg-gradient-to-r from-green-400 to-blue-500 h-2 rounded-full" style="width: ${progressPercentage}%"></div>
                        </div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                            ${product.status}
                        </span>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <button class="text-blue-600 hover:text-blue-900 mr-3" onclick="editProduct(${product.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="text-red-600 hover:text-red-900" onclick="deleteProduct(${product.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                `;
                
                tbody.appendChild(row);
            });
        }

        // Charger les utilisateurs
        function loadUsers() {
            const tbody = document.getElementById('usersTableBody');
            tbody.innerHTML = '';
            
            mockData.users.forEach(user => {
                const row = document.createElement('tr');
                
                const typeColors = {
                    admin: 'bg-red-100 text-red-800',
                    seller: 'bg-blue-100 text-blue-800',
                    user: 'bg-green-100 text-green-800'
                };
                
                row.innerHTML = `
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="flex items-center">
                            <div class="flex-shrink-0 h-10 w-10">
                                <div class="h-10 w-10 rounded-full bg-gradient-to-r from-blue-400 to-purple-400 flex items-center justify-center">
                                    <i class="fas fa-user text-white"></i>
                                </div>
                            </div>
                            <div class="ml-4">
                                <div class="text-sm font-medium text-gray-900">${user.username}</div>
                            </div>
                        </div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ${user.email}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${typeColors[user.type]}">
                            ${user.type}
                        </span>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                            ${user.status}
                        </span>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ${user.createdAt}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <button class="text-blue-600 hover:text-blue-900 mr-3" onclick="editUser(${user.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="text-red-600 hover:text-red-900" onclick="deleteUser(${user.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                `;
                
                tbody.appendChild(row);
            });
        }

        // Charger les transactions
        function loadTransactions() {
            const tbody = document.getElementById('transactionsTableBody');
            tbody.innerHTML = '';
            
            mockData.transactions.forEach(transaction => {
                const row = document.createElement('tr');
                
                row.innerHTML = `
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        #${transaction.id.toString().padStart(6, '0')}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ${transaction.userName}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ${transaction.productTitle}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ${transaction.amount.toFixed(2)}€
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ${transaction.ticketsCount}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                            ${transaction.status}
                        </span>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ${transaction.createdAt}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <button class="text-blue-600 hover:text-blue-900 mr-3" onclick="viewTransaction(${transaction.id})">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="text-green-600 hover:text-green-900" onclick="refundTransaction(${transaction.id})">
                            <i class="fas fa-undo"></i>
                        </button>
                    </td>
                `;
                
                tbody.appendChild(row);
            });
        }

        // Configuration des modales
        function setupModals() {
            const productModal = document.getElementById('productModal');
            const addProductBtn = document.getElementById('addProductBtn');
            const closeProductModal = document.getElementById('closeProductModal');
            const cancelProductBtn = document.getElementById('cancelProductBtn');
            const productForm = document.getElementById('productForm');

            // Ouvrir la modale
            addProductBtn.addEventListener('click', function() {
                productModal.classList.remove('hidden');
                productModal.classList.add('flex');
            });

            // Fermer la modale
            closeProductModal.addEventListener('click', function() {
                productModal.classList.add('hidden');
                productModal.classList.remove('flex');
            });

            cancelProductBtn.addEventListener('click', function() {
                productModal.classList.add('hidden');
                productModal.classList.remove('flex');
            });

            // Fermer en cliquant à l'extérieur
            productModal.addEventListener('click', function(e) {
                if (e.target === productModal) {
                    productModal.classList.add('hidden');
                    productModal.classList.remove('flex');
                }
            });

            // Soumission du formulaire
            productForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const formData = new FormData(productForm);
                const newProduct = {
                    id: mockData.products.length + 1,
                    title: document.getElementById('productTitle').value,
                    description: document.getElementById('productDescription').value,
                    price: parseFloat(document.getElementById('productPrice').value),
                    ticketPrice: parseFloat(document.getElementById('ticketPrice').value),
                    totalTickets: parseInt(document.getElementById('totalTickets').value),
                    ticketsSold: 0,
                    category: getCategoryName(document.getElementById('productCategory').value),
                    seller: currentUser.username,
                    status: 'active',
                    createdAt: new Date().toISOString().split('T')[0]
                };
                
                mockData.products.push(newProduct);
                loadProducts();
                
                // Fermer la modale
                productModal.classList.add('hidden');
                productModal.classList.remove('flex');
                
                // Réinitialiser le formulaire
                productForm.reset();
                
                // Notification de succès
                showNotification('Produit ajouté avec succès!', 'success');
            });
        }

        // Configuration du menu utilisateur
        function setupUserMenu() {
            const userMenuBtn = document.getElementById('userMenuBtn');
            const userMenu = document.getElementById('userMenu');
            const logoutBtn = document.getElementById('logoutBtn');

            userMenuBtn.addEventListener('click', function() {
                userMenu.classList.toggle('hidden');
            });

            // Fermer le menu en cliquant à l'extérieur
            document.addEventListener('click', function(e) {
                if (!userMenuBtn.contains(e.target) && !userMenu.contains(e.target)) {
                    userMenu.classList.add('hidden');
                }
            });

            // Déconnexion
            logoutBtn.addEventListener('click', function() {
                currentUser = null;
                adminInterface.classList.add('hidden');
                loginPage.classList.remove('hidden');
                
                // Réinitialiser le formulaire de connexion
                document.getElementById('loginForm').reset();
                document.getElementById('loginError').classList.add('hidden');
            });
        }

        // Fonctions utilitaires
        function getCategoryName(categoryId) {
            const categories = {
                '1': 'Électronique',
                '2': 'Mode',
                '3': 'Maison',
                '4': 'Sport',
                '5': 'Jeux',
                '6': 'Autres'
            };
            return categories[categoryId] || 'Autres';
        }

        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.className = `fixed top-4 right-4 z-50 p-4 rounded-lg text-white ${type === 'success' ? 'bg-green-500' : 'bg-blue-500'} fade-in`;
            notification.innerHTML = `
                <div class="flex items-center">
                    <i class="fas fa-${type === 'success' ? 'check' : 'info'} mr-2"></i>
                    <span>${message}</span>
                </div>
            `;
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.remove();
            }, 3000);
        }

        // Fonctions d'actions
        function editProduct(id) {
            showNotification('Modification du produit #' + id, 'info');
        }

        function deleteProduct(id) {
            if (confirm('Êtes-vous sûr de vouloir supprimer ce produit ?')) {
                mockData.products = mockData.products.filter(p => p.id !== id);
                loadProducts();
                showNotification('Produit supprimé avec succès!', 'success');
            }
        }

        function editUser(id) {
            showNotification('Modification de l\'utilisateur #' + id, 'info');
        }

        function deleteUser(id) {
            if (confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur ?')) {
                mockData.users = mockData.users.filter(u => u.id !== id);
                loadUsers();
                showNotification('Utilisateur supprimé avec succès!', 'success');
            }
        }

        function viewTransaction(id) {
            showNotification('Affichage de la transaction #' + id, 'info');
        }

        function refundTransaction(id) {
            if (confirm('Êtes-vous sûr de vouloir rembourser cette transaction ?')) {
                showNotification('Transaction remboursée avec succès!', 'success');
            }
        }

        // Initialisation au chargement de la page
        document.addEventListener('DOMContentLoaded', function() {
            // Le site commence sur la page de connexion
            console.log('Interface admin initialisée');
        });
    </script>
</body>
</html>
    <script id="html_badge_script1">
        window.__genspark_remove_badge_link = "https://www.genspark.ai/api/html_badge/" +
            "remove_badge?token=To%2FBnjzloZ3UfQdcSaYfDjjVvsuYlrZNcMjsqYKyZn0b4jAT8ZNMwMTqlS%2FQnMma7jhzPStpiRZaE9BExiBF91A%2FLqbat7Bcg5ekINsrJVgfi7BZkibkEfN1Ut5wqeRMsonKogv3Wtw6KC%2BWLaF%2BFCesrG4kmVBzr%2Fu%2BSb3TmpsPrrmkxkdSS94k%2B2lV4cb3JHCVPRx%2Fu2irsZascddeHvqHHnKWgL3VTha2FbTli%2BJMr%2FYMuYJkf2lmtFxs6HodjdJgvfwCTG%2BMA2mhL38gheFjpDGdS2BEKuP9H5tv5uHc%2Fy2a3y0KEkZk%2BciDaoPgYBrZjCHriOwoVZ3xJ3ACEoq0shAwL%2FZsI0lknj9PBx06X9k3ZXk8OFOmIxBeZRreAt4Rf3cvAZqbRE8PCw8AkxDI%2Fc04MYYX556zzwgi34MEooVGjWyWhZvfnbp%2FDWQ058fn%2B1nVtovFhHWW6YvgUKa1Gm8QJvp%2BqCmFy0e4lnPV9J0CgSfCxbmVIzzIpPZCspMzxgWdc8umrnG2FRguFj76OuQhw5J7FSpmIdHkrNQ%3D";
        window.__genspark_locale = "fr-FR";
        window.__genspark_token = "To/BnjzloZ3UfQdcSaYfDjjVvsuYlrZNcMjsqYKyZn0b4jAT8ZNMwMTqlS/QnMma7jhzPStpiRZaE9BExiBF91A/Lqbat7Bcg5ekINsrJVgfi7BZkibkEfN1Ut5wqeRMsonKogv3Wtw6KC+WLaF+FCesrG4kmVBzr/u+Sb3TmpsPrrmkxkdSS94k+2lV4cb3JHCVPRx/u2irsZascddeHvqHHnKWgL3VTha2FbTli+JMr/YMuYJkf2lmtFxs6HodjdJgvfwCTG+MA2mhL38gheFjpDGdS2BEKuP9H5tv5uHc/y2a3y0KEkZk+ciDaoPgYBrZjCHriOwoVZ3xJ3ACEoq0shAwL/ZsI0lknj9PBx06X9k3ZXk8OFOmIxBeZRreAt4Rf3cvAZqbRE8PCw8AkxDI/c04MYYX556zzwgi34MEooVGjWyWhZvfnbp/DWQ058fn+1nVtovFhHWW6YvgUKa1Gm8QJvp+qCmFy0e4lnPV9J0CgSfCxbmVIzzIpPZCspMzxgWdc8umrnG2FRguFj76OuQhw5J7FSpmIdHkrNQ=";
    </script>
    
    <script id="html_notice_dialog_script" src="https://www.genspark.ai/notice_dialog.js"></script>
    