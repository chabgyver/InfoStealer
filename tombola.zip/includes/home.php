<section class="p-4">
    <h1 class="text-3xl font-extrabold mb-6 text-center">🎁 Produits en Jeu</h1>
    <div class="product-grid">
        <?php foreach ($products as $product): ?>
            <div class="card product-card fade-in">
                <div class="image-carousel">
                    <div class="carousel-container" data-product-id="<?= $product['id'] ?>">
                        <?php foreach ($product['images'] as $image): ?>
                            <div class="carousel-slide">
                                <img src="<?= htmlspecialchars($image) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <button class="carousel-nav prev" onclick="prevImage(<?= $product['id'] ?>)">
                        <i class="fas fa-chevron-left"></i>
                    </button>
                    <button class="carousel-nav next" onclick="nextImage(<?= $product['id'] ?>)">
                        <i class="fas fa-chevron-right"></i>
                    </button>
                    <div class="carousel-dots">
                        <?php foreach ($product['images'] as $index => $_): ?>
                            <span class="carousel-dot <?= $index === 0 ? 'active' : '' ?>" onclick="goToSlide(<?= $product['id'] ?>, <?= $index ?>)"></span>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="product-content">
                    <div class="mb-2">
                        <?php if (!empty($product['isNew'])): ?><span class="badge new">Nouveau</span><?php endif; ?>
                        <?php if (!empty($product['isHot'])): ?><span class="badge hot">Populaire</span><?php endif; ?>
                    </div>
                    <h3 class="product-title"><?= htmlspecialchars($product['name']) ?></h3>
                    <p class="text-gray-400 mb-3"><?= htmlspecialchars($product['description']) ?></p>
                    <div class="product-price">€<?= htmlspecialchars($product['price']) ?></div>
                    <div class="ticket-info">
                        <span>Ticket: €<?= htmlspecialchars($product['ticket_price']) ?></span>
                        <span><?= (int)$product['total_tickets'] - (int)$product['tickets_sold'] ?>/<?= $product['total_tickets'] ?> tickets</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: <?= ($product['tickets_sold'] / max(1, $product['total_tickets'])) * 100 ?>%"></div>
                    </div>
                    <button class="btn btn-success w-full" onclick='openPopup(<?= json_encode($product, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>)'>
                        <i class="fas fa-ticket-alt mr-2"></i>
                        Acheter un ticket
                    </button>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<div class="popup-overlay" id="popup">
    <div class="popup">
        <div class="popup-header">
            <h2 class="text-2xl font-bold" id="popupTitle">Titre du produit</h2>
            <button class="popup-close" onclick="document.getElementById('popup').classList.remove('show')">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="popup-body">
            <img id="popupImage" src="" alt="Image produit" class="w-full h-48 object-cover mb-4 rounded">
            <p id="popupDescription" class="text-gray-300 mb-4">Description du produit ici.</p>
            <div class="form-group">
                <label class="form-label">Email de confirmation</label>
                <input type="email" class="form-input" placeholder="votre@email.com">
            </div>
            <div class="form-group">
                <label class="form-label">Quantité</label>
                <input type="number" class="form-input" value="1" min="1" max="10">
            </div>
            <button class="btn btn-primary w-full">
                <i class="fas fa-shopping-cart mr-2"></i>
                Confirmer l'achat
            </button>
        </div>
    </div>
</div>

<script>
function openPopup(product) {
    document.getElementById('popupTitle').textContent = product.name;
    document.getElementById('popupImage').src = product.images[0] || '';
    document.getElementById('popupDescription').textContent = product.description || 'Pas de description disponible.';
    document.getElementById('popup').classList.add('show');
}

function nextImage(productId) {
    const container = document.querySelector(`[data-product-id="${productId}"]`);
    const slides = container.querySelectorAll('.carousel-slide');
    let index = parseInt(container.dataset.index || 0);
    index = (index + 1) % slides.length;
    container.dataset.index = index;
    container.style.transform = `translateX(-${index * 100}%)`;
    updateDots(container, index);
}

function prevImage(productId) {
    const container = document.querySelector(`[data-product-id="${productId}"]`);
    const slides = container.querySelectorAll('.carousel-slide');
    let index = parseInt(container.dataset.index || 0);
    index = (index - 1 + slides.length) % slides.length;
    container.dataset.index = index;
    container.style.transform = `translateX(-${index * 100}%)`;
    updateDots(container, index);
}

function goToSlide(productId, slideIndex) {
    const container = document.querySelector(`[data-product-id="${productId}"]`);
    container.dataset.index = slideIndex;
    container.style.transform = `translateX(-${slideIndex * 100}%)`;
    updateDots(container, slideIndex);
}

function updateDots(container, activeIndex) {
    const dots = container.closest('.product-card').querySelectorAll('.carousel-dot');
    dots.forEach((dot, i) => dot.classList.toggle('active', i === activeIndex));
}
</script>
