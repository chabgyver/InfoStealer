<footer class="bg-dark py-12 mt-12">
    <div class="container grid grid-cols-1 md:grid-cols-3 gap-8">
        <div class="footer-section">
            <h3 class="text-accent flex items-center gap-2 mb-4">
                <i class="fas fa-info-circle"></i>
                <span>À propos</span>
            </h3>
            <ul class="space-y-2">
                <li><a href="../about.php" class="text-light hover:text-primary transition-colors">Notre histoire</a></li>
                <li><a href="../team.php" class="text-light hover:text-primary transition-colors">Notre équipe</a></li>
                <li><a href="../values.php" class="text-light hover:text-primary transition-colors">Nos valeurs</a></li>
            </ul>
        </div>
        
        <div class="footer-section">
            <h3 class="text-accent flex items-center gap-2 mb-4">
                <i class="fas fa-headset"></i>
                <span>Assistance</span>
            </h3>
            <ul class="space-y-2">
                <li><a href="../faq.php" class="text-light hover:text-primary transition-colors">FAQ</a></li>
                <li><a href="../contact.php" class="text-light hover:text-primary transition-colors">Contactez-nous</a></li>
                <li><a href="../terms.php" class="text-light hover:text-primary transition-colors">CGU</a></li>
            </ul>
        </div>
        
        <div class="footer-section">
            <h3 class="text-accent flex items-center gap-2 mb-4">
                <i class="fas fa-share-alt"></i>
                <span>Réseaux sociaux</span>
            </h3>
            <div class="flex space-x-4">
                <a href="#" class="text-2xl text-light hover:text-primary transition-colors"><i class="fab fa-facebook"></i></a>
                <a href="#" class="text-2xl text-light hover:text-primary transition-colors"><i class="fab fa-twitter"></i></a>
                <a href="#" class="text-2xl text-light hover:text-primary transition-colors"><i class="fab fa-instagram"></i></a>
                <a href="#" class="text-2xl text-light hover:text-primary transition-colors"><i class="fab fa-linkedin"></i></a>
            </div>
        </div>
    </div>
    
    <div class="container mt-8 pt-8 border-t border-gray-700 text-center">
        <p class="text-light">&copy; <?= date('Y') ?> Tombola. Tous droits réservés.</p>
    </div>
</footer>
