<?php

declare(strict_types=1);

use Rector\Core\Configuration\Option;
use Rector\Core\ValueObject\PhpVersion;
use Rector\Set\ValueObject\LevelSetList;
use Rector\Set\ValueObject\SetList;
use Symfony\Component\DependencyInjection\Loader\Configurator\ContainerConfigurator;

return static function (ContainerConfigurator $containerConfigurator): void {
    $parameters = $containerConfigurator->parameters();

    // Define what rule sets will be applied
    $containerConfigurator->import(LevelSetList::UP_TO_PHP_81);
    $containerConfigurator->import(SetList::CODE_QUALITY);
    $containerConfigurator->import(SetList::CODING_STYLE);
    $containerConfigurator->import(SetList::DEAD_CODE);
    $containerConfigurator->import(SetList::EARLY_RETURN);
    $containerConfigurator->import(SetList::TYPE_DECLARATION);

    // Paths to refactor; can be files or directories
    $parameters->set(Option::PATHS, [
        __DIR__ . '/src',
        __DIR__ . '/includes',
        __DIR__ . '/migrations',
    ]);

    // Skip specific rules
    $parameters->set(Option::SKIP, [
        // Skip tests
        '*/tests/*',
        '*/Tests/*',
        // Skip vendor
        '*/vendor/*',
        // Skip specific rules
        Rector\CodeQuality\Rector\Class_\CompleteDynamicPropertiesRector::class,
        Rector\CodeQuality\Rector\If_\ExplicitBoolCompareRector::class,
        // Skip specific files
        __DIR__ . '/vendor/*',
        __DIR__ . '/node_modules/*',
        __DIR__ . '/storage/*',
        __DIR__ . '/public/*',
    ]);

    // Auto import fully qualified class names
    $parameters->set(Option::AUTO_IMPORT_NAMES, true);
    
    // Skip root namespace classes like \DateTime or \Exception [default: true]
    $parameters->set(Option::IMPORT_SHORT_CLASSES, false);
    
    // Skip import use statements that already exist
    $parameters->set(Option::IMPORT_DOC_BLOCKS, true);
    
    // PHP version compatibility
    $parameters->set(Option::PHP_VERSION_FEATURES, PhpVersion::PHP_81);
    
    // Path to PHPStan with extensions, that PHPStan in Rector uses to determine types
    $parameters->set(Option::PHPSTAN_FOR_RECTOR_PATH, __DIR__ . '/phpstan.neon.dist');

    // Cache
    $parameters->set(Option::CACHE_DIR, __DIR__ . '/.rector_cache');
    $parameters->set(Option::ENABLE_CACHE, true);

    // Parallel processing
    $parameters->set(Option::PARALLEL, true);
    $parameters->set(Option::PARALLEL_JOB_SIZE, 10);
    $parameters->set(Option::PARALLEL_TIMEOUT_IN_SECONDS, 120);

    // Debug
    $parameters->set(Option::DEBUG, false);
};
