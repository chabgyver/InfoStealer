<?php
// Configuration des erreurs pour le développement
error_reporting(E_ALL);
ini_set('display_errors', 1);

define('ROOT_PATH', __DIR__);
require_once 'includes/config.php';

// Démarrer la session si elle n'est pas déjà démarrée
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Initialiser la variable de notification
$_SESSION['notification'] = $_SESSION['notification'] ?? [];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Système de Tombola</title>
    
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/main.css">
    
    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="assets/js/main.js" defer></script>
</head>
<body class="bg-gradient-to-br from-gray-900 to-gray-800 min-h-screen">
    <!-- Header -->
    <header class="header bg-gray-900 bg-opacity-90 backdrop-blur-md sticky top-0 z-50">
        <div class="container mx-auto px-4">
            <div class="flex items-center justify-between py-4">
                <!-- Logo -->
                <a href="#" class="logo text-2xl font-bold" onclick="showPage('home'); return false;">
                    <i class="fas fa-dice mr-2"></i>Tombola
                </a>
                
                <!-- Navigation -->
                <nav class="hidden md:flex items-center space-x-6">
                    <div class="relative">
                        <input type="text" class="search-bar bg-gray-800 bg-opacity-50 border border-gray-700 rounded-full py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="Rechercher un produit..." id="searchInput">
                    </div>
                    
                    <button class="btn btn-warning" onclick="filterProducts('almost-sold')">
                        <i class="fas fa-fire"></i> Presque Épuisés
                    </button>
                    <button class="btn btn-success" onclick="filterProducts('new')">
                        <i class="fas fa-star"></i> Nouveautés
                    </button>
                    
                    <div class="user-menu relative" id="userMenu">
                        <button class="btn btn-primary" onclick="toggleUserMenu()" id="userMenuBtn">
                            <i class="fas fa-user"></i> <span id="userMenuText">Se connecter</span>
                        </button>
                        <div class="user-dropdown hidden absolute right-0 mt-2 w-48 bg-gray-800 rounded-md shadow-lg py-1 z-50" id="userDropdown">
                            <a href="#" class="block px-4 py-2 text-sm text-gray-300 hover:bg-gray-700" onclick="showPage('profile'); return false;">
                                <i class="fas fa-user mr-2"></i> Mon Profil
                            </a>
                            <a href="#" class="block px-4 py-2 text-sm text-gray-300 hover:bg-gray-700" onclick="showPage('tickets'); return false;">
                                <i class="fas fa-ticket-alt mr-2"></i> Mes Tickets
                            </a>
                            <a href="#" class="block px-4 py-2 text-sm text-gray-300 hover:bg-gray-700" onclick="showPage('stats'); return false;">
                                <i class="fas fa-chart-bar mr-2"></i> Mes Statistiques
                            </a>
                            <a href="#" class="block px-4 py-2 text-sm text-gray-300 hover:bg-gray-700" onclick="showPage('settings'); return false;">
                                <i class="fas fa-cog mr-2"></i> Paramètres
                            </a>
                            <a href="#" class="block px-4 py-2 text-sm text-red-400 hover:bg-gray-700" onclick="logout(); return false;">
                                <i class="fas fa-sign-out-alt mr-2"></i> Déconnexion
                            </a>
                        </div>
                    </div>
                    
                    <button class="btn btn-secondary" onclick="showPage('admin-login')">
                        <i class="fas fa-shield-alt"></i> Administration
                    </button>
                </nav>
                
                <!-- Bouton menu mobile -->
                <button class="md:hidden text-white focus:outline-none" id="mobileMenuBtn">
                    <i class="fas fa-bars text-2xl"></i>
                </button>
            </div>
        </div>
    </header>

    <!-- Contenu principal -->
    <main class="container mx-auto px-4 py-8">
        <!-- Filtres par catégorie -->
        <div class="category-filter flex space-x-4 overflow-x-auto pb-4 mb-8">
            <button class="filter-btn active" onclick="filterByCategory('all')">
                <i class="fas fa-th-large mr-2"></i> Toutes
            </button>
            <button class="filter-btn" onclick="filterByCategory('electronics')">
                <i class="fas fa-mobile-alt mr-2"></i> Électronique
            </button>
            <button class="filter-btn" onclick="filterByCategory('fashion')">
                <i class="fas fa-tshirt mr-2"></i> Mode
            </button>
            <button class="filter-btn" onclick="filterByCategory('home')">
                <i class="fas fa-home mr-2"></i> Maison
            </button>
            <button class="filter-btn" onclick="filterByCategory('sport')">
                <i class="fas fa-football-ball mr-2"></i> Sport
            </button>
            <button class="filter-btn" onclick="filterByCategory('games')">
                <i class="fas fa-gamepad mr-2"></i> Jeux
            </button>
        </div>

        <!-- Grille de produits -->
        <div class="product-grid grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8" id="productGrid">
            <!-- Les produits seront chargés dynamiquement par JavaScript -->
        </div>
    </main>

    <!-- Popup d'achat -->
    <div class="popup-overlay fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 hidden" id="purchasePopup">
        <div class="popup bg-gray-800 rounded-lg shadow-xl w-full max-w-md mx-4">
            <div class="popup-header border-b border-gray-700 p-6 flex justify-between items-center">
                <h2 class="text-xl font-bold">Acheter des tickets</h2>
                <button class="text-gray-400 hover:text-white focus:outline-none" onclick="closePurchasePopup()">
                    <i class="fas fa-times text-2xl"></i>
                </button>
            </div>
            <div class="popup-body p-6">
                <div class="flex items-center mb-6">
                    <img id="popupProductImage" src="" alt="" class="w-16 h-16 rounded-lg object-cover mr-4">
                    <div>
                        <h3 id="popupProductTitle" class="font-bold text-lg"></h3>
                        <p id="popupProductPrice" class="text-blue-400"></p>
                    </div>
                </div>
                
                <div class="form-group mb-6">
                    <label class="form-label block text-sm font-medium text-gray-300 mb-2">Nombre de tickets</label>
                    <div class="quantity-controls flex items-center space-x-4">
                        <button class="quantity-btn w-10 h-10 flex items-center justify-center rounded-lg bg-gray-700 hover:bg-gray-600" onclick="changeQuantity(-1)">
                            <i class="fas fa-minus"></i>
                        </button>
                        <input type="number" class="quantity-input w-20 text-center bg-gray-700 rounded-lg py-2" id="ticketQuantity" value="1" min="1" max="10" onchange="updateTotal()">
                        <button class="quantity-btn w-10 h-10 flex items-center justify-center rounded-lg bg-gray-700 hover:bg-gray-600" onclick="changeQuantity(1)">
                            <i class="fas fa-plus"></i>
                        </button>
                    </div>
                    <p class="text-xs text-gray-400 mt-1">Maximum 10 tickets par personne</p>
                </div>

                <div class="flex justify-between items-center mb-6 text-sm text-gray-300">
                    <span>Prix par ticket: <span id="ticketPrice" class="font-medium">0.00€</span></span>
                    <span>Tickets restants: <span id="ticketsRemaining" class="font-medium">0</span></span>
                </div>

                <div class="total-price mb-6 text-center py-3 rounded-lg bg-green-900 bg-opacity-30 text-green-400 font-bold text-xl">
                    Total: <span id="totalPrice">0.00€</span>
                </div>

                <div class="form-group mb-6">
                    <label class="form-label block text-sm font-medium text-gray-300 mb-2">Méthode de paiement</label>
                    <div class="payment-methods grid grid-cols-3 gap-3">
                        <div class="payment-method selected border-2 border-blue-500 rounded-lg p-3 text-center cursor-pointer" data-method="card">
                            <i class="fas fa-credit-card text-2xl mb-2"></i>
                            <div class="text-xs">Carte bancaire</div>
                        </div>
                        <div class="payment-method border-2 border-transparent hover:border-gray-600 rounded-lg p-3 text-center cursor-pointer" data-method="paypal">
                            <i class="fab fa-paypal text-2xl mb-2"></i>
                            <div class="text-xs">PayPal</div>
                        </div>
                        <div class="payment-method border-2 border-transparent hover:border-gray-600 rounded-lg p-3 text-center cursor-pointer" data-method="crypto">
                            <i class="fab fa-bitcoin text-2xl mb-2"></i>
                            <div class="text-xs">Crypto</div>
                        </div>
                    </div>
                </div>

                <div class="form-group mb-6">
                    <label for="confirmationEmail" class="form-label block text-sm font-medium text-gray-300 mb-2">Email de confirmation</label>
                    <input type="email" class="form-input w-full px-4 py-2 rounded-lg bg-gray-700 border border-gray-600 focus:border-blue-500 focus:ring-2 focus:ring-blue-500 focus:outline-none" id="confirmationEmail" placeholder="votre@email.com" required>
                </div>

                <button class="btn btn-success w-full py-3 rounded-lg" onclick="processPurchase()">
                    <i class="fas fa-shopping-cart mr-2"></i>
                    Acheter maintenant
                </button>
            </div>
        </div>
    </div>

    <!-- Notification -->
    <div class="notification fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 transform translate-x-full transition-transform duration-300 hidden" id="notification">
        <div class="flex items-center">
            <i class="fas fa-check-circle mr-2"></i>
            <span id="notificationText"></span>
        </div>
    </div>

    <!-- Scripts -->
    <script>
        // Initialisation des données
        document.addEventListener('DOMContentLoaded', function() {
            // Charger les produits depuis l'API
            fetchProducts();
            
            // Initialiser les composants
            initializeSearchBar();
            initializePaymentMethods();
            checkAuthStatus();
            
            // Gestion du menu mobile
            const mobileMenuBtn = document.getElementById('mobileMenuBtn');
            if (mobileMenuBtn) {
                mobileMenuBtn.addEventListener('click', function() {
                    const nav = document.querySelector('nav');
                    nav.classList.toggle('hidden');
                    nav.classList.toggle('flex');
                    nav.classList.toggle('flex-col');
                    nav.classList.toggle('absolute');
                    nav.classList.toggle('top-16');
                    nav.classList.toggle('left-0');
                    nav.classList.toggle('right-0');
                    nav.classList.toggle('bg-gray-900');
                    nav.classList.toggle('p-4');
                    nav.classList.toggle('space-y-4');
                });
            }
            
            // Afficher la notification si elle existe
            const notification = <?php echo !empty($_SESSION['notification']) ? json_encode($_SESSION['notification']) : 'null'; ?>;
            if (notification) {
                showNotification(notification.message, notification.type || 'success');
                // Supprimer la notification après l'avoir affichée
                <?php unset($_SESSION['notification']); ?>
            }
        });
    </script>
</body>
</html>
